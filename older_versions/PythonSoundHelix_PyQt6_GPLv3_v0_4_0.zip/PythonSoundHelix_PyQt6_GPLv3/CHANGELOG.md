# Changelog

## v0.4.0

- Added SoundHelix-style random song-title generation when the title field is blank.
- Added optional per-instrument loudness normalization with target velocity and strength controls.
- Added optional WAV rendering via a built-in lightweight synth.
- Added optional MP3 export through ffmpeg when available.
- Added per-track instrument dropdowns using General MIDI names.
- Added Options tab with theme selection: Dark, Light, Hell, Matrix, Ocean and Avatar.
- Added English/German GUI language switching and tooltips for important controls.
- Added more genre presets: Synthwave, House, Drum and Bass, Ambient, Matrix/Cyber, Funk, LoFi and Orchestral.
- Added CLI flags: `--normalize`, `--render-wav`, `--render-mp3`.
- Updated package version to 0.4.0.

## v0.2.0

- Initial PyQt6 GPLv3 PythonSoundHelix version.
- Added MIDI export, presets, XML inspector, history/rating memory, JSON project/result export and chord sheets.
