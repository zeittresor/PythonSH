# PythonSoundHelix project origin: https://github.com/zeittresor
# PythonSoundHelix package - GPLv3.
__version__ = "0.4.12"
