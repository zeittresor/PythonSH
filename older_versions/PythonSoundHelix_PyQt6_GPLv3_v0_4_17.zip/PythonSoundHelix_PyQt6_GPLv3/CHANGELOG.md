# Changelog

## v0.4.17

- Added `update.bat` to refresh the local offline wheelhouse and download optional helper tools.
- Added app-local optional-tool layout under `tools/` and `env_windows.bat`; the global Windows PATH is not modified.
- `install_windows.bat` now prefers `wheelhouse/` for offline installation and falls back to online pip only if needed.
- Added bundled Windows x64 / CPython 3.12 wheels for PyQt6, PyQt6-Qt6, PyQt6-sip and numpy.
- Added `scripts/update_optional_tools.ps1` to download ffmpeg and FluidSynth into app-local folders when online.
- Added `docs/offline_update_and_tools.md`.

## v0.4.15

- Moved audio rendering/playback controls to the Options tab.
- Added selectable MIDI playback modes: system default, internal built-in synth and optional FluidSynth/SoundFont rendering.

## v0.4.14

- Renamed classic melody presets so the preset list no longer uses `Public Domain` or `Traditional` prefixes.
- Renamed matching melody-template labels to cleaner contour names.
- Added **Melody coverage** control, allowing 5-100% of a named contour template to be used.
- Longer classic melody contour tables are now available for Elise, Ode, Canon, Row Boat, Twinkle, Frere Jacques, London Bridge, Mary Lamb, Greensleeves, Scarborough, Amazing Grace, Brahms Lullaby, Blue Danube, Yankee Doodle and Old MacDonald.
- Added CLI option `--melody-coverage`.
- Added `docs/infos_for_llms.md` as the central LLM-facing development note file.
- Removed broad explanatory full-line comments from Python source files.

## v0.4.13

- Changed the first-start/default preset to **Elise Synth**.
- Added a larger classic melody contour preset pack.
- Reworked the Progression selector so the default is **Random progression (style-aware)**.
- Added reusable major, minor, modal, house, techno, jazz/turnaround, ambient and blues/rock progression choices.
- Added support for borrowed/modal roman chord notation such as `bVII`, `bII` and `#iv`.

## v0.4.12

- Added style-aware harmony generation and musical guardrails.
- Added a global arrangement-coherence pass.
- Progression names became more musical and less raw/internal.

## v0.4.11

- Added explicit About-dialog attribution for SoundHelix and PythonSoundHelix.
- Enabled safer default musical hygiene.

## v0.4.10

- Added shared timing-grid lock and strict arpeggio-grid controls.

## v0.4.9

- Added Seed variation control and more seed-sensitive template behavior.

## v0.4.8

- Added Fine Tune tab.

## v0.4.7

- Music preset changes no longer change the GUI theme.
- Improved normalization and rapid-note smoothing.

## v0.4.6

- Cleaned up AlgoMusic naming and added screenshot-informed pattern logic.

## v0.4.5

- Added AlgoMusic-inspired Techno/House presets and Amiga-style pattern concepts.

## v0.4.4

- Reworked Original XML Popcorn Expansion toward the original Java SoundHelix-Popcorn XML/log behavior.

## v0.4.3

- Improved ffmpeg compatibility and warnings.

## v0.4.2

- Added auto octave/range guard and max melody pitch option.

## v0.4.1

- Renamed the main button to Generate Song and improved Render/Play behavior.

## v0.4.0

- Initial expanded PyQt6/GPLv3 PythonSoundHelix release.
