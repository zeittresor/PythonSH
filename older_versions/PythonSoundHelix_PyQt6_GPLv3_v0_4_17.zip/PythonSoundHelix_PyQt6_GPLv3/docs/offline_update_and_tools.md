# Offline update and optional tools

PythonSoundHelix release ZIPs intentionally do **not** bundle Python wheels. The `wheelhouse/` folder is a cache that is filled by `update.bat`.

## Recommended workflow

1. Extract PythonSoundHelix on an online Windows PC.
2. Run `update.bat`.
3. The updater downloads current compatible wheels into `wheelhouse/` and optional helper programs into `tools/`.
4. Copy the complete folder to an offline PC.
5. Run `install_windows.bat` on the offline PC. It installs from `wheelhouse/` first.

This keeps the distributed ZIP smaller and lets the online preparation step fetch newer compatible dependency builds when available.

## Notes

- `install_windows.bat` uses `wheelhouse/` if it contains `.whl` files.
- If `wheelhouse/` is empty, the installer tries online pip installation.
- `update.bat` downloads wheels for the Python/Windows architecture used on the update PC. For best offline reliability, run it with the same Python major/minor version and architecture as the target offline PC.
- Optional tools are stored app-locally and are added to PATH only for PythonSoundHelix via `env_windows.bat`; the global Windows PATH is not modified.

Optional tools:

- `ffmpeg`: MP3 export. WAV export works without it.
- `FluidSynth`: SoundFont-based internal MIDI rendering. No SoundFont is bundled; select your own `.sf2` or `.sf3` in Options.
