@echo off
setlocal
cd /d "%~dp0"
if exist "env_windows.bat" call "env_windows.bat"
echo ============================================================
echo  PythonSoundHelix v0.4.17 - PyQt6 GPLv3 Windows installer
echo ============================================================
where py >nul 2>nul
if %errorlevel%==0 (
    set PY=py -3
) else (
    set PY=python
)
%PY% --version
if errorlevel 1 (
    echo [ERROR] Python 3 was not found. Install Python 3.10+ first.
    pause
    exit /b 1
)
if not exist ".venv" (
    echo [1/3] Creating local virtual environment...
    %PY% -m venv .venv
    if errorlevel 1 goto fail
) else (
    echo [1/3] Local virtual environment exists.
)
echo [2/3] Checking local wheelhouse cache...
set WHEELHOUSE=%CD%\wheelhouse
set HAVE_WHEELHOUSE=0
if exist "%WHEELHOUSE%\*.whl" set HAVE_WHEELHOUSE=1
if "%HAVE_WHEELHOUSE%"=="1" (
    echo [3/3] Installing requirements from local wheelhouse...
    ".venv\Scripts\python.exe" -m pip install --no-index --find-links="%WHEELHOUSE%" -r requirements.txt
    if errorlevel 1 (
        echo [WARN] Local wheelhouse install failed. Trying online installation...
        ".venv\Scripts\python.exe" -m pip install -r requirements.txt
        if errorlevel 1 goto fail
    )
) else (
    echo [3/3] No populated local wheelhouse found.
    echo       Trying online installation. For offline PCs, run update.bat once on an online PC first.
    ".venv\Scripts\python.exe" -m pip install -r requirements.txt
    if errorlevel 1 goto fail
)
echo.
echo [OK] Installation complete. Start with run_windows.bat
echo.
choice /C YN /N /T 10 /D Y /M "Launch PythonSoundHelix now? [Y/n] "
if errorlevel 2 exit /b 0
call run_windows.bat
exit /b 0
:fail
echo [ERROR] Installation failed.
echo If this PC is offline, run update.bat once on an online PC first, then copy the whole folder including wheelhouse.
pause
exit /b 1
