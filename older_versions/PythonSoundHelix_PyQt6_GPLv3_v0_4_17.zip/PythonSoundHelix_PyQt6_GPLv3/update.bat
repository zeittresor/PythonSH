@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if exist "env_windows.bat" call "env_windows.bat"
echo ============================================================
echo  PythonSoundHelix v0.4.17 - online updater/cache builder
echo ============================================================
echo This updater downloads the local wheelhouse and optional tools.
echo The release ZIP intentionally does NOT bundle Python wheels.
echo.
where py >nul 2>nul
if %errorlevel%==0 (
    set PY=py -3
) else (
    set PY=python
)
%PY% --version
if errorlevel 1 (
    echo [ERROR] Python 3 was not found. Install Python 3.10+ first.
    pause
    exit /b 1
)
if not exist ".venv" (
    echo [1/7] Creating local virtual environment...
    %PY% -m venv .venv
    if errorlevel 1 goto fail
) else (
    echo [1/7] Local virtual environment exists.
)
echo [2/7] Upgrading pip in local virtual environment...
".venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 echo [WARN] Could not upgrade pip. Continuing with existing pip.

echo [3/7] Downloading fresh wheels into temporary wheelhouse...
if exist "wheelhouse_new" rmdir /s /q "wheelhouse_new"
mkdir "wheelhouse_new"
".venv\Scripts\python.exe" -m pip download --only-binary=:all: --dest "wheelhouse_new" -r requirements.txt
if errorlevel 1 (
    echo [WARN] Could not refresh wheelhouse online.
    echo [WARN] Keeping existing wheelhouse unchanged.
    if exist "wheelhouse_new" rmdir /s /q "wheelhouse_new"
) else (
    echo [OK] Fresh wheelhouse downloaded.
    if exist "wheelhouse_old" rmdir /s /q "wheelhouse_old"
    if exist "wheelhouse" rename "wheelhouse" "wheelhouse_old"
    rename "wheelhouse_new" "wheelhouse"
    > "wheelhouse\README.txt" echo Wheelhouse created by PythonSoundHelix update.bat.
    >> "wheelhouse\README.txt" echo This folder contains downloaded wheels for the Python/Windows architecture used during update.
    >> "wheelhouse\README.txt" echo Copy this complete folder with the app for offline installation.
    > "wheelhouse\WHEELHOUSE_MANIFEST.txt" echo PythonSoundHelix v0.4.17 generated wheelhouse
    >> "wheelhouse\WHEELHOUSE_MANIFEST.txt" echo Generated on %DATE% %TIME%
    >> "wheelhouse\WHEELHOUSE_MANIFEST.txt" echo Python:
    ".venv\Scripts\python.exe" --version >> "wheelhouse\WHEELHOUSE_MANIFEST.txt" 2>&1
    >> "wheelhouse\WHEELHOUSE_MANIFEST.txt" echo.
    >> "wheelhouse\WHEELHOUSE_MANIFEST.txt" echo Wheels:
    for %%F in ("wheelhouse\*.whl") do echo %%~nxF>> "wheelhouse\WHEELHOUSE_MANIFEST.txt"
    if exist "wheelhouse_old" rmdir /s /q "wheelhouse_old"
)

echo [4/7] Installing application requirements...
set WHEELHOUSE=%CD%\wheelhouse
set HAVE_WHEELHOUSE=0
if exist "%WHEELHOUSE%\*.whl" set HAVE_WHEELHOUSE=1
if "%HAVE_WHEELHOUSE%"=="1" (
    echo Installing from local wheelhouse first...
    ".venv\Scripts\python.exe" -m pip install --no-index --find-links="%WHEELHOUSE%" -r requirements.txt
    if errorlevel 1 (
        echo [WARN] Wheelhouse install failed. Trying online pip install...
        ".venv\Scripts\python.exe" -m pip install -r requirements.txt
        if errorlevel 1 goto fail
    )
) else (
    echo No populated wheelhouse found. Trying online pip install...
    ".venv\Scripts\python.exe" -m pip install -r requirements.txt
    if errorlevel 1 goto fail
)

echo [5/7] Downloading/updating optional tools: ffmpeg and FluidSynth...
if exist "scripts\update_optional_tools.ps1" (
    powershell -NoProfile -ExecutionPolicy Bypass -File "scripts\update_optional_tools.ps1" -Root "%CD%"
    if errorlevel 1 echo [WARN] Optional tool download failed or was skipped. The app can still run.
) else (
    echo [WARN] scripts\update_optional_tools.ps1 not found. Skipping optional tools.
)

echo [6/7] Writing app-local PATH bootstrap...
if not exist "tools" mkdir "tools"
if not exist "tools\bin" mkdir "tools\bin"
> "env_windows.bat" echo @echo off
>> "env_windows.bat" echo rem App-local PATH bootstrap. Does not modify the global Windows PATH.
>> "env_windows.bat" echo set "PSH_ROOT=%%~dp0"
>> "env_windows.bat" echo if exist "%%PSH_ROOT%%tools\bin" set "PATH=%%PSH_ROOT%%tools\bin;%%PATH%%"
>> "env_windows.bat" echo if exist "%%PSH_ROOT%%tools\ffmpeg\bin" set "PATH=%%PSH_ROOT%%tools\ffmpeg\bin;%%PATH%%"
>> "env_windows.bat" echo if exist "%%PSH_ROOT%%tools\fluidsynth\bin" set "PATH=%%PSH_ROOT%%tools\fluidsynth\bin;%%PATH%%"
>> "env_windows.bat" echo for /f "delims=" %%%%F in ^('dir /b /s "%%PSH_ROOT%%tools\ffmpeg.exe" 2^^^>nul'^) do set "PATH=%%%%~dpF;%%PATH%%"
>> "env_windows.bat" echo for /f "delims=" %%%%F in ^('dir /b /s "%%PSH_ROOT%%tools\ffprobe.exe" 2^^^>nul'^) do set "PATH=%%%%~dpF;%%PATH%%"
>> "env_windows.bat" echo for /f "delims=" %%%%F in ^('dir /b /s "%%PSH_ROOT%%tools\fluidsynth.exe" 2^^^>nul'^) do set "PATH=%%%%~dpF;%%PATH%%"

echo [7/7] Verifying local tools and cache...
call env_windows.bat
if exist "wheelhouse\*.whl" (echo [OK] wheelhouse is populated.) else (echo [INFO] wheelhouse is empty.)
where ffmpeg >nul 2>nul && echo [OK] ffmpeg found. || echo [INFO] ffmpeg not found; MP3 export will fall back to WAV.
where fluidsynth >nul 2>nul && echo [OK] FluidSynth found. || echo [INFO] FluidSynth not found; SoundFont playback requires manual install or a successful update run.
echo.
echo [OK] Update complete.
echo To prepare an offline copy, run this updater once online and then copy the whole folder including wheelhouse\ and tools\.
pause
exit /b 0
:fail
echo [ERROR] Update failed.
echo If the PC is offline and wheelhouse is empty, run update.bat once on an online PC first.
pause
exit /b 1
