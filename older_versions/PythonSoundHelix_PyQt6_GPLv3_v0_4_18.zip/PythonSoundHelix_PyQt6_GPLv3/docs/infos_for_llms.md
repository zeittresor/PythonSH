# infos_for_llms.md

Purpose: compact development context for future LLM-assisted work on PythonSoundHelix. Keep broad rationale here instead of scattering explanatory comments through Python source files.

Project identity:
- PythonSoundHelix is GPLv3.
- Original SoundHelix is by Thomas Schürger / Thomas Schuerger and is a Java/XML algorithmic random-music framework.
- PythonSoundHelix is an independent Python/PyQt6 project inspired by SoundHelix and associated with https://github.com/zeittresor. Current updater target: https://github.com/zeittresor/PythonSH.
- Do not imply that Thomas Schürger authored PythonSoundHelix.

Naming policy:
- Preset display names should be clean musical names. Avoid legal/status prefixes such as Public Domain or Traditional in preset names.
- Legal/source context for classic melody contours may live in documentation/resources, not in the preset dropdown.
- Progression labels should be generic musical labels, not song-specific marketing labels.

Generator goals:
- Defaults should produce coherent, pleasant, non-frantic songs.
- Different seeds should audibly change melody/pattern order while preserving musical structure.
- Bass/chords/melody are the backbone. Arp/counter/texture should support, not dominate.
- High-BPM styles need strong grid lock, low humanize ticks, reduced arp rates and busy-track calming.
- Normalize must account for density/energy, not only velocity.
- A named melody template may use melody_coverage percent; 25% means only the opening contour, 100% means the full available contour can cycle through the arrangement.

SoundHelix / AlgoMusic notes:
- SoundHelix Popcorn compatibility uses the original-style Am/G/F/C/Em/D harmony duration pattern and a 36-section activity matrix derived from the supplied console log.
- AlgoMusic was an Amiga-era algorithmic music program by the same author as SoundHelix. Use it as historical inspiration for tracker-like rows and Techno/House structure.
- MUI is an Amiga GUI toolkit/context, not a music genre. Use MUI only as UI/theme naming.

Code hygiene:
- Keep Python source comments sparse.
- Put project memory, source references, TODOs and long rationale here.
- Preserve necessary type-checker pragmas such as inline # type: ignore when needed.


## v0.4.15 playback architecture note

The Generate tab should stay focused on generation and MIDI output. Audio rendering is an option/workflow detail and belongs under Options. MIDI playback has three user-facing modes: system default player, internal built-in synth, and internal SoundFont/FluidSynth. Do not bundle third-party SoundFonts. Let the user pick `.sf2`/`.sf3` files. FluidSynth is optional and detected via PATH.


## v0.4.18 offline/update workflow note

The app should remain copyable/offline-friendly. `wheelhouse/` is the preferred offline install source. `install_windows.bat` must try local wheels first and only then online pip. `update.bat` is the online refresh step: it downloads matching wheels for the current Windows Python and optional helper programs into app-local folders. Do not globally modify Windows PATH; use `env_windows.bat` so ffmpeg/FluidSynth are visible only to PythonSoundHelix sessions. Do not bundle SoundFonts unless licensing is explicitly verified; let the user choose `.sf2`/`.sf3`.


## v0.4.18 wheelhouse policy note

Do not bundle `.whl` files in normal source ZIP releases. Keep `wheelhouse/` as an initially empty cache with documentation only. `update.bat` is the online preparation step and should download current compatible wheels into `wheelhouse/`, plus optional helper tools such as ffmpeg and FluidSynth into `tools/`. `install_windows.bat` should install from `wheelhouse/` first when populated, otherwise fall back to online pip. For an offline copy, the user runs `update.bat` once on an online PC and then copies the entire folder.


## v0.4.18 installer/updater behavior note

`install_windows.bat` should ask whether `update.bat` should run first and default to Yes after 10 seconds. It should also default to launching the app after 10 seconds. `update.bat` should check https://github.com/zeittresor/PythonSH for project updates, then refresh `wheelhouse/`, then update optional app-local tools. Preserve runtime/user folders when applying GitHub ZIP updates: `.venv`, `wheelhouse`, `tools`, `output`, `app_data`, `.update_cache`. Use colored console status output for important installer/updater steps.
