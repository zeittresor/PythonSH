@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if exist "env_windows.bat" call "env_windows.bat"
goto main

:c
set "PSH_COLOR=%~1"
set "PSH_TEXT=%~2"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Write-Host $env:PSH_TEXT -ForegroundColor $env:PSH_COLOR" 2>nul
if errorlevel 1 echo %~2
exit /b 0

:main
call :c Cyan "============================================================"
call :c Cyan " PythonSoundHelix v0.4.18 - PyQt6 GPLv3 Windows installer"
call :c Cyan "============================================================"
call :c Yellow "This installer can run update.bat first to refresh project files, wheelhouse and optional tools."
choice /C YN /N /T 10 /D Y /M "Run update.bat first? Auto-yes in 10 seconds. [Y/n] "
if errorlevel 2 (
    call :c Yellow "[INFO] Skipping update step."
) else (
    call :c Cyan "[UPDATE] Running app-local updater now..."
    call update.bat --from-installer
    if errorlevel 1 (
        call :c Yellow "[WARN] update.bat reported a problem. Continuing with local installation attempt."
    ) else (
        call :c Green "[OK] Update step completed."
    )
)

where py >nul 2>nul
if %errorlevel%==0 (
    set PY=py -3
) else (
    set PY=python
)
call :c Cyan "[PYTHON] Checking Python runtime..."
%PY% --version
if errorlevel 1 (
    call :c Red "[ERROR] Python 3 was not found. Install Python 3.10+ first."
    pause
    exit /b 1
)
if not exist ".venv" (
    call :c Cyan "[1/3] Creating local virtual environment..."
    %PY% -m venv .venv
    if errorlevel 1 goto fail
) else (
    call :c Green "[1/3] Local virtual environment exists."
)
call :c Cyan "[2/3] Checking local wheelhouse cache..."
set WHEELHOUSE=%CD%\wheelhouse
set HAVE_WHEELHOUSE=0
if exist "%WHEELHOUSE%\*.whl" set HAVE_WHEELHOUSE=1
if "%HAVE_WHEELHOUSE%"=="1" (
    call :c Cyan "[3/3] Installing requirements from local wheelhouse..."
    ".venv\Scripts\python.exe" -m pip install --no-index --find-links="%WHEELHOUSE%" -r requirements.txt
    if errorlevel 1 (
        call :c Yellow "[WARN] Local wheelhouse install failed. Trying online installation..."
        ".venv\Scripts\python.exe" -m pip install -r requirements.txt
        if errorlevel 1 goto fail
    )
) else (
    call :c Yellow "[3/3] No populated local wheelhouse found."
    call :c Yellow "      Trying online installation. For offline PCs, run update.bat once on an online PC first."
    ".venv\Scripts\python.exe" -m pip install -r requirements.txt
    if errorlevel 1 goto fail
)
echo.
call :c Green "[OK] Installation complete. Start with run_windows.bat"
echo.
choice /C YN /N /T 10 /D Y /M "Launch PythonSoundHelix now? Auto-yes in 10 seconds. [Y/n] "
if errorlevel 2 exit /b 0
call run_windows.bat
exit /b 0

:fail
call :c Red "[ERROR] Installation failed."
call :c Yellow "If this PC is offline, run update.bat once on an online PC first, then copy the whole folder including wheelhouse."
pause
exit /b 1
