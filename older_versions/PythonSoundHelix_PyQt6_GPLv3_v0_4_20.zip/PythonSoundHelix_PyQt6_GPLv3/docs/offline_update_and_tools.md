# Offline update and optional tools

PythonSoundHelix release ZIPs intentionally do **not** bundle Python wheels. The `wheelhouse/` folder is a cache that is filled by `update.bat`.

## Recommended workflow

1. Extract PythonSoundHelix on an online Windows PC.
2. Run `update.bat`.
3. The updater checks `https://github.com/zeittresor/PythonSH` for newer project files.
4. The updater downloads current compatible wheels into `wheelhouse/` and optional helper programs into `tools/`.
5. Copy the complete folder to an offline PC.
6. Run `install_windows.bat` on the offline PC. It installs from `wheelhouse/` first.

This keeps the distributed ZIP smaller and lets the online preparation step fetch newer compatible dependency builds when available.

## Notes

- `install_windows.bat` uses `wheelhouse/` if it contains `.whl` files.
- If `wheelhouse/` is empty, the installer tries online pip installation.
- `update.bat` downloads wheels for the Python/Windows architecture used on the update PC. For best offline reliability, run it with the same Python major/minor version and architecture as the target offline PC.
- Optional tools are stored app-locally and are added to PATH only for PythonSoundHelix via `env_windows.bat`; the global Windows PATH is not modified.

Optional tools:

- `ffmpeg`: MP3 export. WAV export works without it.
- `FluidSynth`: SoundFont-based internal MIDI rendering. No SoundFont is bundled; select your own `.sf2` or `.sf3` in Options.

## Installer countdown behavior

`install_windows.bat` asks whether it should run `update.bat` first. The default answer is Yes after 10 seconds. The final app launch prompt also defaults to Yes after 10 seconds.

## Project self-update behavior

`update.bat` calls `scripts/update_project_from_github.ps1`. If the folder is a Git checkout, the script attempts a safe `git fetch` / `git pull --ff-only`. If it is a ZIP/extracted copy, it downloads the current repository ZIP and copies project files into place while preserving runtime/user folders such as `.venv`, `wheelhouse`, `tools`, `output` and `app_data`. If GitHub or the network is unavailable, the updater keeps the local copy and continues with dependency/tool update attempts.

## Installer preflight check

Since v0.4.20, `install_windows.bat` runs a status-only check before offering `update.bat`. If the project revision marker, wheelhouse and optional tools already look current, no update prompt is shown; only the normal application launch question remains.

## v0.4.20 update-status behavior

The installer should only offer `update.bat` when `scripts/check_update_status.ps1` reports missing/outdated project files, wheelhouse data or optional tools. If status is current, it skips the update prompt and continues directly to install/start handling.
