param(
    [string]$Root = (Resolve-Path ".").Path,
    [string]$RepoOwner = "zeittresor",
    [string]$RepoName = "PythonSH"
)

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

function Write-Step($Text) { Write-Host $Text -ForegroundColor Cyan }
function Write-Ok($Text) { Write-Host $Text -ForegroundColor Green }
function Write-Warn($Text) { Write-Host $Text -ForegroundColor Yellow }
function Add-Reason([System.Collections.Generic.List[string]]$List, [string]$Text) {
    if ($Text -and -not $List.Contains($Text)) { [void]$List.Add($Text) }
}
function Save-Status([string]$RootPath, [bool]$Needed, [string]$Reason, [string]$Details) {
    $cacheDir = Join-Path $RootPath ".update_cache"
    New-Item -ItemType Directory -Force -Path $cacheDir | Out-Null
    $statusPath = Join-Path $cacheDir "update_status.cmd"
    $safeReason = ($Reason -replace '[&|<>^]', ' ')
    $safeDetails = ($Details -replace '[&|<>^]', ' ')
    $neededText = if ($Needed) { "1" } else { "0" }
    $lines = @(
        "@echo off",
        "set PSH_UPDATE_NEEDED=$neededText",
        "set PSH_UPDATE_REASON=$safeReason",
        "set PSH_UPDATE_DETAILS=$safeDetails"
    )
    Set-Content -Path $statusPath -Value $lines -Encoding ASCII
}

try {
    $rootPath = (Resolve-Path $Root).Path
    $reasons = [System.Collections.Generic.List[string]]::new()
    $details = [System.Collections.Generic.List[string]]::new()
    $cacheDir = Join-Path $rootPath ".update_cache"
    New-Item -ItemType Directory -Force -Path $cacheDir | Out-Null

    Write-Step "[STATUS] Checking GitHub project revision..."
    try {
        $repoApi = "https://api.github.com/repos/$RepoOwner/$RepoName"
        $headers = @{ "User-Agent" = "PythonSoundHelix-Installer-Status" }
        $repo = Invoke-RestMethod -Uri $repoApi -Headers $headers -TimeoutSec 12
        $branch = $repo.default_branch
        if (-not $branch) { $branch = "main" }
        $commit = Invoke-RestMethod -Uri "$repoApi/commits/$branch" -Headers $headers -TimeoutSec 12
        $remoteSha = $commit.sha
        if (-not $remoteSha) { throw "Could not read remote commit SHA." }

        $gitDir = Join-Path $rootPath ".git"
        $gitExe = Get-Command git -ErrorAction SilentlyContinue
        if ($gitExe -and (Test-Path $gitDir)) {
            $localSha = (& git -C $rootPath rev-parse HEAD 2>$null).Trim()
            if ($LASTEXITCODE -eq 0 -and $localSha -and ($remoteSha.StartsWith($localSha) -or $localSha.StartsWith($remoteSha))) {
                Write-Ok "[STATUS] Git checkout is already at the checked remote revision."
            } else {
                Add-Reason $reasons "GitHub project update available."
            }
        } else {
            $shaFile = Join-Path $cacheDir "last_remote_sha.txt"
            $localSha = ""
            if (Test-Path $shaFile) { $localSha = (Get-Content $shaFile -ErrorAction SilentlyContinue | Select-Object -First 1) }
            if ($localSha -eq $remoteSha) {
                Write-Ok "[STATUS] Project files match the last downloaded GitHub revision."
            } else {
                if ($localSha) {
                    Add-Reason $reasons "New GitHub project revision available."
                } else {
                    Add-Reason $reasons "No local GitHub revision marker yet."
                }
            }
        }
    } catch {
        Add-Reason $details "GitHub check unavailable; local files will be used."
        Write-Warn "[STATUS] GitHub check unavailable: $($_.Exception.Message)"
    }

    Write-Step "[STATUS] Checking local wheelhouse..."
    $wheelhouse = Join-Path $rootPath "wheelhouse"
    $wheels = @()
    if (Test-Path $wheelhouse) { $wheels = @(Get-ChildItem $wheelhouse -Filter *.whl -File -ErrorAction SilentlyContinue) }
    if ($wheels.Count -gt 0) {
        Write-Ok "[STATUS] wheelhouse contains $($wheels.Count) wheel file(s)."
    } else {
        Add-Reason $reasons "Local wheelhouse is empty."
    }

    Write-Step "[STATUS] Checking optional tools..."
    $ffmpeg = Get-Command ffmpeg -ErrorAction SilentlyContinue
    $fluidsynth = Get-Command fluidsynth -ErrorAction SilentlyContinue
    if ($ffmpeg) { Write-Ok "[STATUS] ffmpeg found." } else { Add-Reason $details "ffmpeg missing; MP3 export may need update.bat." }
    if ($fluidsynth) { Write-Ok "[STATUS] FluidSynth found." } else { Add-Reason $details "FluidSynth missing; SoundFont playback may need update.bat." }
    if (-not $ffmpeg -or -not $fluidsynth) {
        Add-Reason $reasons "Optional audio tools are missing."
    }

    $needed = ($reasons.Count -gt 0)
    if ($needed) {
        $reasonText = ($reasons -join " ")
        $detailText = ($details -join " ")
        Save-Status $rootPath $true $reasonText $detailText
        Write-Warn "[STATUS] Update/download recommended: $reasonText"
        exit 2
    } else {
        $reasonText = "Project cache and required local data look current."
        if ($details.Count -gt 0) { $reasonText = $reasonText + " " + ($details -join " ") }
        Save-Status $rootPath $false $reasonText ""
        Write-Ok "[STATUS] No update/download required."
        exit 0
    }
}
catch {
    $rootPath = (Resolve-Path $Root).Path
    Save-Status $rootPath $false "Status check failed; continuing with local installation." ($_.Exception.Message)
    Write-Warn "[STATUS] Status check failed: $($_.Exception.Message)"
    exit 1
}
