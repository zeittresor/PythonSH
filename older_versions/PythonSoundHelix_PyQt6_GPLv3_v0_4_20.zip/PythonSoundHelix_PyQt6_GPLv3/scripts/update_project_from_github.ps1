param(
    [string]$Root = (Resolve-Path ".").Path,
    [string]$RepoOwner = "zeittresor",
    [string]$RepoName = "PythonSH"
)

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

function Write-Step($Text) { Write-Host $Text -ForegroundColor Cyan }
function Write-Ok($Text) { Write-Host $Text -ForegroundColor Green }
function Write-Warn($Text) { Write-Host $Text -ForegroundColor Yellow }
function Write-Fail($Text) { Write-Host $Text -ForegroundColor Red }

try {
    $rootPath = (Resolve-Path $Root).Path
    $cacheDir = Join-Path $rootPath ".update_cache"
    New-Item -ItemType Directory -Force -Path $cacheDir | Out-Null

    $repoApi = "https://api.github.com/repos/$RepoOwner/$RepoName"
    $headers = @{ "User-Agent" = "PythonSoundHelix-Updater" }

    Write-Step "[GITHUB] Checking $RepoOwner/$RepoName ..."
    $repo = Invoke-RestMethod -Uri $repoApi -Headers $headers -TimeoutSec 20
    $branch = $repo.default_branch
    if (-not $branch) { $branch = "main" }

    $commitApi = "$repoApi/commits/$branch"
    $commit = Invoke-RestMethod -Uri $commitApi -Headers $headers -TimeoutSec 20
    $remoteSha = $commit.sha
    if (-not $remoteSha) { throw "Could not read remote commit SHA." }

    $shaFile = Join-Path $cacheDir "last_remote_sha.txt"
    $localSha = ""
    if (Test-Path $shaFile) { $localSha = (Get-Content $shaFile -ErrorAction SilentlyContinue | Select-Object -First 1) }

    if ($localSha -eq $remoteSha) {
        Write-Ok "[GITHUB] Project files already match the last downloaded GitHub revision."
        exit 0
    }

    $gitExe = Get-Command git -ErrorAction SilentlyContinue
    $gitDir = Join-Path $rootPath ".git"
    if ($gitExe -and (Test-Path $gitDir)) {
        Write-Step "[GITHUB] Git repository detected. Running git fetch/pull."
        & git -C $rootPath remote get-url origin *> $null
        if ($LASTEXITCODE -ne 0) {
            & git -C $rootPath remote add origin "https://github.com/$RepoOwner/$RepoName.git"
        }
        & git -C $rootPath fetch origin $branch
        if ($LASTEXITCODE -ne 0) { throw "git fetch failed." }
        & git -C $rootPath pull --ff-only origin $branch
        if ($LASTEXITCODE -ne 0) { throw "git pull --ff-only failed. Local edits may need manual handling." }
        Set-Content -Path $shaFile -Value $remoteSha -Encoding ASCII
        Write-Ok "[GITHUB] Git project update completed."
        exit 0
    }

    Write-Step "[GITHUB] Non-git copy detected. Downloading latest repository ZIP."
    $zipUrl = "https://github.com/$RepoOwner/$RepoName/archive/refs/heads/$branch.zip"
    $zipPath = Join-Path $cacheDir "${RepoName}_${branch}.zip"
    $extractRoot = Join-Path $cacheDir "extract"
    if (Test-Path $zipPath) { Remove-Item $zipPath -Force }
    if (Test-Path $extractRoot) { Remove-Item $extractRoot -Recurse -Force }

    Invoke-WebRequest -Uri $zipUrl -OutFile $zipPath -Headers $headers -TimeoutSec 90
    Expand-Archive -Path $zipPath -DestinationPath $extractRoot -Force
    $sourceRoot = Get-ChildItem $extractRoot -Directory | Select-Object -First 1
    if (-not $sourceRoot) { throw "Downloaded repository ZIP did not contain a project folder." }

    $preserveNames = @(
        ".git", ".venv", ".update_cache", "wheelhouse", "wheelhouse_new", "wheelhouse_old",
        "tools", "output", "app_data", "logs", "generated", "__pycache__"
    )
    $preserveFiles = @("env_windows.bat")

    Write-Step "[GITHUB] Applying latest project files while preserving runtime/user folders."
    Get-ChildItem $sourceRoot.FullName -Force | ForEach-Object {
        if ($preserveNames -contains $_.Name) { return }
        if ($preserveFiles -contains $_.Name) { return }
        $dest = Join-Path $rootPath $_.Name
        if (Test-Path $dest) { Remove-Item $dest -Recurse -Force }
        Copy-Item $_.FullName $dest -Recurse -Force
    }

    Set-Content -Path $shaFile -Value $remoteSha -Encoding ASCII
    Write-Ok "[GITHUB] Project files updated from GitHub branch '$branch'."
    Write-Warn "[GITHUB] Runtime folders were preserved: .venv, wheelhouse, tools, output, app_data."
    exit 0
}
catch {
    Write-Warn "[GITHUB] Project update skipped/failed: $($_.Exception.Message)"
    exit 1
}
