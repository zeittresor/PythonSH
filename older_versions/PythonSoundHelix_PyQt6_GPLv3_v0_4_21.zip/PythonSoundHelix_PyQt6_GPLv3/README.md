# PythonSoundHelix v0.4.21

PythonSoundHelix is a GPLv3 Python/PyQt6 reimplementation and expansion inspired by the original Java SoundHelix project.

The original SoundHelix project is a Java framework for algorithmic random music composition with XML configuration and MIDI output. This Python version keeps the core ideas—seeded composition, configurable harmony, arrangement engines, sequence-like track roles, random song names and MIDI export—but removes the Java runtime dependency and adds a Windows-focused PyQt6 GUI.

## What is included

- PyQt6 Windows GUI, no tkinter.
- Pure-Python Standard MIDI File writer, no Java required.
- SoundHelix-style deterministic random song titles when the song-title field is left blank.
- First-start/default preset: **Elise Synth**.
- Presets inspired by SoundHelix XML examples, AlgoMusic/Amiga-era ideas, modern styles and classic melody contours.
- Clean preset names such as **Elise Synth**, **Row Boat Round**, **Twinkle Music Box**, **Scarborough Modal** and **Blue Danube Waltz**.
- Melody coverage control for named contour templates: 5-100% of the available contour.
- Editable track table with General MIDI instrument dropdowns.
- Optional loudness normalization with track-energy balancing.
- Auto octave/range guard, shared timing-grid lock, strict arpeggio-grid mode, rapid-note smoothing and musical guardrails.
- Fine Tune tab with global arpeggio-rate and per-track octave, semitone transpose, cents fine-tune and local arpeggio-rate controls.
- Optional WAV rendering through a built-in lightweight synth.
- Optional MP3 rendering when `ffmpeg` is installed and available in `PATH`.
- Options tab with theme switching and English/German GUI language switching.
- Seed control, random seed mode, Seed Variation and rating memory.
- MIDI export plus JSON result/project export and chord-sheet export.
- Original XML inspector tab for bundled GPLv3 SoundHelix XML examples.
- `docs/infos_for_llms.md` for LLM-facing development context.

## Start on Windows

1. Extract the ZIP.
2. Run `install_windows.bat` once.
3. Run `run_windows.bat` afterwards.

Generated MIDI/WAV/MP3 files are written to `output/`.

## Build EXE on Windows

Run:

```bat
compile_windows_nuitka.bat
```

## Command-line generation without GUI

```bat
.venv\Scripts\python.exe PythonSoundHelix.py --nogui --preset "Elise Synth" --random-seed --normalize --render-wav --melody-coverage 100
```

## MP3 export note

WAV export works after the Python dependencies are installed. MP3 export additionally needs `ffmpeg`; `update.bat` can place it app-locally under `tools/`.

## Classic melody contour presets

Classic melody examples are represented as interval-contour templates, not bundled recordings. The **Melody coverage** control determines how much of the available contour is allowed into the generated song.

## Attribution

- The original SoundHelix project is by Thomas Schürger and is available from https://www.soundhelix.com/.
- PythonSoundHelix is an independent Python/PyQt6 reimplementation and expansion inspired by SoundHelix.
- PythonSoundHelix project/update origin: https://github.com/zeittresor/PythonSH. It is associated with https://github.com/zeittresor and is not authored or maintained by Thomas Schürger.
- AlgoMusic 2.4 by Thomas Schürger is referenced as historical Amiga-era inspiration only; no Amiga binary or source code is bundled.

## License

GPLv3. See `COPYING`.

## v0.4.15 playback changes

The main Generate tab now focuses on song generation and MIDI playback. The audio render/play button was moved into Options. MIDI playback can be configured there:

- System default MIDI player: opens `.mid` files with Windows file association, for example VLC.
- Internal built-in synth: renders with PythonSoundHelix' lightweight synth and plays the rendered audio through QtMultimedia when available.
- Internal SoundFont / FluidSynth: renders MIDI through a user-selected `.sf2`/`.sf3` SoundFont using `fluidsynth` from PATH, then plays the WAV internally when possible.

No SoundFont is bundled. The user selects their own `.sf2`/`.sf3` file.


## v0.4.21 project update/offline-cache changes

Release ZIPs do not include bundled Python wheel files. The `wheelhouse/` folder starts as a small documented cache folder. Run `update.bat` on an online Windows PC to check `https://github.com/zeittresor/PythonSH` for project updates, download current compatible wheels and download optional tools. After that, copy the whole folder, including `wheelhouse/` and `tools/`, to an offline PC and run `install_windows.bat`.

`install_windows.bat` asks whether the update step should run first. If no key is pressed for 10 seconds, the update step runs automatically. After installation, launching the app also defaults to Yes after 10 seconds.

## v0.4.21 installer behavior

`install_windows.bat` now performs a stricter preflight check. If the GitHub revision marker, `wheelhouse`, optional tools and local `.venv` imports already look valid, it skips the update/install flow and only asks whether the app should be launched, with the existing 10-second auto-yes countdown.

When `update.bat` is launched from the installer, the installer restarts itself afterwards with `--skip-update-check`. This avoids stale batch-label errors if GitHub self-update replaces the installer file while it is running.
