
from __future__ import annotations

from copy import deepcopy
from pathlib import Path
from typing import Dict, List

from .models import GeneratorSettings, TrackSettings
from .music_theory import GM_PROGRAMS


DEFAULT_PRESET_NAME = "Elise Synth"


def _t(name: str, role: str, channel: int, program_name: str | int, volume: int, pan: int, density: int, complexity: int, activity: int, pattern: str = "auto", octave: int = 0, mute_intro: bool = False, fill_every: int = 8) -> TrackSettings:
    program = program_name if isinstance(program_name, int) else GM_PROGRAMS.get(program_name, 0)
    return TrackSettings(name=name, role=role, channel=channel, program=program, volume=volume, pan=pan, density=density, complexity=complexity, activity=activity, pattern=pattern, octave=octave, mute_in_intro=mute_intro, fill_every=fill_every)


def _base(name: str) -> GeneratorSettings:
    s = GeneratorSettings(preset_name=name, tracks=[])
    s.normalize_velocity = True
    s.musical_guardrails = True
    s.coherence_strength = 84
    s.normalize_target = 82
    s.normalize_strength = 80
    s.timing_grid_lock = True
    s.timing_grid_strength = 96
    s.strict_arpeggio_grid = True
    s.rhythmic_smoothing = True
    s.smoothing_strength = 70
    s.calm_busy_tracks = True
    s.relaxation_strength = 76
    s.global_arpeggio_rate = 85
    s.humanize_ticks = 4
    s.humanize_velocity = 6
    return s


def make_presets() -> Dict[str, GeneratorSettings]:
    presets: Dict[str, GeneratorSettings] = {}

    p = _base("PythonSoundHelix Extended Pop")
    p.description = "Modern pop/electro generator with full band arrangement, motif memory and rating-aware randomization."
    p.bpm = 118; p.bars = 96; p.key = "C"; p.mode = "major"; p.progression = "Random progression (style-aware)"; p.complexity = 58; p.variation = 52; p.swing = 7
    p.tracks = [
        _t("Drum Matrix", "drum", 9, 0, 100, 64, 82, 70, 92, "electro four", fill_every=8),
        _t("Round Bass", "bass", 1, "Synth Bass 1", 92, 50, 78, 55, 88, "sync eighth", octave=-1, mute_intro=True),
        _t("Pulse Chords", "chord", 2, "Electric Piano 2", 82, 38, 70, 55, 82, "stab"),
        _t("Warm Pad", "pad", 3, "Pad 2 (warm)", 70, 74, 55, 35, 95, "long"),
        _t("Lead Motif", "melody", 4, "Lead 2 (sawtooth)", 96, 64, 68, 70, 78, "auto", mute_intro=True),
        _t("Answer Bell", "counter", 5, "Vibraphone", 54, 86, 42, 45, 48, "answer", octave=0, mute_intro=True),
    ]
    presets[p.preset_name] = p

    p = _base("Original XML Popcorn Expansion")
    p.description = "Closer compatibility preset for the original SoundHelix-Popcorn XML/log: 137 BPM, 288 bars, 12 TPB, 36 activity sections and the original Am/G/F/C/Em/D chord pattern. Still Python-native and editable in the GUI."
    p.bpm = 137; p.bars = 288; p.beats_per_bar = 4; p.ticks_per_beat = 12; p.key = "A"; p.mode = "minor"
    p.progression = "SoundHelix legacy harmony A"
    p.harmonic_rhythm = 1; p.section_count = 36
    p.complexity = 62; p.variation = 42; p.swing = 0; p.humanize_ticks = 0; p.humanize_velocity = 6; p.motif_memory = 78; p.accent_strength = 30
    p.melody_template = "Popcorn-style recognizable contour"; p.auto_range_guard = True; p.max_melody_pitch = 84; p.seed_variation_strength = 55
    p.use_rating_memory = False
    p.render_wav = False; p.render_mp3 = False
    p.tracks = [
        _t("base_snare", "drum", 9, 0, 100, 64, 72, 68, 100, "base_snare", fill_every=0),
        _t("clap", "drum", 9, 0, 88, 64, 56, 50, 100, "clap", fill_every=0),
        _t("hihat", "drum", 9, 0, 70, 64, 64, 52, 100, "hihat", fill_every=0),
        _t("bass", "bass", 1, "Synth Bass 2", 92, 48, 70, 48, 100, "eighth", octave=-1),
        _t("chords", "chord", 2, "Drawbar Organ", 76, 38, 52, 44, 100, "stab"),
        _t("accomp", "chord", 3, "Electric Piano 2", 70, 42, 50, 38, 100, "stab"),
        _t("arpeggio", "arpeggio", 4, "Celesta", 56, 82, 70, 60, 100, "updown", octave=0),
        _t("melody", "melody", 5, "Lead 1 (square)", 96, 62, 86, 78, 100, "template", octave=0),
        _t("pad", "pad", 6, "Pad 7 (halo)", 58, 88, 38, 30, 100, "long"),
        _t("string", "pad", 7, "String Ensemble 1", 60, 76, 34, 28, 100, "long"),
    ]
    presets[p.preset_name] = p

    p = _base("PythonSoundHelix Popcorn Expansion")
    p.description = "Shorter, more modern Python expansion of the Popcorn idea with extra tracks and GUI-friendly audio rendering."
    p.bpm = 136; p.bars = 128; p.key = "A"; p.mode = "minor"; p.progression = "SoundHelix legacy harmony A"; p.harmonic_rhythm = 1
    p.complexity = 72; p.variation = 58; p.seed_variation_strength = 82; p.swing = 4; p.melody_template = "Popcorn-style recognizable contour"
    p.tracks = [
        _t("Popcorn Drums Plus", "drum", 9, 0, 104, 64, 88, 82, 95, "electro four", fill_every=4),
        _t("Pop Bass", "bass", 1, "Synth Bass 2", 96, 48, 84, 60, 92, "sync eighth", octave=-1),
        _t("Pluck Hook", "melody", 2, "Lead 1 (square)", 108, 62, 100, 82, 100, "template"),
        _t("Glass Arp", "arpeggio", 3, "Celesta", 58, 80, 62, 58, 70, "updown", octave=0),
        _t("Offbeat Organ", "chord", 4, "Drawbar Organ", 72, 36, 68, 50, 76, "stab"),
        _t("Space Pad", "pad", 5, "Pad 7 (halo)", 62, 94, 45, 38, 88, "long"),
        _t("Noise Spark", "texture", 6, "FX 3 (crystal)", 34, 72, 26, 54, 34, "spark", octave=0),
    ]
    presets[p.preset_name] = p

    p = _base("Ode Electro")
    p.description = "Electro arrangement with a short Ode-to-Joy-style motif transformed by the generator."
    p.bpm = 124; p.bars = 96; p.key = "D"; p.mode = "major"; p.progression = "Major circle: I-vi-ii-V"; p.complexity = 62; p.variation = 58; p.swing = 5; p.melody_template = "Ode-to-Joy contour"; p.melody_coverage = 100
    p.tracks = [
        _t("Ceremony Drums", "drum", 9, 0, 96, 64, 76, 68, 88, "four"),
        _t("Choir Pad", "pad", 1, "Choir Aahs", 76, 62, 52, 36, 94, "long"),
        _t("Classic Lead", "melody", 2, "Lead 3 (calliope)", 96, 72, 86, 65, 92, "template"),
        _t("Piano Chords", "chord", 3, "Bright Acoustic Piano", 82, 44, 68, 50, 84, "block"),
        _t("Cello Bass", "bass", 4, "Cello", 84, 54, 62, 48, 80, "eighth", octave=-1),
        _t("Bell Answer", "counter", 5, "Vibraphone", 52, 92, 34, 44, 45, "answer", octave=0),
    ]
    presets[p.preset_name] = p

    p = _base("Elise Synth")
    p.description = "Minor-key synth piece using a Für-Elise-style interval contour as a seed, not a fixed cover."
    p.bpm = 126; p.bars = 112; p.key = "A"; p.mode = "minor"; p.progression = "Random progression (style-aware)"; p.complexity = 54; p.variation = 54; p.seed_variation_strength = 64; p.global_arpeggio_rate = 62; p.smoothing_strength = 84; p.relaxation_strength = 82; p.swing = 3; p.melody_template = "Fuer-Elise contour"; p.melody_coverage = 100
    p.tracks = [
        _t("Broken Beat", "drum", 9, 0, 92, 64, 74, 78, 86, "broken electro", fill_every=8),
        _t("Left Hand Bass", "bass", 1, "Synth Bass 1", 90, 42, 72, 58, 88, "sync eighth", octave=-1),
        _t("Elise Pluck", "melody", 2, "Clavinet", 94, 68, 86, 78, 92, "template"),
        _t("Dark Arp", "arpeggio", 3, "Harpsichord", 76, 82, 88, 72, 84, "down", octave=0),
        _t("Minor Pad", "pad", 4, "Pad 3 (polysynth)", 66, 78, 48, 36, 90, "long"),
    ]
    presets[p.preset_name] = p

    p = _base("Canon Dream")
    p.description = "Pachelbel-Canon-inspired chord movement with modern arps and pads."
    p.bpm = 110; p.bars = 128; p.key = "D"; p.mode = "major"; p.progression = "Major canon cycle: I-V-vi-iii-IV-I-IV-V"; p.complexity = 55; p.variation = 48; p.swing = 6; p.melody_template = "Canon contour"; p.melody_coverage = 100
    p.tracks = [
        _t("Soft Drum", "drum", 9, 0, 78, 64, 54, 42, 70, "soft four", fill_every=16),
        _t("Canon Bass", "bass", 1, "Fretless Bass", 84, 50, 66, 48, 82, "eighth", octave=-1),
        _t("Glass Canon", "arpeggio", 2, "Vibraphone", 68, 86, 84, 64, 86, "updown", octave=0),
        _t("String Pad", "pad", 3, "String Ensemble 1", 72, 42, 58, 40, 96, "long"),
        _t("Quiet Lead", "melody", 4, "Flute", 76, 70, 52, 48, 54, "template"),
    ]
    presets[p.preset_name] = p

    p = _base("Toccata Drive")
    p.description = "Dark organ/electro drive with a toccata-like contour and heavier drums."
    p.bpm = 142; p.bars = 96; p.key = "D"; p.mode = "minor"; p.progression = "Minor drive: i-VII-VI-V"; p.complexity = 78; p.variation = 72; p.swing = 2; p.melody_template = "Toccata contour"; p.melody_coverage = 100
    p.tracks = [
        _t("Heavy Machine", "drum", 9, 0, 108, 64, 90, 86, 96, "electro four", fill_every=4),
        _t("Pedal Bass", "bass", 1, "Synth Bass 2", 100, 45, 92, 72, 94, "sync eighth", octave=-1),
        _t("Organ Hook", "melody", 2, "Drawbar Organ", 102, 65, 86, 82, 94, "template"),
        _t("Church Stabs", "chord", 3, "Reed Organ", 82, 38, 74, 68, 86, "stab"),
        _t("Dark Halo", "pad", 4, "Pad 7 (halo)", 60, 92, 38, 45, 78, "long"),
    ]
    presets[p.preset_name] = p

    p = _base("Legacy XML Piano Expansion")
    p.description = "Python expansion inspired by the original SoundHelix-Piano XML: piano, arpeggio, melody and bass with richer controls."
    p.bpm = 96; p.bars = 112; p.key = "C"; p.mode = "major"; p.progression = "Random progression (style-aware)"; p.complexity = 48; p.variation = 44; p.swing = 10
    p.tracks = [
        _t("Piano Accomp", "chord", 0, "Acoustic Grand Piano", 90, 48, 66, 44, 86, "block"),
        _t("Piano Arpeggio", "arpeggio", 1, "Bright Acoustic Piano", 78, 82, 76, 54, 76, "updown"),
        _t("Piano Melody", "melody", 2, "Electric Grand Piano", 78, 64, 55, 48, 64, "auto", octave=0, mute_intro=True),
        _t("Upright Bass", "bass", 3, "Acoustic Bass", 74, 52, 55, 38, 70, "eighth", octave=-1),
        _t("Room Pad", "pad", 4, "String Ensemble 2", 52, 75, 28, 24, 60, "long"),
    ]
    presets[p.preset_name] = p

    p = _base("Legacy XML Guitar Expansion")
    p.description = "Python expansion inspired by the original SoundHelix-Guitar XML: strummed guitar, bass and melody."
    p.bpm = 104; p.bars = 96; p.key = "G"; p.mode = "major"; p.progression = "Random progression (style-aware)"; p.complexity = 50; p.variation = 45; p.swing = 12
    p.tracks = [
        _t("Steel Guitar", "chord", 0, "Acoustic Guitar (steel)", 90, 42, 78, 45, 90, "guitar"),
        _t("Clean Lead", "melody", 1, "Electric Guitar (clean)", 78, 68, 45, 48, 56, "auto", mute_intro=True),
        _t("Picked Bass", "bass", 2, "Electric Bass (finger)", 82, 52, 62, 40, 82, "eighth", octave=-1),
        _t("Light Percussion", "drum", 9, 0, 80, 64, 48, 38, 56, "soft four", fill_every=16),
    ]
    presets[p.preset_name] = p

    p = _base("New Arcade Byte Bubbles")
    p.description = "New catchy arcade/electro example with an original hook in the spirit of memorable synthetic novelty melodies."
    p.bpm = 150; p.bars = 96; p.key = "F"; p.mode = "mixolydian"; p.progression = "Mixolydian rock: I-bVII-IV-I"; p.complexity = 74; p.variation = 74; p.swing = 4; p.melody_template = "Original arcade anthem"
    p.tracks = [
        _t("Arcade Drums", "drum", 9, 0, 104, 64, 86, 82, 94, "electro four", fill_every=4),
        _t("Bubble Bass", "bass", 1, "Synth Bass 1", 98, 42, 88, 70, 92, "sync eighth", octave=-1),
        _t("Byte Hook", "melody", 2, "Lead 1 (square)", 104, 66, 94, 86, 100, "template"),
        _t("Coin Arp", "arpeggio", 3, "Tinkle Bell", 66, 84, 84, 76, 82, "updown", octave=0),
        _t("Chip Chords", "chord", 4, "Lead 8 (bass + lead)", 72, 34, 70, 55, 74, "stab"),
        _t("Pixel Dust", "texture", 5, "FX 3 (crystal)", 40, 90, 36, 65, 42, "spark", octave=0),
    ]
    presets[p.preset_name] = p


    p = _base("Synthwave Night Drive")
    p.description = "Wide synthwave preset with sidechain-like pulse chords, steady electronic drums and a neon lead contour."
    p.bpm = 112; p.bars = 128; p.key = "C"; p.mode = "minor"; p.progression = "Random progression (style-aware)"; p.complexity = 62; p.variation = 60; p.swing = 3
    p.tracks = [
        _t("Retro Drums", "drum", 9, 0, 98, 64, 78, 70, 90, "electro four", fill_every=8),
        _t("Sub Drive", "bass", 1, "Synth Bass 1", 96, 48, 82, 64, 92, "sync eighth", octave=-1),
        _t("Sidechain Chords", "chord", 2, "Pad 3 (polysynth)", 78, 38, 72, 55, 86, "stab"),
        _t("Night Pad", "pad", 3, "Pad 2 (warm)", 66, 78, 46, 35, 98, "long"),
        _t("Chrome Lead", "melody", 4, "Lead 2 (sawtooth)", 94, 64, 64, 68, 76, "auto", mute_intro=True),
        _t("Glass Echo", "counter", 5, "Celesta", 50, 90, 38, 45, 45, "answer", octave=0),
    ]
    presets[p.preset_name] = p

    p = _base("House Floor Builder")
    p.description = "Four-on-the-floor dance preset with repeating bass, offbeat harmonic stabs and gradual hook energy."
    p.bpm = 126; p.bars = 128; p.key = "F"; p.mode = "minor"; p.progression = "Random progression (style-aware)"; p.complexity = 60; p.variation = 52; p.swing = 2
    p.tracks = [
        _t("Club Drums", "drum", 9, 0, 108, 64, 92, 78, 98, "electro four", fill_every=4),
        _t("Rubber Bass", "bass", 1, "Synth Bass 2", 98, 50, 88, 66, 96, "sync eighth", octave=-1),
        _t("Piano Stab", "chord", 2, "Electric Piano 2", 86, 40, 78, 58, 90, "stab"),
        _t("Air Pad", "pad", 3, "Pad 1 (new age)", 54, 82, 35, 30, 86, "long"),
        _t("Hook Lead", "melody", 4, "Lead 1 (square)", 84, 64, 58, 62, 62, "auto", mute_intro=True),
    ]
    presets[p.preset_name] = p

    p = _base("Drum and Bass Neon")
    p.description = "Fast broken-beat preset with busy bass movement, glass arps and high-energy fills."
    p.bpm = 172; p.bars = 96; p.key = "E"; p.mode = "minor"; p.progression = "Random progression (style-aware)"; p.complexity = 68; p.variation = 62; p.swing = 1; p.humanize_ticks = 1; p.humanize_velocity = 6; p.timing_grid_lock = True; p.timing_grid_strength = 100; p.strict_arpeggio_grid = True; p.rhythmic_smoothing = True; p.smoothing_strength = 84; p.calm_busy_tracks = True; p.relaxation_strength = 88; p.global_arpeggio_rate = 62
    p.tracks = [
        _t("Break Drums", "drum", 9, 0, 104, 64, 86, 78, 100, "broken electro", fill_every=8),
        _t("Reese-ish Bass", "bass", 1, "Synth Bass 2", 96, 48, 74, 66, 92, "sync eighth", octave=-1),
        _t("Neon Arp", "arpeggio", 2, "Lead 8 (bass + lead)", 62, 82, 58, 58, 70, "updown", octave=0),
        _t("Dark Pad", "pad", 3, "Pad 7 (halo)", 56, 76, 34, 34, 76, "long"),
        _t("Needle Lead", "melody", 4, "Lead 2 (sawtooth)", 74, 62, 46, 58, 58, "auto", mute_intro=True),
    ]
    presets[p.preset_name] = p

    p = _base("Ambient Ocean Pad")
    p.description = "Slow, spacious ambient preset with long pads, light textures and sparse melodic fragments."
    p.bpm = 78; p.bars = 96; p.key = "Bb"; p.mode = "lydian"; p.progression = "Random progression (style-aware)"; p.complexity = 34; p.variation = 46; p.swing = 10
    p.tracks = [
        _t("Soft Tide", "pad", 0, "Pad 1 (new age)", 76, 42, 36, 25, 100, "long"),
        _t("Deep Current", "bass", 1, "Fretless Bass", 58, 52, 35, 25, 50, "eighth", octave=-1),
        _t("Pearl Arp", "arpeggio", 2, "Vibraphone", 44, 88, 40, 45, 42, "updown", octave=0),
        _t("Ocean Spark", "texture", 3, "FX 1 (rain)", 38, 90, 38, 55, 48, "spark", octave=0),
        _t("Lonely Flute", "melody", 4, "Flute", 62, 60, 28, 35, 34, "auto", mute_intro=True),
    ]
    presets[p.preset_name] = p

    p = _base("Matrix Terminal Pulse")
    p.description = "Minimal cyber sequence preset with ticking percussion, repeating bass and crystalline counters."
    p.bpm = 132; p.bars = 96; p.key = "G"; p.mode = "phrygian"; p.progression = "Random progression (style-aware)"; p.complexity = 68; p.variation = 70; p.swing = 1
    p.tracks = [
        _t("Terminal Ticks", "drum", 9, 0, 92, 64, 72, 78, 88, "broken electro", fill_every=8),
        _t("Code Bass", "bass", 1, "Synth Bass 1", 94, 50, 82, 68, 90, "sync eighth", octave=-1),
        _t("Green Arp", "arpeggio", 2, "Kalimba", 70, 84, 86, 72, 86, "updown", octave=0),
        _t("CRT Pad", "pad", 3, "Pad 4 (choir)", 54, 72, 34, 36, 78, "long"),
        _t("Debug Lead", "counter", 4, "Lead 1 (square)", 64, 62, 38, 50, 52, "answer"),
    ]
    presets[p.preset_name] = p

    p = _base("Funky Brass Shuffle")
    p.description = "Upbeat funky preset with swung drums, bass movement, brass stabs and short call/response phrases."
    p.bpm = 108; p.bars = 96; p.key = "Eb"; p.mode = "mixolydian"; p.progression = "Random progression (style-aware)"; p.complexity = 64; p.variation = 68; p.swing = 28
    p.tracks = [
        _t("Shuffle Kit", "drum", 9, 0, 96, 64, 72, 72, 92, "four", fill_every=8),
        _t("Finger Bass", "bass", 1, "Electric Bass (finger)", 94, 46, 82, 62, 90, "eighth", octave=-1),
        _t("Brass Hits", "chord", 2, "Brass Section", 86, 34, 72, 60, 82, "stab"),
        _t("Clav Groove", "arpeggio", 3, "Clavinet", 76, 74, 78, 66, 86, "updown"),
        _t("Sax Reply", "counter", 4, "Alto Sax", 70, 86, 45, 56, 58, "answer"),
    ]
    presets[p.preset_name] = p

    p = _base("LoFi Piano Rain")
    p.description = "Soft lo-fi/chill preset with gentle piano, rounded bass, rain texture and relaxed swing."
    p.bpm = 86; p.bars = 96; p.key = "A"; p.mode = "minor"; p.progression = "Random progression (style-aware)"; p.complexity = 42; p.variation = 45; p.swing = 18
    p.tracks = [
        _t("Dusty Beat", "drum", 9, 0, 70, 64, 48, 44, 70, "soft four", fill_every=16),
        _t("Soft Bass", "bass", 1, "Fretless Bass", 68, 48, 46, 34, 72, "eighth", octave=-1),
        _t("Rain Piano", "chord", 2, "Electric Piano 1", 80, 42, 64, 40, 86, "block"),
        _t("Cassette Pad", "pad", 3, "Pad 2 (warm)", 46, 76, 34, 28, 80, "long"),
        _t("Window Melody", "melody", 4, "Vibraphone", 56, 66, 35, 40, 40, "auto", octave=0, mute_intro=True),
        _t("Rain Noise", "texture", 5, "FX 1 (rain)", 34, 92, 28, 50, 44, "spark", octave=0),
    ]
    presets[p.preset_name] = p

    p = _base("Orchestral Trailer Sketch")
    p.description = "Cinematic sketch preset with strings, brass, low bass and heavy-but-simple percussion."
    p.bpm = 92; p.bars = 80; p.key = "D"; p.mode = "minor"; p.progression = "Random progression (style-aware)"; p.complexity = 58; p.variation = 50; p.swing = 0
    p.tracks = [
        _t("War Drums", "drum", 9, 0, 100, 64, 66, 58, 88, "four", fill_every=8),
        _t("Low Strings", "bass", 1, "Cello", 92, 46, 58, 46, 86, "eighth", octave=-1),
        _t("String Ostinato", "arpeggio", 2, "String Ensemble 1", 82, 72, 78, 64, 82, "updown"),
        _t("Brass Chords", "chord", 3, "Brass Section", 88, 40, 56, 50, 74, "stab"),
        _t("Choir Pad", "pad", 4, "Choir Aahs", 62, 82, 35, 28, 86, "long"),
    ]
    presets[p.preset_name] = p


    p = _base("AlgoMusic Legacy Techno House")
    p.description = "Amiga/AlgoMusic-inspired Techno-House generator: tracker-like pulse, tracker-style algorithmic activity, gated stabs and simple deterministic randomness. Newly written Python logic; no Amiga binary/code is bundled."
    p.bpm = 132; p.bars = 144; p.key = "A"; p.mode = "minor"; p.progression = "Random progression (style-aware)"; p.harmonic_rhythm = 1; p.section_count = 12
    p.complexity = 64; p.variation = 62; p.swing = 2; p.humanize_ticks = 2; p.humanize_velocity = 8; p.motif_memory = 54; p.accent_strength = 52
    p.melody_template = "AlgoMusic tracker pulse"; p.groove_template = "algomusic legacy"; p.normalize_velocity = True; p.normalize_target = 80; p.normalize_strength = 84; p.rhythmic_smoothing = True; p.smoothing_strength = 78; p.calm_busy_tracks = True; p.relaxation_strength = 76; p.global_arpeggio_rate = 72; p.render_wav = True; p.render_mp3 = True
    p.tracks = [
        _t("Classic Kick Snare", "drum", 9, 0, 96, 64, 76, 68, 92, "amiga four", fill_every=8),
        _t("Tracker Hats", "drum", 9, 0, 58, 64, 66, 52, 82, "tracker hats", fill_every=0),
        _t("Algorithmic Bass", "bass", 1, "Synth Bass 1", 88, 46, 72, 62, 86, "acid pulse", octave=-1),
        _t("Legacy Gate Chords", "chord", 2, "Electric Piano 2", 68, 34, 50, 52, 72, "random gate"),
        _t("Tracker Arp", "arpeggio", 3, "Lead 8 (bass + lead)", 58, 82, 58, 58, 66, "tracker arp", octave=0),
        _t("Algo Hook", "melody", 4, "Lead 1 (square)", 74, 62, 52, 58, 62, "template", mute_intro=True),
        _t("Amiga Pad", "pad", 5, "Pad 3 (polysynth)", 58, 88, 40, 34, 74, "long"),
    ]
    presets[p.preset_name] = p

    p = _base("AlgoMusic 040 Acid Jam")
    p.description = "Faster 68040-era acid/techno sketch inspired by AlgoMusic's random Techno/House premise: short gated bass cells, bright tracker arp and sparse robotic counters."
    p.bpm = 148; p.bars = 128; p.key = "C"; p.mode = "phrygian"; p.progression = "Random progression (style-aware)"; p.harmonic_rhythm = 1; p.section_count = 16
    p.complexity = 70; p.variation = 68; p.swing = 1; p.humanize_ticks = 1; p.humanize_velocity = 7; p.motif_memory = 48; p.accent_strength = 58
    p.melody_template = "AlgoMusic random walk"; p.groove_template = "algomusic acid"; p.normalize_velocity = True; p.normalize_target = 81; p.normalize_strength = 84; p.rhythmic_smoothing = True; p.smoothing_strength = 74; p.render_wav = True; p.render_mp3 = True
    p.tracks = [
        _t("040 Machine Kit", "drum", 9, 0, 98, 64, 78, 76, 94, "amiga four", fill_every=8),
        _t("Acid Cell Bass", "bass", 1, "Synth Bass 2", 90, 44, 72, 70, 90, "acid pulse", octave=-1),
        _t("Random Gate Organ", "chord", 2, "Drawbar Organ", 66, 36, 48, 58, 68, "random gate"),
        _t("040 Tracker Arp", "arpeggio", 3, "Clavinet", 58, 84, 58, 64, 72, "tracker arp", octave=0),
        _t("Robot Answer", "counter", 4, "Lead 2 (sawtooth)", 50, 74, 34, 46, 42, "answer"),
        _t("Low CPU Pad", "pad", 5, "Pad 2 (warm)", 48, 92, 30, 30, 62, "long"),
    ]
    presets[p.preset_name] = p

    p = _base("AlgoMusic Ambient House")
    p.description = "Softer Amiga/AlgoMusic-flavored ambient-house preset: random-gated e-piano, low tracker bass, sparse melody and wider pads."
    p.bpm = 116; p.bars = 128; p.key = "D"; p.mode = "dorian"; p.progression = "Random progression (style-aware)"; p.harmonic_rhythm = 2; p.section_count = 10
    p.complexity = 50; p.variation = 68; p.swing = 8; p.humanize_ticks = 5; p.humanize_velocity = 12; p.motif_memory = 58; p.accent_strength = 42
    p.melody_template = "AlgoMusic house chord riff"; p.groove_template = "algomusic mellow"; p.normalize_velocity = True; p.normalize_target = 76; p.normalize_strength = 82; p.rhythmic_smoothing = True; p.smoothing_strength = 62; p.render_wav = True; p.render_mp3 = True
    p.tracks = [
        _t("Mellow 4/4 Kit", "drum", 9, 0, 84, 64, 70, 58, 78, "soft four", fill_every=16),
        _t("Warm Tracker Bass", "bass", 1, "Fretless Bass", 76, 46, 62, 48, 76, "acid pulse", octave=-1),
        _t("Ambient Electric Gate", "chord", 2, "Electric Piano 1", 78, 38, 62, 52, 82, "random gate"),
        _t("Soft Tracker Arp", "arpeggio", 3, "Vibraphone", 56, 84, 54, 46, 52, "tracker arp", octave=0),
        _t("Guide Melody", "melody", 4, "Flute", 66, 64, 40, 44, 44, "template", mute_intro=True),
        _t("Ambient Pad Layer", "pad", 5, "Pad 1 (new age)", 62, 88, 38, 28, 92, "long"),
    ]
    presets[p.preset_name] = p


    p = _base("AlgoMusic Techno Pattern Rows")
    p.description = "Screenshot-informed AlgoMusic-style Techno preset: separate digit/dash melody rows and symbol-based drum rows are selected per bar and recombined into a full song. Newly written Python logic based on the visual pattern concept, not copied Amiga code."
    p.bpm = 138; p.bars = 160; p.key = "A"; p.mode = "minor"; p.progression = "Random progression (style-aware)"; p.harmonic_rhythm = 1; p.section_count = 16
    p.complexity = 66; p.variation = 64; p.swing = 1; p.humanize_ticks = 1; p.humanize_velocity = 7; p.motif_memory = 58; p.accent_strength = 54
    p.melody_template = "AlgoMusic digit progression"; p.groove_template = "algomusic techno rows"; p.normalize_velocity = True; p.normalize_target = 80; p.normalize_strength = 86; p.rhythmic_smoothing = True; p.smoothing_strength = 76; p.render_wav = True; p.render_mp3 = True
    p.tracks = [
        _t("Symbol Row Drums", "drum", 9, 0, 96, 64, 78, 72, 94, "algomusic drums", fill_every=8),
        _t("Tracker Row Hats", "drum", 9, 0, 54, 64, 62, 52, 82, "tracker hats", fill_every=0),
        _t("Row Bass", "bass", 1, "Synth Bass 2", 88, 46, 70, 66, 88, "acid pulse", octave=-1),
        _t("Digit Gate Chords", "chord", 2, "Electric Piano 2", 64, 34, 48, 54, 72, "random gate"),
        _t("Digit Row Lead", "melody", 3, "Lead 1 (square)", 74, 62, 58, 64, 72, "digit progression", mute_intro=True),
        _t("Row Tracker Arp", "arpeggio", 4, "Clavinet", 56, 82, 56, 60, 68, "tracker arp", octave=0),
        _t("Machine Pad", "pad", 5, "Pad 3 (polysynth)", 52, 88, 35, 30, 70, "long"),
    ]
    presets[p.preset_name] = p


    def _add_pd_preset(name: str, description: str, template: str, bpm: int, bars: int, key: str, mode: str, progression: str, style: str = "gentle") -> None:
        p = _base(name)
        p.description = description
        p.bpm = bpm; p.bars = bars; p.key = key; p.mode = mode; p.progression = progression
        p.melody_template = template
        p.seed_variation_strength = 58
        p.complexity = 42 if style in ("gentle", "lullaby", "waltz") else 54
        p.variation = 48 if style in ("gentle", "lullaby", "waltz") else 56
        p.global_arpeggio_rate = 58 if style in ("gentle", "lullaby", "waltz") else 70
        p.smoothing_strength = 82
        p.relaxation_strength = 84
        p.normalize_target = 80
        p.normalize_strength = 84
        if style == "waltz":
            p.beats_per_bar = 3
            p.swing = 6
        elif style == "march":
            p.swing = 1
            p.accent_strength = 64
        elif style == "modal":
            p.swing = 8
            p.accent_strength = 44
        else:
            p.swing = 4
        drum_pattern = "soft four" if style not in ("march", "waltz") else ("four" if style == "march" else "soft four")
        lead_program = {
            "gentle": "Music Box",
            "round": "Celesta",
            "lullaby": "Vibraphone",
            "waltz": "Accordion",
            "modal": "Flute",
            "march": "Piccolo",
            "barn": "Harmonica",
        }.get(style, "Music Box")
        chord_program = "Electric Piano 1" if style not in ("modal", "waltz") else ("Acoustic Guitar (nylon)" if style == "modal" else "Accordion")
        bass_program = "Acoustic Bass" if style in ("modal", "waltz", "barn") else "Fretless Bass"
        p.tracks = [
            _t("Gentle Pulse", "drum", 9, 0, 70 if style in ("gentle", "lullaby") else 82, 64, 40 if style in ("gentle", "lullaby") else 58, 34, 58 if style in ("gentle", "lullaby") else 72, drum_pattern, fill_every=16),
            _t("Root Bass", "bass", 1, bass_program, 72, 48, 46, 34, 68, "eighth", octave=-1, mute_intro=True),
            _t("Harmony Bed", "chord", 2, chord_program, 68, 40, 50, 36, 76, "block" if style in ("gentle", "lullaby", "waltz") else "stab"),
            _t("Lead", "melody", 3, lead_program, 82, 66, 58, 46, 72, "template"),
            _t("Soft Pad", "pad", 4, "Pad 2 (warm)", 48, 82, 28, 22, 72, "long"),
        ]
        if style not in ("lullaby", "gentle"):
            p.tracks.append(_t("Light Counter", "counter", 5, "Vibraphone", 46, 88, 28, 34, 38, "answer", octave=0, mute_intro=True))
        presets[p.preset_name] = p

    _add_pd_preset("Row Boat Round", "Round/canon-style arrangement based on a Row Row Row Your Boat contour.", "Row Boat round", 112, 96, "C", "major", "Pop: I-V-vi-IV", "round")
    _add_pd_preset("Twinkle Music Box", "Music-box arrangement based on the Twinkle/Ah vous dirai-je contour.", "Twinkle music-box contour", 96, 80, "C", "major", "Pop: I-V-vi-IV", "gentle")
    _add_pd_preset("Frere Jacques Round", "Round/canon generator preset based on a Frere Jacques/Bruder Jakob contour.", "Frere Jacques round", 108, 96, "F", "major", "Pop: I-vi-IV-V", "round")
    _add_pd_preset("London Bridge Toy", "Toy-synth arrangement using a London Bridge contour.", "London Bridge contour", 118, 80, "G", "major", "Pop: I-V-vi-IV", "gentle")
    _add_pd_preset("Mary Lamb Bells", "Bell lead using a Mary Had a Little Lamb contour.", "Mary Lamb contour", 104, 80, "C", "major", "Pop: I-vi-IV-V", "gentle")
    _add_pd_preset("Greensleeves Dream", "Modal pad/folk arrangement based on a Greensleeves-style contour.", "Greensleeves air", 86, 112, "A", "minor", "Minor cinematic: i-VI-III-VII", "modal")
    _add_pd_preset("Scarborough Modal", "Sparse modal folk-synth preset using a Scarborough-style contour.", "Scarborough modal contour", 92, 112, "D", "dorian", "Minor cinematic: i-VI-III-VII", "modal")
    _add_pd_preset("Amazing Grace Pad", "Slow hymn-like pad arrangement based on a Amazing Grace contour.", "Amazing Grace hymn contour", 76, 96, "G", "major", "Pop: I-V-vi-IV", "lullaby")
    _add_pd_preset("Brahms Lullaby Synth", "Very soft lullaby arrangement based on a Brahms-lullaby-style contour.", "Brahms Lullaby contour", 72, 80, "Eb", "major", "Pop: I-vi-IV-V", "lullaby")
    _add_pd_preset("Blue Danube Waltz", "3/4 waltz preset based on a Blue-Danube-style contour.", "Blue Danube waltz contour", 132, 96, "D", "major", "Pop: I-V-vi-IV", "waltz")
    _add_pd_preset("Yankee Doodle March", "Small march/toy-band preset using a Yankee Doodle contour.", "Yankee Doodle march contour", 128, 96, "C", "major", "Pop: I-V-vi-IV", "march")
    _add_pd_preset("Old MacDonald Barn Dance", "Playful barn-dance arrangement based on a Old MacDonald contour.", "Old MacDonald barn contour", 116, 80, "G", "major", "Pop: I-vi-IV-V", "barn")


    def _add_classic_preset(name: str, description: str, template: str, bpm: int, bars: int, key: str, mode: str, progression: str, style: str = "gentle") -> None:
        p = _base(name)
        p.description = description
        p.bpm = bpm; p.bars = bars; p.key = key; p.mode = mode; p.progression = progression
        p.melody_template = template; p.melody_coverage = 100
        p.seed_variation_strength = 56
        p.complexity = 38 if style in ("gentle", "lullaby") else 56
        p.variation = 44 if style in ("gentle", "lullaby") else 58
        p.global_arpeggio_rate = 52 if style in ("gentle", "lullaby") else 68
        p.smoothing_strength = 84; p.relaxation_strength = 84; p.normalize_target = 80; p.normalize_strength = 86
        if style == "waltz": p.beats_per_bar = 3; p.swing = 5
        elif style == "march": p.swing = 0; p.accent_strength = 66
        elif style == "drive": p.swing = 1; p.accent_strength = 64; p.global_arpeggio_rate = 70
        else: p.swing = 4
        lead_program = {"gentle":"Music Box", "lullaby":"Vibraphone", "folk":"Flute", "march":"Trumpet", "waltz":"Accordion", "drive":"Lead 1 (square)", "chamber":"Violin"}.get(style, "Music Box")
        p.tracks = [
            _t("Soft Pulse", "drum", 9, 0, 66 if style in ("gentle","lullaby","chamber") else 84, 64, 34 if style in ("gentle","lullaby") else 56, 32, 54 if style in ("gentle","lullaby") else 72, "soft four" if style != "march" else "four", fill_every=16),
            _t("Root Bass", "bass", 1, "Fretless Bass", 72, 48, 44, 32, 64, "eighth", octave=-1, mute_intro=True),
            _t("Harmony", "chord", 2, "Electric Piano 1" if style != "chamber" else "String Ensemble 1", 66, 42, 46, 34, 74, "block" if style in ("gentle","lullaby","chamber","waltz") else "stab"),
            _t("Lead", "melody", 3, lead_program, 82, 66, 56, 46, 72, "template"),
            _t("Air Pad", "pad", 4, "Pad 2 (warm)", 46, 82, 24, 20, 70, "long"),
        ]
        if style not in ("lullaby", "gentle"):
            p.tracks.append(_t("Answer", "counter", 5, "Vibraphone", 42, 88, 24, 30, 34, "answer", mute_intro=True))
        presets[p.preset_name] = p

    _add_classic_preset("Silent Night Glass", "Quiet glass-pad version of a well-known Christmas carol contour.", "Silent Night contour", 72, 80, "C", "major", "Random progression (style-aware)", "lullaby")
    _add_classic_preset("Auld Lang Synth", "Warm synth arrangement around an Auld Lang Syne contour.", "Auld Lang Syne contour", 88, 96, "G", "major", "Random progression (style-aware)", "folk")
    _add_classic_preset("Oh Susanna Bounce", "Playful synth-folk bounce using an Oh Susanna contour.", "Oh Susanna contour", 118, 96, "C", "major", "Random progression (style-aware)", "folk")
    _add_classic_preset("Camptown Electro", "Light electro toy-band preset using a Camptown contour.", "Camptown contour", 126, 96, "G", "major", "Random progression (style-aware)", "march")
    _add_classic_preset("Night Music Chamber", "Chamber/synth preset with a Mozart-style night-music contour.", "Night Music contour", 104, 96, "G", "major", "Random progression (style-aware)", "chamber")
    _add_classic_preset("Swan Lake Pad", "Soft minor pad arrangement using a Swan-Lake-style contour.", "Swan Lake contour", 82, 112, "B", "minor", "Random progression (style-aware)", "chamber")
    _add_classic_preset("Spring Sequencer", "Bright sequenced preset inspired by a Vivaldi spring-like contour.", "Spring Vivaldi contour", 128, 96, "E", "major", "Random progression (style-aware)", "drive")
    _add_classic_preset("Mountain King Drive", "Dark accelerating synth-drive preset around a mountain-king-style contour.", "Mountain King contour", 138, 96, "A", "minor", "Random progression (style-aware)", "drive")
    _add_classic_preset("Wedding March Brass", "Ceremonial brass/synth preset using a wedding-march-like contour.", "Wedding March contour", 112, 96, "C", "major", "Random progression (style-aware)", "march")

    def _add_style_preset(name: str, description: str, bpm: int, key: str, mode: str, style: str, lead_template: str = "auto") -> None:
        p = _base(name)
        p.description = description
        p.bpm = bpm; p.bars = 112; p.key = key; p.mode = mode; p.progression = "Random progression (style-aware)"
        p.melody_template = lead_template; p.seed_variation_strength = 72; p.melody_coverage = 100
        p.complexity = 56; p.variation = 66; p.global_arpeggio_rate = 60; p.smoothing_strength = 78; p.relaxation_strength = 82
        if style in ("dub", "reggae"):
            p.swing = 10; drum_pattern = "soft four"; bass_pattern = "sync eighth"; chord_pattern = "stab"; lead_program = "Melodic Tom" if style == "dub" else "Harmonica"
        elif style == "swing":
            p.swing = 18; drum_pattern = "soft four"; bass_pattern = "eighth"; chord_pattern = "stab"; lead_program = "Clarinet"
        elif style == "chiptune":
            p.swing = 0; drum_pattern = "electro four"; bass_pattern = "sync eighth"; chord_pattern = "stab"; lead_program = "Lead 1 (square)"
        elif style == "trance":
            p.swing = 1; drum_pattern = "four"; bass_pattern = "sync eighth"; chord_pattern = "stab"; lead_program = "Lead 2 (sawtooth)"
        else:
            p.swing = 3; drum_pattern = "four"; bass_pattern = "eighth"; chord_pattern = "block"; lead_program = "Lead 2 (sawtooth)"
        p.tracks = [
            _t("Groove", "drum", 9, 0, 86, 64, 58, 54, 78, drum_pattern, fill_every=16),
            _t("Bass", "bass", 1, "Synth Bass 1", 82, 48, 52, 42, 74, bass_pattern, octave=-1, mute_intro=True),
            _t("Chords", "chord", 2, "Electric Piano 2", 68, 38, 48, 38, 72, chord_pattern),
            _t("Lead", "melody", 3, lead_program, 76, 66, 48, 50, 62, "template" if lead_template != "auto" else "auto", mute_intro=True),
            _t("Pad", "pad", 4, "Pad 3 (polysynth)", 48, 84, 26, 24, 72, "long"),
        ]
        if style in ("trance", "chiptune"):
            p.tracks.append(_t("Tamed Arp", "arpeggio", 5, "Clavinet" if style == "chiptune" else "Lead 2 (sawtooth)", 48, 82, 42, 46, 50, "updown", mute_intro=True))
        elif style in ("dub", "reggae", "swing"):
            p.tracks.append(_t("Echo Answer", "counter", 5, "Vibraphone", 38, 86, 22, 30, 34, "answer", mute_intro=True))
        presets[p.preset_name] = p

    _add_style_preset("Dub Echo Chamber", "Sparse dub/echo style with calmer timing and offbeat chords.", 92, "D", "minor", "dub")
    _add_style_preset("Reggae Skank Garden", "Relaxed offbeat skank preset with warm bass and restrained lead.", 86, "G", "major", "reggae")
    _add_style_preset("Electro Swing Parlour", "Swingy electro-jazz toy-parlour preset.", 124, "Bb", "major", "swing", "Electro swing riff")
    _add_style_preset("Chiptune Starfield", "8-bit style pulse preset with square-wave contour and restrained arps.", 132, "C", "major", "chiptune", "Chiptune star motif")
    _add_style_preset("Dream Trance Lift", "Melodic trance-style lift with safer arpeggio defaults.", 134, "A", "minor", "trance")
    _add_style_preset("Piano House Sunrise", "Piano-house preset with softer groove and cleaner sync.", 124, "F", "minor", "house")
    _add_style_preset("Space Ambient Drift", "Slow space ambient generator with lots of air and few attacks.", 74, "E", "minor", "ambient")
    _add_style_preset("Minimal Techno Clockwork", "Minimal techno with stricter grid and fewer competing tonal attacks.", 126, "A", "minor", "techno")

    def _safe_groove_preset(s: GeneratorSettings) -> None:
        """Apply conservative musical hygiene to bundled presets.

        This is deliberately not a genre transformation. It keeps the preset's
        identity while making the default output less frantic: all tonal tracks
        stay on the shared timing grid, very busy channels are calmed, loudness
        normalization is on, and arpeggios are kept in a more listener-friendly
        density range.
        """
        if s.preset_name == "Original XML Popcorn Expansion":
            s.timing_grid_lock = True
            s.timing_grid_strength = max(getattr(s, "timing_grid_strength", 0), 94)
            s.strict_arpeggio_grid = True
            s.rhythmic_smoothing = True
            s.smoothing_strength = max(getattr(s, "smoothing_strength", 0), 56)
            s.calm_busy_tracks = False
            s.normalize_velocity = False
            return
        s.normalize_velocity = True
        s.normalize_target = min(getattr(s, "normalize_target", 82), 84)
        s.normalize_strength = max(getattr(s, "normalize_strength", 0), 78)
        s.timing_grid_lock = True
        s.timing_grid_strength = max(getattr(s, "timing_grid_strength", 0), 96)
        s.strict_arpeggio_grid = True
        s.rhythmic_smoothing = True
        s.smoothing_strength = max(getattr(s, "smoothing_strength", 0), 70)
        s.calm_busy_tracks = True
        s.relaxation_strength = max(getattr(s, "relaxation_strength", 0), 74)
        s.global_arpeggio_rate = min(getattr(s, "global_arpeggio_rate", 100), 85)
        if getattr(s, "bpm", 120) >= 150:
            s.humanize_ticks = min(getattr(s, "humanize_ticks", 4), 2)
            s.swing = min(getattr(s, "swing", 0), 2)
            s.global_arpeggio_rate = min(getattr(s, "global_arpeggio_rate", 85), 70)
            s.relaxation_strength = max(getattr(s, "relaxation_strength", 0), 82)
            s.smoothing_strength = max(getattr(s, "smoothing_strength", 0), 78)
        for t in s.tracks:
            role = (t.role or "").lower()
            if role == "arpeggio":
                t.density = min(t.density, 68)
                t.activity = min(t.activity, 78)
                t.volume = min(t.volume, 68)
                t.arp_rate = min(getattr(t, "arp_rate", 100), 80)
            elif role == "texture":
                t.density = min(t.density, 45)
                t.activity = min(t.activity, 58)
                t.volume = min(t.volume, 46)
            elif role in ("counter",):
                t.density = min(t.density, 48)
                t.activity = min(t.activity, 58)
                t.volume = min(t.volume, 68)
            elif role == "melody":
                t.density = min(t.density, 72)
                t.activity = min(t.activity, 82)
            elif role == "chord":
                t.density = min(t.density, 68)
            elif role == "bass" and getattr(s, "bpm", 120) >= 150:
                t.density = min(t.density, 78)
                t.activity = min(t.activity, 90)
        for t in s.tracks:
            role = (t.role or "").lower()
            if role in ("melody", "counter", "arpeggio", "texture") and getattr(t, "activity", 0) >= 70:
                t.mute_in_intro = True

    for _preset in presets.values():
        _safe_groove_preset(_preset)

    return presets


PRESETS = make_presets()


def get_preset(name: str) -> GeneratorSettings:
    settings = PRESETS.get(name) or PRESETS.get(DEFAULT_PRESET_NAME) or next(iter(PRESETS.values()))
    return GeneratorSettings.from_dict(deepcopy(settings.to_dict()))


def preset_names() -> List[str]:
    names = list(PRESETS.keys())
    if DEFAULT_PRESET_NAME in names:
        names.remove(DEFAULT_PRESET_NAME)
        names.insert(0, DEFAULT_PRESET_NAME)
    return names


def xml_reference_files(base_dir: str | Path) -> List[Path]:
    root = Path(base_dir) / "resources" / "original_soundhelix_examples"
    return sorted(root.glob("*.xml"))
