# infos_for_llms.md

Purpose: compact development context for future LLM-assisted work on PythonSoundHelix. Keep broad rationale here instead of scattering explanatory comments through Python source files.

Project identity:
- PythonSoundHelix is GPLv3.
- Original SoundHelix is by Thomas Schürger / Thomas Schuerger and is a Java/XML algorithmic random-music framework.
- PythonSoundHelix is an independent Python/PyQt6 project inspired by SoundHelix and associated with https://github.com/zeittresor. Current updater target: https://github.com/zeittresor/PythonSH.
- Do not imply that Thomas Schürger authored PythonSoundHelix.

Naming policy:
- Preset display names should be clean musical names. Avoid legal/status prefixes such as Public Domain or Traditional in preset names.
- Legal/source context for classic melody contours may live in documentation/resources, not in the preset dropdown.
- Progression labels should be generic musical labels, not song-specific marketing labels.

Generator goals:
- Defaults should produce coherent, pleasant, non-frantic songs.
- Different seeds should audibly change melody/pattern order while preserving musical structure.
- Bass/chords/melody are the backbone. Arp/counter/texture should support, not dominate.
- High-BPM styles need strong grid lock, low humanize ticks, reduced arp rates and busy-track calming.
- Normalize must account for density/energy, not only velocity.
- A named melody template may use melody_coverage percent; 25% means only the opening contour, 100% means the full available contour can cycle through the arrangement.

SoundHelix / AlgoMusic notes:
- SoundHelix Popcorn compatibility uses the original-style Am/G/F/C/Em/D harmony duration pattern and a 36-section activity matrix derived from the supplied console log.
- AlgoMusic was an Amiga-era algorithmic music program by the same author as SoundHelix. Use it as historical inspiration for tracker-like rows and Techno/House structure.
- MUI is an Amiga GUI toolkit/context, not a music genre. Use MUI only as UI/theme naming.

Code hygiene:
- Keep Python source comments sparse.
- Put project memory, source references, TODOs and long rationale here.
- Preserve necessary type-checker pragmas such as inline # type: ignore when needed.


## v0.4.15 playback architecture note

The Generate tab should stay focused on generation and MIDI output. Audio rendering is an option/workflow detail and belongs under Options. MIDI playback has three user-facing modes: system default player, internal built-in synth, and internal SoundFont/FluidSynth. Do not bundle third-party SoundFonts. Let the user pick `.sf2`/`.sf3` files. FluidSynth is optional and detected via PATH.


## v0.4.23 offline/update workflow note

The app should remain copyable/offline-friendly. `wheelhouse/` is the preferred offline install source. `install_windows.bat` must try local wheels first and only then online pip. `update.bat` is the online refresh step: it downloads matching wheels for the current Windows Python and optional helper programs into app-local folders. Do not globally modify Windows PATH; use `env_windows.bat` so ffmpeg/FluidSynth are visible only to PythonSoundHelix sessions. Do not bundle SoundFonts unless licensing is explicitly verified; let the user choose `.sf2`/`.sf3`.


## v0.4.23 wheelhouse policy note

Do not bundle `.whl` files in normal source ZIP releases. Keep `wheelhouse/` as an initially empty cache with documentation only. `update.bat` is the online preparation step and should download current compatible wheels into `wheelhouse/`, plus optional helper tools such as ffmpeg and FluidSynth into `tools/`. `install_windows.bat` should install from `wheelhouse/` first when populated, otherwise fall back to online pip. For an offline copy, the user runs `update.bat` once on an online PC and then copies the entire folder.


## v0.4.23 installer/updater behavior note

`install_windows.bat` should ask whether `update.bat` should run first and default to Yes after 10 seconds. It should also default to launching the app after 10 seconds. `update.bat` should check https://github.com/zeittresor/PythonSH for project updates, then refresh `wheelhouse/`, then update optional app-local tools. Preserve runtime/user folders when applying GitHub ZIP updates: `.venv`, `wheelhouse`, `tools`, `output`, `app_data`, `.update_cache`. Use colored console status output for important installer/updater steps.

## v0.4.23 installer preflight behavior

The Windows installer should not always ask to run update.bat. It first calls scripts/check_update_status.ps1, which writes .update_cache/update_status.cmd. Only when PSH_UPDATE_NEEDED=1 should install_windows.bat offer update.bat with a 10 second default-yes countdown. If no update/cache/tool download is needed, the installer skips the update prompt and only uses the normal 10 second launch prompt after installation.

## v0.4.23 visualizer and preset expansion

The GUI has a full-screen VisualizerWindow launched from Options. It is intentionally tied to internal playback modes and should not depend on bundled audio analysis; use current song seed to randomize visuals deterministically. New presets should default to conservative musical guardrails and avoid over-busy arps/counter tracks. Installer preflight should skip update prompts when check_update_status.ps1 reports PSH_UPDATE_NEEDED=0.

## v0.4.23 installer/update note

When `install_windows.bat` calls `update.bat`, GitHub self-update may replace the currently running batch file. Do not call batch subroutines after that return. The installer must restart itself with `--skip-update-check` after updater completion, then continue local install/launch. The status checker should only return no-update-needed if `.venv` exists and `import PyQt6, numpy` succeeds, wheelhouse has wheels, optional tools are visible via app-local PATH, and the local GitHub revision marker matches remote.

## v0.4.23 GitHub updater version-gating note

Do not let update.bat blindly overwrite local project files from GitHub. The user specifically observed that a newer extracted ZIP, e.g. v0.4.21+, could be downgraded to an older GitHub snapshot. The updater must compare local project version against remote project version and only apply GitHub project files when the remote version is strictly newer. If the remote version is older or equal, keep local project files but still allow wheelhouse/tool refreshes. Use PROJECT_VERSION.txt and app/__init__.py as local version sources.



## Version-aware updater rule

Before applying project files from GitHub, compare local `docs/version_info.md` / `PROJECT_VERSION.txt` with the remote version. Only apply GitHub project files when the remote version is strictly newer. Do not downgrade a ChatGPT-generated ZIP build with an older GitHub repository snapshot. Wheelhouse and optional tools may still be updated independently.

## v0.4.23 playback / visualizer / coherence note
- Do not reintroduce purely random visualizer motion; the visualizer should consume generated note-event metadata when available.
- Internal playback should prefer WAV over MP3 because QtMultimedia codec support differs between Windows installations.
- Musical Guardrails should keep role-based pitch lanes stable by default; avoid detuning cents automatically unless the user explicitly requests it.
