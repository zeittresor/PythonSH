# PythonSoundHelix Version Info

project_name: PythonSoundHelix
project_origin: https://github.com/zeittresor/PythonSH
version: 0.4.24
release_date_utc: 2026-06-05
package_generation: local_zip_build

## Update rule

The updater must compare this local version against the remote GitHub version before applying project files from GitHub.
A remote GitHub package may only overwrite local project files when the remote version is strictly newer than the local version.
If the local version is newer, the updater must keep the local files and may still update wheelhouse/tools.
If both versions are equal, the updater must not overwrite the local ZIP build automatically unless a force update is requested.

## Rationale

ChatGPT-generated ZIP builds can be newer than the current GitHub repository state. The installer/updater must therefore not assume that GitHub is automatically newer.
This file exists so installer scripts, future LLMs, and maintainers can reliably identify the local package version without parsing UI text.
