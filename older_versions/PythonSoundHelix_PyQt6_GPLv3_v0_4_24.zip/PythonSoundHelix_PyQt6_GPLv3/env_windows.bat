@echo off
rem App-local PATH bootstrap. Does not modify the global Windows PATH.
set "PSH_ROOT=%~dp0"
if exist "%PSH_ROOT%tools\bin" set "PATH=%PSH_ROOT%tools\bin;%PATH%"
if exist "%PSH_ROOT%tools\ffmpeg\bin" set "PATH=%PSH_ROOT%tools\ffmpeg\bin;%PATH%"
if exist "%PSH_ROOT%tools\fluidsynth\bin" set "PATH=%PSH_ROOT%tools\fluidsynth\bin;%PATH%"
for /f "delims=" %%F in ('dir /b /s "%PSH_ROOT%tools\ffmpeg.exe" 2^>nul') do set "PATH=%%~dpF;%PATH%"
for /f "delims=" %%F in ('dir /b /s "%PSH_ROOT%tools\ffprobe.exe" 2^>nul') do set "PATH=%%~dpF;%PATH%"
for /f "delims=" %%F in ('dir /b /s "%PSH_ROOT%tools\fluidsynth.exe" 2^>nul') do set "PATH=%%~dpF;%PATH%"
