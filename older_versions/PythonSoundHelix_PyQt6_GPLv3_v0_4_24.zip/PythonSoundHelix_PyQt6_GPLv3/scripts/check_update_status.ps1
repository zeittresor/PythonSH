param(
    [string]$Root = (Resolve-Path ".").Path,
    [string]$RepoOwner = "zeittresor",
    [string]$RepoName = "PythonSH"
)

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

function Write-Step($Text) { Write-Host $Text -ForegroundColor Cyan }
function Write-Ok($Text) { Write-Host $Text -ForegroundColor Green }
function Write-Warn($Text) { Write-Host $Text -ForegroundColor Yellow }
function Add-Reason([System.Collections.Generic.List[string]]$List, [string]$Text) {
    if ($Text -and -not $List.Contains($Text)) { [void]$List.Add($Text) }
}
function Safe-CmdValue([string]$Value) {
    if (-not $Value) { return "" }
    return ($Value -replace '[&|<>^]', ' ' -replace '[\r\n]+', ' ')
}
function Save-Status([string]$RootPath, [bool]$Needed, [string]$Reason, [string]$Details) {
    $cacheDir = Join-Path $RootPath ".update_cache"
    New-Item -ItemType Directory -Force -Path $cacheDir | Out-Null
    $statusPath = Join-Path $cacheDir "update_status.cmd"
    $neededText = if ($Needed) { "1" } else { "0" }
    $lines = @(
        "@echo off",
        "set PSH_UPDATE_NEEDED=$neededText",
        "set PSH_UPDATE_REASON=$(Safe-CmdValue $Reason)",
        "set PSH_UPDATE_DETAILS=$(Safe-CmdValue $Details)"
    )
    Set-Content -Path $statusPath -Value $lines -Encoding ASCII
}
function Test-VenvPackages([string]$RootPath) {
    $venvPython = Join-Path $RootPath ".venv\Scripts\python.exe"
    if (-not (Test-Path $venvPython)) { return $false }
    & $venvPython -c "import PyQt6, numpy" *> $null
    return ($LASTEXITCODE -eq 0)
}
function Get-VersionFromText([string]$Text) {
    if (-not $Text) { return $null }
    $m = [regex]::Match($Text, '__version__\s*=\s*["'']([^"'']+)["'']')
    if ($m.Success) { return $m.Groups[1].Value.Trim() }
    $m = [regex]::Match($Text, 'PythonSoundHelix\s+v?([0-9]+\.[0-9]+\.[0-9]+)')
    if ($m.Success) { return $m.Groups[1].Value.Trim() }
    $m = [regex]::Match($Text, '^\s*version\s*:\s*v?([0-9]+\.[0-9]+\.[0-9]+)\s*$', [System.Text.RegularExpressions.RegexOptions]::Multiline)
    if ($m.Success) { return $m.Groups[1].Value.Trim() }
    $m = [regex]::Match($Text, '^\s*v?([0-9]+\.[0-9]+\.[0-9]+)\s*$', [System.Text.RegularExpressions.RegexOptions]::Multiline)
    if ($m.Success) { return $m.Groups[1].Value.Trim() }
    return $null
}
function Get-LocalVersion([string]$RootPath) {
    $versionInfo = Join-Path $RootPath "docs\version_info.md"
    if (Test-Path $versionInfo) {
        $txt = Get-Content $versionInfo -Raw -ErrorAction SilentlyContinue
        $v = Get-VersionFromText $txt
        if ($v) { return $v }
    }
    $projectVersion = Join-Path $RootPath "PROJECT_VERSION.txt"
    if (Test-Path $projectVersion) {
        $txt = Get-Content $projectVersion -Raw -ErrorAction SilentlyContinue
        $v = Get-VersionFromText $txt
        if ($v) { return $v }
    }
    $initPath = Join-Path $RootPath "app\__init__.py"
    if (Test-Path $initPath) {
        $txt = Get-Content $initPath -Raw -ErrorAction SilentlyContinue
        $v = Get-VersionFromText $txt
        if ($v) { return $v }
    }
    $readmePath = Join-Path $RootPath "README.md"
    if (Test-Path $readmePath) {
        $txt = Get-Content $readmePath -Raw -ErrorAction SilentlyContinue
        $v = Get-VersionFromText $txt
        if ($v) { return $v }
    }
    return $null
}
function Compare-VersionText([string]$Left, [string]$Right) {
    if (-not $Left -and -not $Right) { return 0 }
    if (-not $Left) { return -1 }
    if (-not $Right) { return 1 }
    try {
        $lv = [version]$Left
        $rv = [version]$Right
        return $lv.CompareTo($rv)
    } catch {
        return [string]::Compare($Left, $Right, $true)
    }
}
function Get-RemoteVersionFromGitHub([string]$RepoApi, [string]$Branch, [hashtable]$Headers) {
    $candidatePaths = @("docs/version_info.md", "PROJECT_VERSION.txt", "app/__init__.py", "README.md")
    foreach ($relativePath in $candidatePaths) {
        try {
            $encodedPath = $relativePath -replace '/', '%2F'
            $contentApi = "$RepoApi/contents/$encodedPath`?ref=$Branch"
            $content = Invoke-RestMethod -Uri $contentApi -Headers $Headers -TimeoutSec 12
            if ($content.content) {
                $rawBytes = [System.Convert]::FromBase64String(($content.content -replace '\s',''))
                $txt = [System.Text.Encoding]::UTF8.GetString($rawBytes)
                $v = Get-VersionFromText $txt
                if ($v) { return $v }
            }
        } catch {
        }
    }
    return $null
}

try {
    $rootPath = (Resolve-Path $Root).Path
    $reasons = [System.Collections.Generic.List[string]]::new()
    $details = [System.Collections.Generic.List[string]]::new()
    $cacheDir = Join-Path $rootPath ".update_cache"
    New-Item -ItemType Directory -Force -Path $cacheDir | Out-Null

    Write-Step "[STATUS] Checking GitHub project version/revision..."
    try {
        $repoApi = "https://api.github.com/repos/$RepoOwner/$RepoName"
        $headers = @{ "User-Agent" = "PythonSoundHelix-Installer-Status" }
        $repo = Invoke-RestMethod -Uri $repoApi -Headers $headers -TimeoutSec 12
        $branch = $repo.default_branch
        if (-not $branch) { $branch = "main" }
        $commit = Invoke-RestMethod -Uri "$repoApi/commits/$branch" -Headers $headers -TimeoutSec 12
        $remoteSha = $commit.sha
        if (-not $remoteSha) { throw "Could not read remote commit SHA." }

        $localVersion = Get-LocalVersion $rootPath
        $remoteVersion = Get-RemoteVersionFromGitHub $repoApi $branch $headers
        if ($localVersion) { Write-Ok "[STATUS] Local project version:  $localVersion" } else { Write-Warn "[STATUS] Local project version unknown." }
        if ($remoteVersion) { Write-Ok "[STATUS] Remote project version: $remoteVersion" } else { Write-Warn "[STATUS] Remote project version unknown." }

        if ($localVersion -and $remoteVersion) {
            $cmp = Compare-VersionText $remoteVersion $localVersion
            if ($cmp -gt 0) {
                Add-Reason $reasons "Newer GitHub project version available: $remoteVersion."
            } elseif ($cmp -eq 0) {
                $shaFile = Join-Path $cacheDir "last_remote_sha.txt"
                $localSha = ""
                if (Test-Path $shaFile) { $localSha = (Get-Content $shaFile -ErrorAction SilentlyContinue | Select-Object -First 1) }
                if ($localSha -eq $remoteSha) {
                    Write-Ok "[STATUS] Same project version and same known GitHub revision."
                } else {
                    Write-Ok "[STATUS] GitHub is not newer than the local package. Project overwrite is not needed."
                    Add-Reason $details "GitHub revision differs but is not a newer version; project files will not be overwritten."
                }
            } else {
                Write-Ok "[STATUS] Local package is newer than GitHub. Project update will be skipped to prevent downgrade."
                Add-Reason $details "GitHub remote version $remoteVersion is older than local version $localVersion."
            }
        } elseif ($localVersion -and -not $remoteVersion) {
            Write-Warn "[STATUS] Remote version unknown. Project overwrite will be skipped for safety."
            Add-Reason $details "Remote project version could not be determined; local files will be kept."
        } elseif (-not $localVersion) {
            Add-Reason $reasons "Local project version marker is missing."
        }
    } catch {
        Add-Reason $details "GitHub check unavailable; local files will be used."
        Write-Warn "[STATUS] GitHub check unavailable: $($_.Exception.Message)"
    }

    Write-Step "[STATUS] Checking local Python environment..."
    if (Test-VenvPackages $rootPath) {
        Write-Ok "[STATUS] Local .venv exists and required Python packages import."
    } else {
        Add-Reason $reasons "Local Python environment is missing or incomplete."
    }

    Write-Step "[STATUS] Checking local wheelhouse..."
    $wheelhouse = Join-Path $rootPath "wheelhouse"
    $wheels = @()
    if (Test-Path $wheelhouse) { $wheels = @(Get-ChildItem $wheelhouse -Filter *.whl -File -ErrorAction SilentlyContinue) }
    if ($wheels.Count -gt 0) {
        Write-Ok "[STATUS] wheelhouse contains $($wheels.Count) wheel file(s)."
    } else {
        Add-Reason $reasons "Local wheelhouse is empty."
    }

    Write-Step "[STATUS] Checking optional tools..."
    $ffmpeg = Get-Command ffmpeg -ErrorAction SilentlyContinue
    $fluidsynth = Get-Command fluidsynth -ErrorAction SilentlyContinue
    if ($ffmpeg) { Write-Ok "[STATUS] ffmpeg found." } else { Add-Reason $details "ffmpeg missing; MP3 export may need update.bat." }
    if ($fluidsynth) { Write-Ok "[STATUS] FluidSynth found." } else { Add-Reason $details "FluidSynth missing; SoundFont playback may need update.bat." }
    if (-not $ffmpeg -or -not $fluidsynth) { Add-Reason $reasons "Optional audio tools are missing." }

    $needed = ($reasons.Count -gt 0)
    if ($needed) {
        $reasonText = ($reasons -join " ")
        $detailText = ($details -join " ")
        Save-Status $rootPath $true $reasonText $detailText
        Write-Warn "[STATUS] Update/download/install recommended: $reasonText"
        exit 2
    } else {
        $reasonText = "Project files, wheelhouse, optional tools and local Python environment look current."
        if ($details.Count -gt 0) { $reasonText = $reasonText + " " + ($details -join " ") }
        Save-Status $rootPath $false $reasonText ""
        Write-Ok "[STATUS] No update/download/install required."
        exit 0
    }
}
catch {
    $rootPath = (Resolve-Path $Root).Path
    Save-Status $rootPath $true "Status check failed; local install check is recommended." ($_.Exception.Message)
    Write-Warn "[STATUS] Status check failed: $($_.Exception.Message)"
    exit 1
}
