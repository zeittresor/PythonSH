param(
    [string]$Root = (Resolve-Path ".").Path
)
$ErrorActionPreference = "Stop"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$tools = Join-Path $Root "tools"
$tmp = Join-Path $Root "_update_tmp"
New-Item -ItemType Directory -Force -Path $tools | Out-Null
New-Item -ItemType Directory -Force -Path $tmp | Out-Null
function Invoke-GitHubJson($url) {
    Invoke-RestMethod -Uri $url -Headers @{"User-Agent"="PythonSoundHelix updater"}
}
function Get-LatestAsset($repo, [string[]]$include, [string[]]$exclude) {
    $release = Invoke-GitHubJson "https://api.github.com/repos/$repo/releases/latest"
    foreach ($pattern in $include) {
        $matches = @($release.assets | Where-Object {
            $asset = $_
            $excluded = $false
            foreach ($ex in $exclude) {
                if ($ex -and $ex.Length -gt 0 -and $asset.name -match $ex) { $excluded = $true }
            }
            ($asset.name -match $pattern) -and (-not $excluded)
        })
        if ($matches.Count -gt 0) { return $matches[0] }
    }
    return $null
}
function Download-Asset($asset, $dest) {
    if (-not $asset) { return $false }
    Write-Host "Downloading $($asset.name)"
    Invoke-WebRequest -Uri $asset.browser_download_url -OutFile $dest -UseBasicParsing -Headers @{"User-Agent"="PythonSoundHelix updater"}
    return $true
}
function Expand-ZipClean($zip, $dest) {
    if (Test-Path $dest) { Remove-Item -Recurse -Force $dest }
    New-Item -ItemType Directory -Force -Path $dest | Out-Null
    Expand-Archive -Path $zip -DestinationPath $dest -Force
}
try {
    Write-Host "[ffmpeg] Looking for latest Windows x64 GPL build..."
    $ffAsset = Get-LatestAsset "BtbN/FFmpeg-Builds" @("ffmpeg.*win64.*gpl.*\.zip$", "win64.*gpl.*\.zip$") @("shared", "debug", "lgpl")
    if ($ffAsset) {
        $ffZip = Join-Path $tmp $ffAsset.name
        if (Download-Asset $ffAsset $ffZip) {
            $ffExtract = Join-Path $tmp "ffmpeg_extract"
            Expand-ZipClean $ffZip $ffExtract
            $ffExe = Get-ChildItem -Path $ffExtract -Filter ffmpeg.exe -Recurse | Select-Object -First 1
            if ($ffExe) {
                $ffBin = Join-Path $tools "ffmpeg\bin"
                New-Item -ItemType Directory -Force -Path $ffBin | Out-Null
                Copy-Item -Path (Join-Path $ffExe.Directory.FullName "*") -Destination $ffBin -Recurse -Force
                Write-Host "[ffmpeg] Installed to $ffBin"
            } else { Write-Warning "ffmpeg.exe not found in archive." }
        }
    } else { Write-Warning "No matching ffmpeg asset found." }
} catch { Write-Warning "ffmpeg update failed: $($_.Exception.Message)" }
try {
    Write-Host "[FluidSynth] Looking for latest Windows x64 build..."
    $fsAsset = Get-LatestAsset "FluidSynth/fluidsynth" @("win.*x64.*\.zip$", "windows.*x64.*\.zip$", "win10.*x64.*\.zip$", "x64.*\.zip$") @("src", "source", "mac", "linux")
    if ($fsAsset) {
        $fsZip = Join-Path $tmp $fsAsset.name
        if (Download-Asset $fsAsset $fsZip) {
            $fsExtract = Join-Path $tmp "fluidsynth_extract"
            Expand-ZipClean $fsZip $fsExtract
            $fsExe = Get-ChildItem -Path $fsExtract -Filter fluidsynth.exe -Recurse | Select-Object -First 1
            if ($fsExe) {
                $fsBin = Join-Path $tools "fluidsynth\bin"
                New-Item -ItemType Directory -Force -Path $fsBin | Out-Null
                Copy-Item -Path (Join-Path $fsExe.Directory.FullName "*") -Destination $fsBin -Recurse -Force
                Write-Host "[FluidSynth] Installed to $fsBin"
            } else { Write-Warning "fluidsynth.exe not found in archive." }
        }
    } else { Write-Warning "No matching FluidSynth Windows x64 ZIP asset found." }
} catch { Write-Warning "FluidSynth update failed: $($_.Exception.Message)" }
try { Remove-Item -Recurse -Force $tmp -ErrorAction SilentlyContinue } catch {}
