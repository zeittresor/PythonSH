param(
    [string]$Root = (Resolve-Path ".").Path,
    [string]$RepoOwner = "zeittresor",
    [string]$RepoName = "PythonSH",
    [switch]$ForceProjectUpdate
)

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

function Write-Step($Text) { Write-Host $Text -ForegroundColor Cyan }
function Write-Ok($Text) { Write-Host $Text -ForegroundColor Green }
function Write-Warn($Text) { Write-Host $Text -ForegroundColor Yellow }

function Get-VersionFromText([string]$Text) {
    if (-not $Text) { return $null }
    $m = [regex]::Match($Text, '__version__\s*=\s*["'']([^"'']+)["'']')
    if ($m.Success) { return $m.Groups[1].Value.Trim() }
    $m = [regex]::Match($Text, 'PythonSoundHelix\s+v?([0-9]+\.[0-9]+\.[0-9]+)')
    if ($m.Success) { return $m.Groups[1].Value.Trim() }
    $m = [regex]::Match($Text, '^\s*version\s*:\s*v?([0-9]+\.[0-9]+\.[0-9]+)\s*$', [System.Text.RegularExpressions.RegexOptions]::Multiline)
    if ($m.Success) { return $m.Groups[1].Value.Trim() }
    $m = [regex]::Match($Text, '^\s*v?([0-9]+\.[0-9]+\.[0-9]+)\s*$', [System.Text.RegularExpressions.RegexOptions]::Multiline)
    if ($m.Success) { return $m.Groups[1].Value.Trim() }
    return $null
}

function Get-LocalVersion([string]$RootPath) {
    $versionInfo = Join-Path $RootPath "docs\version_info.md"
    if (Test-Path $versionInfo) {
        $txt = Get-Content $versionInfo -Raw -ErrorAction SilentlyContinue
        $v = Get-VersionFromText $txt
        if ($v) { return $v }
    }
    $projectVersion = Join-Path $RootPath "PROJECT_VERSION.txt"
    if (Test-Path $projectVersion) {
        $txt = Get-Content $projectVersion -Raw -ErrorAction SilentlyContinue
        $v = Get-VersionFromText $txt
        if ($v) { return $v }
    }
    $initPath = Join-Path $RootPath "app\__init__.py"
    if (Test-Path $initPath) {
        $txt = Get-Content $initPath -Raw -ErrorAction SilentlyContinue
        $v = Get-VersionFromText $txt
        if ($v) { return $v }
    }
    $readmePath = Join-Path $RootPath "README.md"
    if (Test-Path $readmePath) {
        $txt = Get-Content $readmePath -Raw -ErrorAction SilentlyContinue
        $v = Get-VersionFromText $txt
        if ($v) { return $v }
    }
    return $null
}

function Compare-VersionText([string]$Left, [string]$Right) {
    if (-not $Left -and -not $Right) { return 0 }
    if (-not $Left) { return -1 }
    if (-not $Right) { return 1 }
    try {
        $lv = [version]$Left
        $rv = [version]$Right
        return $lv.CompareTo($rv)
    } catch {
        return [string]::Compare($Left, $Right, $true)
    }
}

function Get-RemoteVersionFromGitHub([string]$RepoApi, [string]$Branch, [hashtable]$Headers) {
    $candidatePaths = @("docs/version_info.md", "PROJECT_VERSION.txt", "app/__init__.py", "README.md")
    foreach ($relativePath in $candidatePaths) {
        try {
            $encodedPath = $relativePath -replace '/', '%2F'
            $contentApi = "$RepoApi/contents/$encodedPath`?ref=$Branch"
            $content = Invoke-RestMethod -Uri $contentApi -Headers $Headers -TimeoutSec 20
            if ($content.content) {
                $rawBytes = [System.Convert]::FromBase64String(($content.content -replace '\s',''))
                $txt = [System.Text.Encoding]::UTF8.GetString($rawBytes)
                $v = Get-VersionFromText $txt
                if ($v) { return $v }
            }
        } catch {
        }
    }
    return $null
}

try {
    $rootPath = (Resolve-Path $Root).Path
    $cacheDir = Join-Path $rootPath ".update_cache"
    New-Item -ItemType Directory -Force -Path $cacheDir | Out-Null

    $repoApi = "https://api.github.com/repos/$RepoOwner/$RepoName"
    $headers = @{ "User-Agent" = "PythonSoundHelix-Updater" }

    Write-Step "[GITHUB] Checking $RepoOwner/$RepoName ..."
    $repo = Invoke-RestMethod -Uri $repoApi -Headers $headers -TimeoutSec 20
    $branch = $repo.default_branch
    if (-not $branch) { $branch = "main" }

    $commit = Invoke-RestMethod -Uri "$repoApi/commits/$branch" -Headers $headers -TimeoutSec 20
    $remoteSha = $commit.sha
    if (-not $remoteSha) { throw "Could not read remote commit SHA." }

    $localVersion = Get-LocalVersion $rootPath
    $remoteVersion = Get-RemoteVersionFromGitHub $repoApi $branch $headers

    if ($localVersion) { Write-Ok "[GITHUB] Local project version:  $localVersion" } else { Write-Warn "[GITHUB] Local project version could not be determined." }
    if ($remoteVersion) { Write-Ok "[GITHUB] Remote project version: $remoteVersion" } else { Write-Warn "[GITHUB] Remote project version could not be determined." }

    if (-not $ForceProjectUpdate) {
        if ($localVersion -and $remoteVersion) {
            $cmp = Compare-VersionText $remoteVersion $localVersion
            if ($cmp -lt 0) {
                Write-Warn "[GITHUB] Remote version is older than local. Skipping project file update to prevent downgrade."
                Write-Warn "[GITHUB] Local v$localVersion remains active; remote v$remoteVersion will not be applied."
                exit 0
            }
            if ($cmp -eq 0) {
                $shaFile = Join-Path $cacheDir "last_remote_sha.txt"
                $localSha = ""
                if (Test-Path $shaFile) { $localSha = (Get-Content $shaFile -ErrorAction SilentlyContinue | Select-Object -First 1) }
                if ($localSha -eq $remoteSha) {
                    Write-Ok "[GITHUB] Same version and same known remote revision. No project update needed."
                    exit 0
                }
                Write-Warn "[GITHUB] Remote version equals local version. Skipping automatic project overwrite unless --force-project-update is used."
                Write-Warn "[GITHUB] This avoids replacing a newer ZIP build with a same-version or stale GitHub snapshot."
                exit 0
            }
            Write-Step "[GITHUB] Remote version is newer. Project update is allowed."
        } elseif ($localVersion -and -not $remoteVersion) {
            Write-Warn "[GITHUB] Remote version unknown while local version is known. Skipping project overwrite for safety."
            exit 0
        } elseif (-not $localVersion) {
            Write-Warn "[GITHUB] Local version unknown. Project update is allowed only because no local version marker exists."
        }
    } else {
        Write-Warn "[GITHUB] ForceProjectUpdate was specified. Version downgrade protection is bypassed."
    }

    $shaFile = Join-Path $cacheDir "last_remote_sha.txt"
    $gitExe = Get-Command git -ErrorAction SilentlyContinue
    $gitDir = Join-Path $rootPath ".git"
    if ($gitExe -and (Test-Path $gitDir)) {
        Write-Step "[GITHUB] Git repository detected. Running git fetch/pull."
        & git -C $rootPath remote get-url origin *> $null
        if ($LASTEXITCODE -ne 0) {
            & git -C $rootPath remote add origin "https://github.com/$RepoOwner/$RepoName.git"
        }
        & git -C $rootPath fetch origin $branch
        if ($LASTEXITCODE -ne 0) { throw "git fetch failed." }
        & git -C $rootPath pull --ff-only origin $branch
        if ($LASTEXITCODE -ne 0) { throw "git pull --ff-only failed. Local edits may need manual handling." }
        Set-Content -Path $shaFile -Value $remoteSha -Encoding ASCII
        Write-Ok "[GITHUB] Git project update completed."
        exit 0
    }

    Write-Step "[GITHUB] Non-git copy detected. Downloading newer repository ZIP."
    $zipUrl = "https://github.com/$RepoOwner/$RepoName/archive/refs/heads/$branch.zip"
    $zipPath = Join-Path $cacheDir "${RepoName}_${branch}.zip"
    $extractRoot = Join-Path $cacheDir "extract"
    if (Test-Path $zipPath) { Remove-Item $zipPath -Force }
    if (Test-Path $extractRoot) { Remove-Item $extractRoot -Recurse -Force }

    Invoke-WebRequest -Uri $zipUrl -OutFile $zipPath -Headers $headers -TimeoutSec 90
    Expand-Archive -Path $zipPath -DestinationPath $extractRoot -Force
    $sourceRoot = Get-ChildItem $extractRoot -Directory | Select-Object -First 1
    if (-not $sourceRoot) { throw "Downloaded repository ZIP did not contain a project folder." }

    $preserveNames = @(
        ".git", ".venv", ".update_cache", "wheelhouse", "wheelhouse_new", "wheelhouse_old",
        "tools", "output", "app_data", "logs", "generated", "__pycache__"
    )
    $preserveFiles = @("env_windows.bat")

    Write-Step "[GITHUB] Applying newer project files while preserving runtime/user folders."
    Get-ChildItem $sourceRoot.FullName -Force | ForEach-Object {
        if ($preserveNames -contains $_.Name) { return }
        if ($preserveFiles -contains $_.Name) { return }
        $dest = Join-Path $rootPath $_.Name
        if (Test-Path $dest) { Remove-Item $dest -Recurse -Force }
        Copy-Item $_.FullName $dest -Recurse -Force
    }

    Set-Content -Path $shaFile -Value $remoteSha -Encoding ASCII
    Write-Ok "[GITHUB] Project files updated from GitHub branch '$branch' to version $remoteVersion."
    Write-Warn "[GITHUB] Runtime folders were preserved: .venv, wheelhouse, tools, output, app_data."
    exit 0
}
catch {
    Write-Warn "[GITHUB] Project update skipped/failed: $($_.Exception.Message)"
    exit 1
}
