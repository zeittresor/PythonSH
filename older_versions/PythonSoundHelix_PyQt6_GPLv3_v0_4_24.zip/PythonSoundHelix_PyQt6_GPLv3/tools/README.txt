Optional app-local tools downloaded by update.bat are stored here. This folder is added to PATH only through env_windows.bat.
