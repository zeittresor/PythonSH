@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if exist "env_windows.bat" call "env_windows.bat"
set "FROM_INSTALLER=0"
if /I "%~1"=="--from-installer" set "FROM_INSTALLER=1"
goto main

:c
set "PSH_COLOR=%~1"
set "PSH_TEXT=%~2"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Write-Host $env:PSH_TEXT -ForegroundColor $env:PSH_COLOR" 2>nul
if errorlevel 1 echo %~2
exit /b 0

:main
call :c Cyan "============================================================"
call :c Cyan " PythonSoundHelix v0.4.24 - online updater/cache builder"
call :c Cyan "============================================================"
call :c Yellow "Updates project files from https://github.com/zeittresor/PythonSH when reachable."
call :c Yellow "Builds a local wheelhouse and downloads optional app-local tools."
echo.
where py >nul 2>nul
if %errorlevel%==0 (
    set PY=py -3
) else (
    set PY=python
)
call :c Cyan "[PYTHON] Checking Python runtime..."
%PY% --version
if errorlevel 1 (
    call :c Red "[ERROR] Python 3 was not found. Install Python 3.10+ first."
    if "%FROM_INSTALLER%"=="0" pause
    exit /b 1
)
if not exist ".venv" (
    call :c Cyan "[1/8] Creating local virtual environment..."
    %PY% -m venv .venv
    if errorlevel 1 goto fail
) else (
    call :c Green "[1/8] Local virtual environment exists."
)
call :c Cyan "[2/8] Checking project updates from GitHub..."
if exist "scripts\update_project_from_github.ps1" (
    powershell -NoProfile -ExecutionPolicy Bypass -File "scripts\update_project_from_github.ps1" -Root "%CD%" -RepoOwner "zeittresor" -RepoName "PythonSH"
    if errorlevel 1 (
        call :c Yellow "[WARN] Project self-update failed or was skipped. Continuing with local files."
    ) else (
        call :c Green "[OK] Project update check completed."
    )
) else (
    call :c Yellow "[WARN] scripts\update_project_from_github.ps1 not found. Skipping project update."
)

call :c Cyan "[3/8] Upgrading pip in local virtual environment..."
".venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 call :c Yellow "[WARN] Could not upgrade pip. Continuing with existing pip."

call :c Cyan "[4/8] Downloading fresh wheels into temporary wheelhouse..."
if exist "wheelhouse_new" rmdir /s /q "wheelhouse_new"
mkdir "wheelhouse_new"
".venv\Scripts\python.exe" -m pip download --only-binary=:all: --dest "wheelhouse_new" -r requirements.txt
if errorlevel 1 (
    call :c Yellow "[WARN] Could not refresh wheelhouse online."
    call :c Yellow "[WARN] Keeping existing wheelhouse unchanged."
    if exist "wheelhouse_new" rmdir /s /q "wheelhouse_new"
) else (
    call :c Green "[OK] Fresh wheelhouse downloaded."
    if exist "wheelhouse_old" rmdir /s /q "wheelhouse_old"
    if exist "wheelhouse" rename "wheelhouse" "wheelhouse_old"
    rename "wheelhouse_new" "wheelhouse"
    > "wheelhouse\README.txt" echo Wheelhouse created by PythonSoundHelix update.bat.
    >> "wheelhouse\README.txt" echo This folder contains downloaded wheels for the Python/Windows architecture used during update.
    >> "wheelhouse\README.txt" echo Copy this complete folder with the app for offline installation.
    > "wheelhouse\WHEELHOUSE_MANIFEST.txt" echo PythonSoundHelix v0.4.24 generated wheelhouse
    >> "wheelhouse\WHEELHOUSE_MANIFEST.txt" echo Generated on %DATE% %TIME%
    >> "wheelhouse\WHEELHOUSE_MANIFEST.txt" echo Python:
    ".venv\Scripts\python.exe" --version >> "wheelhouse\WHEELHOUSE_MANIFEST.txt" 2>&1
    >> "wheelhouse\WHEELHOUSE_MANIFEST.txt" echo.
    >> "wheelhouse\WHEELHOUSE_MANIFEST.txt" echo Wheels:
    for %%F in ("wheelhouse\*.whl") do echo %%~nxF>> "wheelhouse\WHEELHOUSE_MANIFEST.txt"
    if exist "wheelhouse_old" rmdir /s /q "wheelhouse_old"
)

call :c Cyan "[5/8] Installing application requirements..."
set WHEELHOUSE=%CD%\wheelhouse
set HAVE_WHEELHOUSE=0
if exist "%WHEELHOUSE%\*.whl" set HAVE_WHEELHOUSE=1
if "%HAVE_WHEELHOUSE%"=="1" (
    call :c Cyan "Installing from local wheelhouse first..."
    ".venv\Scripts\python.exe" -m pip install --no-index --find-links="%WHEELHOUSE%" -r requirements.txt
    if errorlevel 1 (
        call :c Yellow "[WARN] Wheelhouse install failed. Trying online pip install..."
        ".venv\Scripts\python.exe" -m pip install -r requirements.txt
        if errorlevel 1 goto fail
    )
) else (
    call :c Yellow "No populated wheelhouse found. Trying online pip install..."
    ".venv\Scripts\python.exe" -m pip install -r requirements.txt
    if errorlevel 1 goto fail
)

call :c Cyan "[6/8] Downloading/updating optional tools: ffmpeg and FluidSynth..."
if exist "scripts\update_optional_tools.ps1" (
    powershell -NoProfile -ExecutionPolicy Bypass -File "scripts\update_optional_tools.ps1" -Root "%CD%"
    if errorlevel 1 call :c Yellow "[WARN] Optional tool download failed or was skipped. The app can still run."
) else (
    call :c Yellow "[WARN] scripts\update_optional_tools.ps1 not found. Skipping optional tools."
)

call :c Cyan "[7/8] Writing app-local PATH bootstrap..."
if not exist "tools" mkdir "tools"
if not exist "tools\bin" mkdir "tools\bin"
> "env_windows.bat" echo @echo off
>> "env_windows.bat" echo rem App-local PATH bootstrap. Does not modify the global Windows PATH.
>> "env_windows.bat" echo set "PSH_ROOT=%%~dp0"
>> "env_windows.bat" echo if exist "%%PSH_ROOT%%tools\bin" set "PATH=%%PSH_ROOT%%tools\bin;%%PATH%%"
>> "env_windows.bat" echo if exist "%%PSH_ROOT%%tools\ffmpeg\bin" set "PATH=%%PSH_ROOT%%tools\ffmpeg\bin;%%PATH%%"
>> "env_windows.bat" echo if exist "%%PSH_ROOT%%tools\fluidsynth\bin" set "PATH=%%PSH_ROOT%%tools\fluidsynth\bin;%%PATH%%"
>> "env_windows.bat" echo for /f "delims=" %%%%F in ^('dir /b /s "%%PSH_ROOT%%tools\ffmpeg.exe" 2^^^>nul'^) do set "PATH=%%%%~dpF;%%PATH%%"
>> "env_windows.bat" echo for /f "delims=" %%%%F in ^('dir /b /s "%%PSH_ROOT%%tools\ffprobe.exe" 2^^^>nul'^) do set "PATH=%%%%~dpF;%%PATH%%"
>> "env_windows.bat" echo for /f "delims=" %%%%F in ^('dir /b /s "%%PSH_ROOT%%tools\fluidsynth.exe" 2^^^>nul'^) do set "PATH=%%%%~dpF;%%PATH%%"

call :c Cyan "[8/8] Verifying local tools and cache..."
call env_windows.bat
if exist "wheelhouse\*.whl" (call :c Green "[OK] wheelhouse is populated.") else (call :c Yellow "[INFO] wheelhouse is empty.")
where ffmpeg >nul 2>nul && call :c Green "[OK] ffmpeg found." || call :c Yellow "[INFO] ffmpeg not found; MP3 export will fall back to WAV."
where fluidsynth >nul 2>nul && call :c Green "[OK] FluidSynth found." || call :c Yellow "[INFO] FluidSynth not found; SoundFont playback requires manual install or a successful update run."
echo.
call :c Green "[OK] Update complete."
call :c Yellow "To prepare an offline copy, run this updater once online and then copy the whole folder including wheelhouse\ and tools\."
if "%FROM_INSTALLER%"=="0" pause
exit /b 0

:fail
call :c Red "[ERROR] Update failed."
call :c Yellow "If the PC is offline and wheelhouse is empty, run update.bat once on an online PC first."
if "%FROM_INSTALLER%"=="0" pause
exit /b 1
