Wheelhouse cache folder
=======================

This ZIP intentionally ships without bundled Python wheels.
Run update.bat on an online Windows PC to download the current compatible wheels into this folder.
After that, the whole PythonSoundHelix folder can be copied to an offline PC and install_windows.bat will install from this local wheelhouse.

Keep this folder when preparing an offline copy.
