# Changelog

## v0.4.25

- Added `docs/reference_analysis/original_soundhelix_midi_stats.md` with compact statistics from the user-provided original Java SoundHelix Popcorn and Piano MIDI outputs.
- Shifted the generator back toward SoundHelix-style coordinated engines: multi-bar activity gating, shared timing lattice, clearer register lanes and less independent per-track randomness.
- Fixed `Elise Synth` so the lead uses a protected chromatic Für-Elise-style phrase instead of generic diatonic scale degrees. The harmonic coherence pass no longer flattens important chromatic hook notes.
- Changed first-start/default playback mode to the internal built-in synth so Play MIDI can work without relying on a Windows MIDI file association.
- Visualizer checkbox remains enabled by default and now auto-starts on Play MIDI in both internal and system-player modes.
- Reworked the fullscreen visualizer toward a wormhole/tunnel-flight look with radial streaks, center-depth and note/beat/bar reactive motion.
- Added stronger protection for named template melodies so smoothing/arrangement cleanup does not delete recognizable hook notes.
- Tuned `Legacy XML Piano Expansion` using the uploaded original SoundHelix Piano MIDI statistics: calmer activity, lower arpeggio dominance and clearer piano-role separation.

## v0.4.22

- Added `docs/version_info.md` as an explicit machine-readable/local-version marker for installers, updaters, maintainers and LLM-assisted development.
- Added downgrade protection to the GitHub updater: project files from `https://github.com/zeittresor/PythonSH` are only applied when the remote project version is newer than the local package version.
- Added `PROJECT_VERSION.txt` as an explicit local version marker for installer/updater comparisons.
- `scripts/check_update_status.ps1` now reports older/equal GitHub versions as non-project-update cases, while still allowing wheelhouse/tool refreshes.
- `scripts/update_project_from_github.ps1` now compares local and remote versions before downloading/applying GitHub ZIP project files. This prevents a fresh local ZIP build, for example v0.4.22, from being overwritten by an older GitHub snapshot such as v0.4.9.
- Same-version GitHub snapshots are no longer auto-applied unless a future manual force path is used.

## v0.4.21

- Fixed installer handoff after `update.bat`: the installer now restarts itself with `--skip-update-check` after a self-update so overwritten batch files cannot trigger `Das Sprungziel - c wurde nicht gefunden`.
- Installer status check verifies the local `.venv` and required Python imports before deciding that no install/update work is needed.
- If project files, wheelhouse, optional tools and local Python environment are already current, `install_windows.bat` skips reinstall/update prompts and only shows the 10-second app launch prompt.
- Status-check script treats an incomplete Python environment as an install/update reason instead of silently proceeding to app launch.

## v0.4.20

- `update.bat` checks `https://github.com/zeittresor/PythonSH` for project files and can refresh local project/cache/tool data.
- Added `scripts/update_project_from_github.ps1` for GitHub self-update support. It preserves runtime/user folders such as `.venv`, `wheelhouse`, `tools`, `output` and `app_data`.
- `install_windows.bat` asks whether `update.bat` should run first; the answer defaults to Yes after a 10 second countdown.
- `install_windows.bat` also auto-starts PythonSoundHelix after installation when no answer is given within 10 seconds.
- Installer/updater output uses colored status messages for major steps, warnings and errors.
- Release ZIPs do not bundle Python wheel files. `update.bat` fills `wheelhouse/` on an online Windows PC.
- `update.bat` refreshes the local wheelhouse and optional app-local tools such as ffmpeg and FluidSynth.

## v0.4.15

- Moved audio rendering/playback controls to the Options tab.
- Added selectable MIDI playback modes: system default, internal built-in synth and optional FluidSynth/SoundFont rendering.

## v0.4.14

- Renamed classic melody presets so the preset list no longer uses `Public Domain` or `Traditional` prefixes.
- Renamed matching melody-template labels to cleaner contour names.
- Added **Melody coverage** control, allowing 5-100% of a named contour template to be used.
- Longer classic melody contour tables are now available for Elise, Ode, Canon, Row Boat, Twinkle, Frere Jacques, London Bridge, Mary Lamb, Greensleeves, Scarborough, Amazing Grace, Brahms Lullaby, Blue Danube, Yankee Doodle and Old MacDonald.
- Added CLI option `--melody-coverage`.
- Added `docs/infos_for_llms.md` as the central LLM-facing development note file.
- Removed broad explanatory full-line comments from Python source files.

## v0.4.13

- Changed the first-start/default preset to **Elise Synth**.
- Added a larger classic melody contour preset pack.
- Reworked the Progression selector so the default is **Random progression (style-aware)**.
- Added reusable major, minor, modal, house, techno, jazz/turnaround, ambient and blues/rock progression choices.
- Added support for borrowed/modal roman chord notation such as `bVII`, `bII` and `#iv`.

## v0.4.12

- Added style-aware harmony generation and musical guardrails.
- Added a global arrangement-coherence pass.
- Progression names became more musical and less raw/internal.

## v0.4.11

- Added explicit About-dialog attribution for SoundHelix and PythonSoundHelix.
- Enabled safer default musical hygiene.

## v0.4.10

- Added shared timing-grid lock and strict arpeggio-grid controls.

## v0.4.9

- Added Seed variation control and more seed-sensitive template behavior.

## v0.4.8

- Added Fine Tune tab.

## v0.4.7

- Music preset changes no longer change the GUI theme.
- Improved normalization and rapid-note smoothing.

## v0.4.6

- Cleaned up AlgoMusic naming and added screenshot-informed pattern logic.

## v0.4.5

- Added AlgoMusic-inspired Techno/House presets and Amiga-style pattern concepts.

## v0.4.4

- Reworked Original XML Popcorn Expansion toward the original Java SoundHelix-Popcorn XML/log behavior.

## v0.4.3

- Improved ffmpeg compatibility and warnings.

## v0.4.2

- Added auto octave/range guard and max melody pitch option.

## v0.4.1

- Renamed the main button to Generate Song and improved Render/Play behavior.

## v0.4.0

- Initial expanded PyQt6/GPLv3 PythonSoundHelix release.

## v0.4.25

- Added a visible main-screen Stop playback button for the internal audio player and visualizer.
- Added an Options checkbox to auto-start the visualizer when Play MIDI uses an internal playback mode.
- Reworked the visualizer into a note-reactive fullscreen wormhole/tunnel effect rather than a flat 2D particle display.
- Added a stronger harmonic coherence pass that retunes generated tonal notes toward the current chord/scale lane.
- Calmed the default Elise Synth preset and disabled its extra arpeggio layer by default for a more coherent first-run result.
- Made internal-player fallback more aggressive when QtMultimedia fails silently.
