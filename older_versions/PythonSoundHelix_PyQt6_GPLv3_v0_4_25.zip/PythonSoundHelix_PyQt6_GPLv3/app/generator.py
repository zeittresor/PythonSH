
from __future__ import annotations

import json
import math
import os
import random
import time
from dataclasses import asdict
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

from .audio_render import convert_wav_to_mp3, ffmpeg_available, render_tracks_to_wav
from .midi_writer import MidiTrackData, write_midi
from .models import ChordEvent, GeneratorSettings, SectionEvent, SongResult, TrackSettings
from .song_names import generate_song_name
from .music_theory import (
    DRUM_NOTES,
    clamp,
    degree_pitch,
    key_to_pc,
    midi_note_name,
    nearest_scale_pitch,
    notes_for_chord,
    parse_progression_units,
    safe_filename,
    scale_pitches,
    voice_lead,
)

SECTION_NAMES = ["Intro", "A", "Rise", "Hook", "Break", "Hook 2", "Outro"]
MELODY_TEMPLATES: Dict[str, List[int]] = {
    "auto": [],
    "Popcorn-style original pulse": [0, 0, -2, 0, 3, 0, -2, 0, 0, 0, -2, 0, 5, 3, 0, -2],
    "Popcorn-style recognizable contour": [0, 0, -2, 0, 3, 0, -2, 0, 0, 0, -2, 0, 5, 3, 0, -2],
    "Ode-to-Joy contour": [2, 2, 3, 4, 4, 3, 2, 1, 0, 0, 1, 2, 2, 1, 1, 2, 2, 3, 4, 4, 3, 2, 1, 0, 0, 1, 2, 1, 0, 0, 1, 1, 2, 0, 1, 2, 3, 2, 0, 1, 2, 3, 2, 1, 0, 1, -4, 2, 2, 3, 4, 4, 3, 2, 1, 0, 0, 1, 2, 1, 0, 0],
    "Fuer-Elise contour": [4, 3, 4, 3, 4, 1, 3, 2, 0, -2, 0, 1, 2, -3, -1, 2, 3, -1, 3, 4, 3, 4, 3, 4, 1, 3, 2, 0, -2, 0, 1, 2, -3, -1, 2, 0, -2, 2, 4, 5, 0, 4, 5, 7, 2, 5, 7, 8, 4, 3, 4, 3, 4, 1, 3, 2, 0, -2, 0, 1, 2, -3, -1, 2, 0],
    "Canon contour": [0, 4, 5, 2, 3, 0, 3, 4, 5, 7, 4, 5, 3, 4, 0, 4, 5, 7, 5, 4, 3, 2, 0, 2, 3, 4, 5, 7, 9, 7, 5, 4, 3, 4, 5, 2, 3, 0, 3, 4, 5, 7, 4, 5, 3, 4],
    "Toccata contour": [0, 7, 5, 3, 2, 0, -2, 0, 2, 3, 5, 7, 0, 7, 5, 3, 2, 0, -2, 0, -4, -2, 0, 2, 3, 2, 0, -2, 0, 7, 5, 3, 2, 0, -2, 0],
    "Original arcade anthem": [0, 0, 4, 7, 4, 2, 0, -1, 0, 2, 4, 2, 0],
    "Row Boat round": [0, 0, 0, 1, 2, 2, 1, 2, 3, 4, 7, 7, 7, 4, 4, 4, 2, 2, 2, 0, 0, 0, 4, 3, 2, 1, 0],
    "Twinkle music-box contour": [0, 0, 4, 4, 5, 5, 4, 3, 3, 2, 2, 1, 1, 0, 4, 4, 3, 3, 2, 2, 1, 4, 4, 3, 3, 2, 2, 1, 0, 0, 4, 4, 5, 5, 4, 3, 3, 2, 2, 1, 1, 0],
    "Frere Jacques round": [0, 1, 2, 0, 0, 1, 2, 0, 2, 3, 4, 2, 3, 4, 4, 5, 4, 3, 2, 0, 4, 5, 4, 3, 2, 0, 0, -3, 0, 0, -3, 0],
    "London Bridge contour": [4, 5, 4, 3, 2, 3, 4, 1, 2, 3, 2, 3, 4, 4, 5, 4, 3, 2, 3, 4, 1, 4, 2, 0],
    "Mary Lamb contour": [2, 1, 0, 1, 2, 2, 2, 1, 1, 1, 2, 4, 4, 2, 1, 0, 1, 2, 2, 2, 2, 1, 1, 2, 1, 0],
    "Greensleeves air": [4, 7, 8, 9, 7, 5, 4, 2, 0, 2, 4, 5, 4, 2, 0, -2, 4, 7, 8, 9, 7, 5, 4, 2, 0, 2, 4, 3, 2, 0, -2, 0],
    "Scarborough modal contour": [0, 2, 3, 2, 0, -2, 0, 2, 5, 3, 2, 0, -2, -4, -2, 0, 0, 2, 3, 5, 7, 5, 3, 2, 0, -2, 0, 2, 3, 2, 0],
    "Amazing Grace hymn contour": [0, 4, 7, 4, 7, 5, 4, 2, 0, 0, 4, 7, 4, 7, 5, 4, 2, 4, 7, 9, 7, 4, 7, 5, 4, 2, 0],
    "Brahms Lullaby contour": [0, 0, 2, 0, 0, 2, 0, 2, 5, 4, 3, 2, 1, 0, -1, 0, 1, 2, 0, 2, 5, 4, 3, 2, 1, 0],
    "Blue Danube waltz contour": [0, 2, 4, 4, 5, 7, 7, 5, 4, 2, 0, 2, 4, 5, 4, 0, 2, 4, 4, 5, 7, 7, 5, 4, 2, 0, 2, 4, 5, 4, 2, 0],
    "Yankee Doodle march contour": [0, 0, 1, 2, 0, 2, 1, -1, 0, 0, 1, 2, 0, -1, 0, 0, 1, 2, 3, 2, 1, 0, -1, 0, 1, 2, 0],
    "Old MacDonald barn contour": [0, 0, 0, -4, -4, -5, -5, -4, 0, 0, 0, -4, -4, -5, 0, 0, 0, -4, -4, -5, -5, -4, 0, 2, 2, 1, 1, 0],
    "Silent Night contour": [0, 1, 0, -4, 0, 1, 0, -4, 7, 7, 4, 5, 5, 0, 1, 1, 5, 4, 0, 1, 0, -4],
    "Auld Lang Syne contour": [0, 3, 2, 3, 5, 3, 2, 0, 0, 5, 7, 8, 7, 5, 3, 3, 0, 3, 2, 3, 5, 3, 2, 0],
    "Oh Susanna contour": [0, 2, 4, 7, 7, 9, 7, 4, 0, 2, 4, 4, 2, 0, -2, 0, 2, 4, 7, 7, 9, 7, 4, 0, 2, 4, 2, 0],
    "Camptown contour": [0, 0, 2, 4, 4, 2, 0, 2, 4, 5, 4, 2, 0, 0, 2, 4, 4, 2, 0, 2, 4, 2, 0],
    "Night Music contour": [0, 4, 7, 4, 7, 4, 0, 4, 7, 9, 7, 5, 4, 2, 0, 2, 4, 7, 4, 0],
    "Swan Lake contour": [0, 2, 3, 5, 7, 5, 3, 2, 0, -2, 0, 3, 2, 0, -2, -4, -2, 0, 2, 3, 5, 3, 2, 0],
    "Spring Vivaldi contour": [0, 4, 4, 4, 2, 0, 2, 4, 5, 7, 7, 7, 5, 4, 2, 0, 0, 4, 4, 4, 2, 0, 2, 4, 5, 7],
    "Mountain King contour": [0, 1, 3, 4, 6, 4, 6, 7, 0, 1, 3, 4, 6, 4, 6, 7, 7, 6, 4, 6, 7, 9, 7, 9, 10],
    "Wedding March contour": [0, 4, 7, 12, 11, 12, 7, 4, 0, 4, 7, 12, 11, 12, 7, 4, 5, 7, 9, 7, 5, 4, 2, 0],
    "Chiptune star motif": [0, 7, 12, 7, 5, 3, 0, 3, 5, 7, 12, 10, 7, 5, 3, 0],
    "Electro swing riff": [0, 3, 4, 7, 6, 7, 4, 3, 0, 3, 5, 8, 7, 5, 3, 0],
    "AlgoMusic tracker pulse": [0, 0, 7, 0, 3, 5, 0, -2, 0, 7, 5, 3, 2, 0, -2, 0],
    "AlgoMusic house chord riff": [0, 2, 3, 2, 0, -2, 0, 2, 5, 3, 2, 0, -2, -4, -2, 0],
    "AlgoMusic random walk": [0, 3, 2, 5, 3, 7, 5, 3, 0, -2, 0, 2, -1, 2, 4, 2],
}

CHROMATIC_TEMPLATES: Dict[str, List[int | None]] = {
    "Fuer-Elise contour": [7, 6, 7, 6, 7, 2, 5, 3, 0, None, -3, 0, 2, None, -2, 2, 3, None, -1, 3, 4, None, 7, 6, 7, 6, 7, 2, 5, 3, 0, None, -3, 0, 2, None, -2, 3, 2, 0, None, 2, 4, 5, None, 4, 7, 8, None, 7, 5, 4, None, 3, 7, 6, 7, 6, 7, 2, 5, 3, 0, None],
    "Popcorn-style recognizable contour": [0, 0, -2, 0, 3, 0, -2, 0, 0, 0, -2, 0, 5, 3, 0, -2, 2, 2, 0, 2, 5, 3, 2, 0, 0, 3, 0, -2, 0, 3, 0, -2],
}


POPCORN_CONTOUR_BANK = [
    [0, 0, -2, 0, 3, 0, -2, 0, 0, 0, -2, 0, 5, 3, 0, -2],
    [0, 0, -2, 0, 3, 0, -2, 0, 2, 2, 0, 2, 5, 3, 2, 0],
    [0, 3, 0, -2, 0, 3, 0, -2, 5, 3, 0, -2, 0, -2, -4, -2],
    [0, 0, -2, 0, 3, 0, -2, 0, -2, -2, -4, -2, 0, -2, -4, -5],
]

LEGACY_POPCORN_HARMONY = "+Am/10,G/2,F/2,Am/12,G/2,F/2,Am/2,+C/8,Em/2,D/2,C/12,Em/2,D/2,C/4"


ALGOMUSIC_DIGIT_PATTERN_BANK = [
    "1---1---1---1---",
    "1-1---1---1-1---",
    "1---2---1---2---",
    "1--2--1--2--112-",
    "1-1---2-1---1---",
    "1---2--1---12-1-",
    "1--2--121--2-12-",
    "1---1---2-11-11-",
    "1---3---1---3---",
    "1-3---1---3-1---",
    "1---3-4-3-2-1---",
    "1---1---4---1---",
    "1-2-3---3-2-1---",
    "1---31--3-1---1-",
    "1-3-1-3-1-3-1-3-",
    "1-2-3-4-1-2-3-4-",
]

ALGOMUSIC_DRUM_SYMBOL_BANK = [
    "----+-----+-----",
    ".---:---.---:---",
    "--^---^---^---^-",
    "*--*--*--*****--",
    "*--*--*--*--***-",
    "---^--+---^--+--",
    "----+-----++-+--",
    ".---:---.--+:-+-",
    "---^--+---^--+X-",
    ".---.---.---.---",
    "---^--+---^--+--",
    "----+-----+++--+",
]

LEGACY_POPCORN_ACTIVITY = {
    "accomp": "*****-------------*****-------***---",
    "arpeggio": "----------**---**---------******----",
    "base_snare": "--****---****---***-********-******-",
    "bass": "------********---------***----------",
    "chords": "***********-----------------********",
    "clap": "--------**---********-**---*********",
    "hihat": "-----------***********--*******-----",
    "melody": "-**-***----------***-----*****--**--",
    "pad": "-------*********---**********-------",
    "string": "-----**********----------------***--",
}



PROGRESSION_PRESET_MAP = {
    "Random progression (style-aware)": "auto",
    "Random / automatic progression": "auto",
    "Zufällige Akkordfolge (stilabhängig)": "auto",
    "Auto progression (style-aware)": "auto",
    "Auto progression / style-aware": "auto",
    "Automatische Akkordfolge (stilabhängig)": "auto",

    "Major lift: I-V-vi-IV": "I,V,vi,IV",
    "Major cycle: I-vi-IV-V": "I,vi,IV,V",
    "Major circle: I-vi-ii-V": "I,vi,ii,V",
    "Major classic: I-IV-V-I": "I,IV,V,I",
    "Major folk: I-IV-I-V": "I,IV,I,V",
    "Major canon cycle: I-V-vi-iii-IV-I-IV-V": "I,V,vi,iii,IV,I,IV,V",
    "Major wistful: vi-IV-I-V": "vi,IV,I,V",
    "Minor drive: i-VII-VI-V": "i,VII,VI,V",
    "Minor natural loop: i-VII-VI-VII": "i,VII,VI,VII",
    "Minor cinematic: i-VI-III-VII": "i,VI,III,VII",
    "Minor cadence: i-iv-V-i": "i,iv,V,i",
    "Minor classic: i-V-i-iv": "i,V,i,iv",
    "Dorian groove: i-IV-v-bVII": "i,IV,v,bVII",
    "Phrygian dark: i-bII-bVII-i": "i,bII,bVII,i",
    "Lydian dream: I-II-I-V": "I,II,I,V",
    "Mixolydian rock: I-bVII-IV-I": "I,bVII,IV,I",
    "Blues rock: I-IV-I-V": "I,IV,I,V",
    "Jazz turnaround: ii-V-I-vi": "ii,V,I,vi",
    "House minor: i-VI-III-VII": "i,VI,III,VII",
    "Techno pedal: i-i-VI-VII": "i,i,VI,VII",
    "Ambient drift: I-iii-IV-V": "I,iii,IV,V",
    "Modal folk: i-bVII-IV-i": "i,bVII,IV,i",

    "SoundHelix legacy harmony A": LEGACY_POPCORN_HARMONY,
    "SoundHelix legacy duration pattern A": LEGACY_POPCORN_HARMONY,
    "SoundHelix legacy simple minor": "Am/8,G/4,F/4,Am/8,C/4,G/4,F/8,G/8",
}


STYLE_PROGRESSIONS = {
    "pop": ["I,V,vi,IV", "I,vi,IV,V", "vi,IV,I,V", "I,V,IV,I", "I,IV,V,I", "I,vi,ii,V"],
    "minor": ["i,V,i,iv", "i,VI,III,VII", "i,VII,VI,V", "i,iv,V,i", "i,VII,VI,VII", "i,VI,VII,i"],
    "house": ["i,VI,III,VII", "i,VII,VI,VII", "i,iv,VI,VII", "i,VII,iv,VI", "i,VI,VII,i"],
    "techno": ["i,VII,VI,VII", "i,i,VI,VII", "i,VI,VII,i", "i,iv,VII,VI", "i,bVII,IV,i"],
    "dnb": ["i,VII,VI,V", "i,VI,VII,i", "i,VII,iv,V", "i,VII,VI,VII", "i,iv,V,i"],
    "ambient": ["I,V,ii,IV", "i,VI,iv,VII", "I,iii,IV,V", "i,VII,VI,VII", "I,II,I,V"],
    "lofi": ["i,VI,iv,V", "i,VII,VI,V", "I,vi,ii,V", "vi,IV,I,V", "ii,V,I,vi"],
    "funk": ["I,IV,I,V", "I,bVII,IV,I", "i,IV,V,IV", "I,V,bVII,IV", "I,IV,V,IV"],
    "orchestral": ["i,VI,III,VII", "i,iv,V,i", "I,V,vi,IV", "i,VII,VI,V", "I,V,vi,iii,IV,I,IV,V"],
    "reggae": ["I,V,vi,IV", "I,IV,V,IV", "i,VII,VI,VII", "I,bVII,IV,I"],
    "dub": ["i,VII,VI,VII", "i,iv,VII,VI", "I,bVII,IV,I", "i,VI,VII,i"],
    "swing": ["ii,V,I,vi", "I,vi,ii,V", "I,VI,ii,V", "I,bVII,VI,V"],
    "chiptune": ["I,V,vi,IV", "i,VII,VI,V", "I,bVII,IV,I", "i,VI,III,VII"],
    "trance": ["i,VI,III,VII", "vi,IV,I,V", "i,VII,VI,VII", "I,V,vi,IV"],
    "legacy": [LEGACY_POPCORN_HARMONY, "Am/8,G/4,F/4,Am/8,C/4,G/4,F/8,G/8"],
}



def _progression_label_to_pattern(text: str) -> str:
    text = (text or "").strip()
    return PROGRESSION_PRESET_MAP.get(text, text or "auto")


def _is_auto_progression(text: str) -> bool:
    return _progression_label_to_pattern(text).lower() in {"auto", "auto progression", "style-aware", "style aware"}


def _style_key(settings: GeneratorSettings) -> str:
    text = f"{settings.preset_name} {settings.melody_template} {settings.groove_template}".lower()
    mode_text = (settings.mode or "").lower()
    if "popcorn" in text or "legacy harmony" in text:
        return "legacy"
    if "drum and bass" in text or "dnb" in text or "jungle" in text:
        return "dnb"
    if "algomusic" in text or "techno" in text or "acid" in text or "matrix" in text:
        return "techno"
    if "reggae" in text or "skank" in text:
        return "reggae"
    if "dub" in text or "echo" in text:
        return "dub"
    if "swing" in text:
        return "swing"
    if "chiptune" in text or "byte" in text or "starfield" in text:
        return "chiptune"
    if "trance" in text:
        return "trance"
    if "house" in text:
        return "house"
    if "ambient" in text or "ocean" in text or "pad" in text or "space" in text:
        return "ambient"
    if "lofi" in text or "piano rain" in text:
        return "lofi"
    if "funk" in text or "brass" in text or "shuffle" in text:
        return "funk"
    if "orchestral" in text or "toccata" in text or "canon" in text or "ode" in text:
        return "orchestral"
    if "minor" in mode_text or "phrygian" in mode_text or "dorian" in mode_text:
        return "minor"
    return "pop"


def _auto_progression_pattern(settings: GeneratorSettings) -> str:
    style = _style_key(settings)
    bank = STYLE_PROGRESSIONS.get(style, STYLE_PROGRESSIONS["pop"])
    rng = random.Random(settings.seed + sum(ord(c) for c in (settings.preset_name or "")) * 17)
    pattern = bank[rng.randrange(len(bank))]
    if style != "popcorn" and "," in pattern and clamp(getattr(settings, "seed_variation_strength", 70), 0, 100) > 35:
        parts = [p.strip() for p in pattern.split(",") if p.strip()]
        if len(parts) >= 4 and rng.random() < 0.35:
            rot = rng.choice([0, 0, 1, 2])
            parts = parts[rot:] + parts[:rot]
            pattern = ",".join(parts)
    return pattern


def _effective_progression_pattern(settings: GeneratorSettings) -> str:
    raw = settings.custom_progression or settings.progression or "auto"
    mapped = _progression_label_to_pattern(raw)
    if _is_auto_progression(mapped):
        return _auto_progression_pattern(settings)
    return mapped


def _apply_musical_guardrails(settings: GeneratorSettings) -> None:
    """Constrain extreme GUI parameters into a musically coherent operating range.

    SoundHelix/AlgoMusic did not simply let every randomized parameter fight every
    other parameter; several engines continuously constrained activity, timing and
    harmony. This Python pass is the same idea: when enabled, user settings still
    matter, but pathological combinations are softened before rendering.
    """
    if not getattr(settings, "musical_guardrails", True):
        return
    strength = clamp(getattr(settings, "coherence_strength", 84), 0, 100) / 100.0
    if strength <= 0:
        return
    beat = max(1, int(settings.ticks_per_beat))
    fast = settings.bpm >= 150
    very_fast = settings.bpm >= 165
    settings.timing_grid_lock = True
    settings.strict_arpeggio_grid = True
    settings.timing_grid_strength = max(settings.timing_grid_strength, int(82 + 18 * strength))
    max_human_ticks = max(0, int(beat * (0.018 if very_fast else 0.028 if fast else 0.045)))
    settings.humanize_ticks = min(settings.humanize_ticks, max_human_ticks)
    settings.humanize_velocity = min(settings.humanize_velocity, 14)
    settings.swing = min(settings.swing, 8 if fast else 18)
    settings.normalize_velocity = True
    settings.normalize_strength = max(settings.normalize_strength, int(78 + 20 * strength))
    settings.normalize_target = min(settings.normalize_target, 84)
    settings.rhythmic_smoothing = True
    settings.smoothing_strength = max(settings.smoothing_strength, int(82 + 14 * strength))
    settings.calm_busy_tracks = True
    settings.relaxation_strength = max(settings.relaxation_strength, int(84 + 12 * strength))
    if fast:
        settings.global_arpeggio_rate = min(settings.global_arpeggio_rate, int(82 - 18 * strength))
        settings.seed_variation_strength = min(settings.seed_variation_strength, 82)
    else:
        settings.global_arpeggio_rate = min(settings.global_arpeggio_rate, int(112 - 20 * strength))

    role_density_caps = {
        "drum": 96,
        "bass": 82 if fast else 88,
        "chord": 72,
        "pad": 48,
        "arpeggio": 62 if fast else 74,
        "melody": 60 if fast else 72,
        "counter": 48 if fast else 58,
        "texture": 34 if fast else 46,
    }
    role_activity_caps = {
        "drum": 100,
        "bass": 92,
        "chord": 86,
        "pad": 90,
        "arpeggio": 72 if fast else 84,
        "melody": 64 if fast else 76,
        "counter": 50 if fast else 62,
        "texture": 38 if fast else 52,
    }
    role_volume_caps = {
        "drum": 108,
        "bass": 96,
        "chord": 84,
        "pad": 72,
        "arpeggio": 66 if fast else 74,
        "melody": 82 if fast else 90,
        "counter": 60,
        "texture": 44,
    }
    for t in settings.tracks:
        role = (t.role or "melody").lower().strip()
        if role in role_density_caps:
            t.density = min(t.density, int(role_density_caps[role] + (100 - role_density_caps[role]) * (1.0 - strength) * 0.35))
        if role in role_activity_caps:
            t.activity = min(t.activity, int(role_activity_caps[role] + (100 - role_activity_caps[role]) * (1.0 - strength) * 0.35))
        if role in role_volume_caps:
            t.volume = min(t.volume, int(role_volume_caps[role] + (127 - role_volume_caps[role]) * (1.0 - strength) * 0.25))
        if role == "arpeggio":
            t.arp_rate = min(getattr(t, "arp_rate", 100), 80 if fast else 105)
            if "tracker" in (t.pattern or "").lower() or "updown" in (t.pattern or "").lower():
                t.complexity = min(t.complexity, 68 if fast else 76)
        if role in ("melody", "counter", "texture") and fast:
            t.complexity = min(t.complexity, 66)
    _auto_lane_tracks(settings)

def _is_legacy_popcorn(settings: GeneratorSettings) -> bool:
    return "popcorn" in (settings.preset_name or "").lower() and "original xml" in (settings.preset_name or "").lower()


def _is_algomusic(settings: GeneratorSettings) -> bool:
    return "algomusic" in (settings.preset_name or "").lower() or "algomusic" in (settings.groove_template or "").lower()


def _seed_variation(settings: GeneratorSettings) -> float:
    return clamp(getattr(settings, "seed_variation_strength", 70), 0, 100) / 100.0


def _track_seed(track: TrackSettings) -> int:
    return sum((idx + 1) * ord(ch) for idx, ch in enumerate((track.name or "") + "|" + (track.pattern or "")))


def _auto_lane_tracks(settings: GeneratorSettings) -> None:
    if not getattr(settings, "musical_guardrails", True) or not getattr(settings, "auto_range_guard", True):
        return
    role_counts: Dict[str, int] = {}
    for t in settings.tracks:
        role = (t.role or "melody").lower().strip()
        role_counts[role] = role_counts.get(role, 0) + 1
        nth = role_counts[role]
        if role == "drum":
            continue
        if role == "bass":
            t.octave = min(getattr(t, "octave", 0), -1)
            t.transpose = clamp(getattr(t, "transpose", 0), -5, 5)
            t.fine_tune_cents = 0
        elif role == "pad":
            if abs(getattr(t, "octave", 0)) <= 1:
                t.octave = -1 if nth == 1 else 0
            t.transpose = clamp(getattr(t, "transpose", 0), -7, 7)
            t.fine_tune_cents = 0
            t.density = min(t.density, 44)
        elif role == "chord":
            t.octave = clamp(getattr(t, "octave", 0), -1, 0)
            t.transpose = clamp(getattr(t, "transpose", 0), -7, 7)
            t.fine_tune_cents = 0
        elif role == "arpeggio":
            t.octave = clamp(getattr(t, "octave", 0), -1, 0)
            t.transpose = clamp(getattr(t, "transpose", 0), -5, 5)
            t.fine_tune_cents = 0
            t.arp_rate = min(getattr(t, "arp_rate", 100), 75)
            t.density = min(t.density, 52)
            t.activity = min(t.activity, 60)
        elif role in ("counter", "texture"):
            t.octave = clamp(getattr(t, "octave", 0), -1, 0)
            t.transpose = clamp(getattr(t, "transpose", 0), -5, 5)
            t.fine_tune_cents = 0
            t.density = min(t.density, 36 if role == "texture" else 46)
            t.activity = min(t.activity, 46 if role == "texture" else 54)
        elif role == "melody":
            t.octave = clamp(getattr(t, "octave", 0), -1, 0)
            t.transpose = clamp(getattr(t, "transpose", 0), -5, 5)
            t.fine_tune_cents = 0
            t.density = min(t.density, 60)
            t.activity = min(t.activity, 72)


def _chromatic_template(settings: GeneratorSettings) -> List[int | None]:
    return CHROMATIC_TEMPLATES.get(settings.melody_template or "", [])


def _chromatic_template_pcs(settings: GeneratorSettings) -> set[int]:
    key_pc = key_to_pc(settings.key)
    return {(key_pc + int(x)) % 12 for x in _chromatic_template(settings) if x is not None}


def _is_chromatic_template(settings: GeneratorSettings) -> bool:
    return bool(_chromatic_template(settings))


def _is_popcorn_template(settings: GeneratorSettings) -> bool:
    text = f"{settings.preset_name} {settings.melody_template}".lower()
    return "popcorn" in text


def _seeded_popcorn_phrase(settings: GeneratorSettings, track: TrackSettings, bar: int) -> List[int]:
    depth = _seed_variation(settings)
    phrase_idx = ((settings.seed // 97) + (bar // 2) + _track_seed(track)) % len(POPCORN_CONTOUR_BANK)
    if bar % 8 in (0, 1) and depth < 0.90:
        phrase_idx = 0
    phrase = POPCORN_CONTOUR_BANK[phrase_idx][:]
    if depth > 0.05:
        rng = random.Random(settings.seed + _track_seed(track) * 131 + bar * 8191)
        if rng.random() < 0.35 * depth and bar % 4 not in (0, 1):
            rot = rng.choice([0, 0, 2, 4, 8])
            phrase = phrase[rot:] + phrase[:rot]
        for i in range(len(phrase)):
            if i % 4 and rng.random() < 0.16 * depth * (settings.variation / 100.0):
                phrase[i] += rng.choice([-1, 0, 1])
    return phrase


def _template_coverage_len(settings: GeneratorSettings, motif: Sequence[int]) -> int:
    if not motif:
        return 0
    pct = clamp(getattr(settings, "melody_coverage", 100), 5, 100)
    return max(1, min(len(motif), math.ceil(len(motif) * pct / 100.0)))


def _seeded_template_degree(settings: GeneratorSettings, track: TrackSettings, bar: int, step: int, motif: Sequence[int], step_count: int = 16) -> int:
    if not motif:
        return 0
    depth = _seed_variation(settings)
    if _is_popcorn_template(settings):
        phrase = _seeded_popcorn_phrase(settings, track, bar)
        return phrase[step % len(phrase)]
    used_len = _template_coverage_len(settings, motif)
    rng = random.Random(settings.seed + _track_seed(track) * 181 + bar * 4099 + step * 67)
    phase = 0
    if depth > 0.05:
        phase = (settings.seed + _track_seed(track) + (bar // 4) * 3) % max(1, used_len)
        if rng.random() > depth:
            phase = 0
    degree = motif[(bar * max(1, step_count) + step + phase) % used_len]
    if depth > 0.05 and step % 4 and rng.random() < 0.18 * depth * (settings.variation / 100.0):
        degree += rng.choice([-2, -1, 1, 2])
    return degree


def _legacy_activity_key(track: TrackSettings) -> str:
    name = (track.name or "").lower().strip().replace(" ", "_")
    pat = (track.pattern or "").lower().strip().replace(" ", "_")
    role = (track.role or "").lower().strip()
    for key in LEGACY_POPCORN_ACTIVITY:
        if key in name or key in pat:
            return key
    if role == "drum":
        return "base_snare"
    if role == "counter":
        return "accomp"
    return role if role in LEGACY_POPCORN_ACTIVITY else name




def _stable_track_index(settings: GeneratorSettings, track: TrackSettings, bar: int, salt: int = 0) -> int:
    return abs(settings.seed * 131 + bar * 977 + salt * 37 + sum(ord(ch) for ch in (track.name + track.pattern)))


def _algomusic_digit_row(settings: GeneratorSettings, track: TrackSettings, bar: int) -> str:
    return ALGOMUSIC_DIGIT_PATTERN_BANK[_stable_track_index(settings, track, bar, 17) % len(ALGOMUSIC_DIGIT_PATTERN_BANK)]


def _algomusic_drum_row(settings: GeneratorSettings, track: TrackSettings, bar: int) -> str:
    return ALGOMUSIC_DRUM_SYMBOL_BANK[_stable_track_index(settings, track, bar, 29) % len(ALGOMUSIC_DRUM_SYMBOL_BANK)]


def _is_algomusic_digit_pattern(settings: GeneratorSettings, track: TrackSettings) -> bool:
    text = f"{settings.melody_template} {track.pattern} {settings.groove_template}".lower()
    return "digit" in text or "pattern bank" in text or "techno rows" in text


def _is_algomusic_drum_pattern(settings: GeneratorSettings, track: TrackSettings) -> bool:
    text = f"{track.pattern} {settings.groove_template}".lower()
    return "symbol" in text or "techno rows" in text or "algomusic drums" in text

def _bar_ticks(settings: GeneratorSettings) -> int:
    return settings.ticks_per_beat * settings.beats_per_bar


def _step_ticks(settings: GeneratorSettings, division: int = 4) -> int:
    return max(1, settings.ticks_per_beat // max(1, division // 4 if division > 4 else 1))


def _human_tick(rng: random.Random, base_tick: int, amount: int) -> int:
    if amount <= 0:
        return base_tick
    return max(0, base_tick + rng.randint(-amount, amount))


def _velocity(rng: random.Random, base: int, human: int, accent: int = 0) -> int:
    return clamp(base + accent + rng.randint(-human, human), 1, 127)


BASE_ROLE_RANGES: Dict[str, Tuple[int, int]] = {
    "bass": (31, 52),
    "chord": (45, 72),
    "pad": (43, 72),
    "arpeggio": (50, 81),
    "melody": (52, 79),
    "counter": (50, 76),
    "texture": (48, 78),
}


def _role_range(settings: GeneratorSettings, track: TrackSettings) -> Tuple[int, int]:
    role = (track.role or "melody").lower().strip()
    low, high = BASE_ROLE_RANGES.get(role, (48, 80))
    if not getattr(settings, "auto_range_guard", True):
        return low + track.octave * 12, high + track.octave * 12
    low += track.octave * 7
    high += track.octave * 7
    melodic_cap = clamp(getattr(settings, "max_melody_pitch", 79), 60, 96)
    if role in ("melody", "counter", "arpeggio", "texture"):
        high = min(high, melodic_cap + (2 if role == "arpeggio" else 0))
    if role in ("pad", "chord"):
        high = min(high, melodic_cap - 2)
    if high <= low + 7:
        high = low + 12
    return int(low), int(high)




def _track_transpose(track: TrackSettings) -> int:
    return clamp(getattr(track, "transpose", 0), -24, 24)


def _track_arp_rate(settings: GeneratorSettings, track: TrackSettings) -> float:
    global_rate = clamp(getattr(settings, "global_arpeggio_rate", 100), 25, 240) / 100.0
    local_rate = clamp(getattr(track, "arp_rate", 100), 25, 240) / 100.0
    return max(0.20, min(3.00, global_rate * local_rate))


def _apply_track_pitch(pitch: int, settings: GeneratorSettings, track: TrackSettings, low: int | None = None, high: int | None = None) -> int:
    if (track.role or "").lower().strip() == "drum":
        return clamp(pitch, 0, 127)
    if low is None or high is None:
        low, high = _role_range(settings, track)
    return _fold_pitch(int(pitch) + _track_transpose(track), low, high)


def _fine_tune_pitch_bend_value(track: TrackSettings) -> int:
    cents = clamp(getattr(track, "fine_tune_cents", 0), -100, 100)
    return clamp(8192 + round((cents / 200.0) * 8192), 0, 16383)

def _fold_pitch(pitch: int, low: int, high: int) -> int:
    while pitch > high:
        pitch -= 12
    while pitch < low:
        pitch += 12
    return clamp(pitch, max(0, low), min(127, high))


def _fold_notes(notes: Sequence[int], low: int, high: int) -> List[int]:
    return [_fold_pitch(int(n), low, high) for n in notes]


def _swing_offset(step_index: int, step_len: int, swing: int) -> int:
    if swing <= 0:
        return 0
    return int(step_len * (swing / 100.0) * 0.33) if step_index % 2 == 1 else 0


def _quantized_step_count(raw_steps: int, settings: GeneratorSettings) -> int:
    """Return an arpeggio step count that lands on a stable musical grid.

    v0.4.9 let seed variation pick values such as 18 or 20 steps per 4/4 bar.
    That creates tuplet/polymetric arps against straight drums and bass and can
    sound as if the channels are drifting. The default is now strict binary grid
    counts; disabling strict_arpeggio_grid allows triplet-like counts again.
    """
    raw = clamp(raw_steps, 2, 64)
    strict = getattr(settings, "strict_arpeggio_grid", True) or getattr(settings, "timing_grid_lock", True)
    allowed = [2, 4, 8, 16, 32, 64] if strict else [2, 3, 4, 6, 8, 12, 16, 24, 32, 48, 64]
    return min(allowed, key=lambda v: (abs(v - raw), v))


def _nearest_grid_tick(tick: int, settings: GeneratorSettings, role: str) -> int:
    """Find nearest arrangement grid point, including the global swing offset.

    This is used by the post-generation grid lock pass. It keeps all channels on
    the same groove lattice instead of letting every voice drift to its own
    fractional step size.
    """
    bar_len = max(1, _bar_ticks(settings))
    beat = max(1, settings.ticks_per_beat)
    if role in ("pad",):
        grid = beat
    elif role in ("chord",):
        grid = max(1, beat // 2)
    else:
        grid = max(1, beat // 4)
    bar_start = (max(0, tick) // bar_len) * bar_len
    local = max(0, tick) - bar_start
    approx_cell = round(local / grid)
    max_cell = max(0, int(round(bar_len / grid)))
    best_tick = bar_start
    best_dist = 10**12
    for cell in range(max(0, approx_cell - 3), min(max_cell, approx_cell + 3) + 1):
        candidate = bar_start + cell * grid + _swing_offset(cell, grid, settings.swing)
        candidate = max(0, min(candidate, bar_start + bar_len - 1))
        dist = abs(candidate - tick)
        if dist < best_dist:
            best_tick = candidate
            best_dist = dist
    return int(best_tick)


def _snap_timing_to_grid(tracks: Sequence[MidiTrackData], settings: GeneratorSettings, track_settings: Sequence[TrackSettings]) -> None:
    """Synchronize note starts to the shared song grid.

    This fixes the v0.4.9 problem where arpeggios could use fractional/non-grid
    divisions while drums, bass and melody stayed on different lattices. The
    function moves note-on and its matching note-off together, so durations stay
    intact. A small amount of human timing can still be reintroduced through the
    strength slider being below 100.
    """
    if not getattr(settings, "timing_grid_lock", True):
        return
    strength = clamp(getattr(settings, "timing_grid_strength", 92), 0, 100) / 100.0
    if strength <= 0:
        return
    for idx, data in enumerate(tracks):
        ts = track_settings[idx] if idx < len(track_settings) else TrackSettings(name=data.name, role="melody")
        role = (ts.role or "melody").lower().strip()
        pairs = _paired_note_events(data)
        for on_ev, off_ev, _duration in pairs:
            target = _nearest_grid_tick(on_ev.tick, settings, role)
            local_strength = 1.0 if role in ("drum", "bass") else strength
            new_tick = int(round(on_ev.tick + (target - on_ev.tick) * local_strength))
            delta = new_tick - on_ev.tick
            if delta:
                on_ev.tick = max(0, on_ev.tick + delta)
                off_ev.tick = max(on_ev.tick + 1, off_ev.tick + delta)


def build_sections(settings: GeneratorSettings) -> List[SectionEvent]:
    count = clamp(settings.section_count, 3, 64)
    bars = max(8, settings.bars)
    base = bars // count
    remainder = bars % count
    sections: List[SectionEvent] = []
    start = 0
    for i in range(count):
        length = base + (1 if i < remainder else 0)
        if i < count - 1 and length > 5 and length % 2:
            length += 1
        if i == count - 1:
            length = bars - start
        name = SECTION_NAMES[i] if i < len(SECTION_NAMES) else f"Section {i + 1}"
        pos = i / max(1, count - 1)
        energy = clamp(28 + 65 * math.sin(pos * math.pi) + (18 if "Hook" in name else 0) - (12 if name == "Break" else 0), 10, 100)
        sections.append(SectionEvent(name=name, start_bar=start, bars=length, energy=energy))
        start += length
        if start >= bars:
            break
    return sections


def section_for_bar(sections: Sequence[SectionEvent], bar: int) -> SectionEvent:
    for section in sections:
        if section.start_bar <= bar < section.start_bar + section.bars:
            return section
    return sections[-1]


def build_chords(settings: GeneratorSettings, sections: Sequence[SectionEvent]) -> List[ChordEvent]:
    key_pc = key_to_pc(settings.key)
    bar_len = _bar_ticks(settings)
    effective_pattern = _effective_progression_pattern(settings)
    if _is_legacy_popcorn(settings):
        units = parse_progression_units(effective_pattern, 1, max_units_per_token=32, divide_duration_by_four=False)
        total_units = sum(length for _, length in units) or 1
        expanded = []
        used = 0
        for idx, (sym, length) in enumerate(units):
            if idx == len(units) - 1:
                bars_for = max(1, settings.bars - used)
            else:
                bars_for = max(1, round(settings.bars * length / total_units))
                used += bars_for
            expanded.extend([sym] * bars_for)
        expanded = expanded[:settings.bars] or ["Am"]
    else:
        units = parse_progression_units(effective_pattern, max(1, settings.harmonic_rhythm))
        expanded: List[str] = []
        for sym, length in units:
            expanded.extend([sym] * max(1, length * max(1, settings.harmonic_rhythm)))
        if not expanded:
            expanded = ["I"]
    chords: List[ChordEvent] = []
    for bar in range(settings.bars):
        symbol = expanded[bar % len(expanded)]
        section = section_for_bar(sections, bar)
        chord_notes = notes_for_chord(symbol, key_pc, settings.mode, octave=4)
        chords.append(ChordEvent(bar=bar, tick=bar * bar_len, symbol=symbol, root=chord_notes[0] % 12, notes=chord_notes, section=section.name))
    return chords


def _is_active(rng: random.Random, settings: GeneratorSettings, track: TrackSettings, section: SectionEvent, bar: int) -> bool:
    if not track.enabled:
        return False
    if track.mute_in_intro and section.name == "Intro":
        return False
    if getattr(settings, "musical_guardrails", True) and not _is_legacy_popcorn(settings):
        role = (track.role or "melody").lower().strip()
        sec = (section.name or "").lower()
        direct_template = role == "melody" and (track.pattern or "").lower() == "template" and settings.melody_template != "auto"
        if direct_template:
            return True
        if "elise" in (track.pattern or "").lower() and role == "bass":
            return True
        profile = {
            "intro": {"drum": 32, "bass": 55, "chord": 42, "pad": 82, "arpeggio": 8, "melody": 48, "counter": 6, "texture": 8},
            "a": {"drum": 78, "bass": 86, "chord": 72, "pad": 62, "arpeggio": 24, "melody": 58, "counter": 18, "texture": 10},
            "rise": {"drum": 88, "bass": 92, "chord": 76, "pad": 66, "arpeggio": 36, "melody": 66, "counter": 24, "texture": 14},
            "hook": {"drum": 92, "bass": 94, "chord": 78, "pad": 68, "arpeggio": 40, "melody": 86, "counter": 28, "texture": 16},
            "break": {"drum": 28, "bass": 32, "chord": 42, "pad": 90, "arpeggio": 10, "melody": 42, "counter": 16, "texture": 20},
            "outro": {"drum": 46, "bass": 58, "chord": 60, "pad": 76, "arpeggio": 14, "melody": 38, "counter": 10, "texture": 8},
        }
        key = "hook" if "hook" in sec else "rise" if "rise" in sec else "break" if "break" in sec else "outro" if "outro" in sec else "intro" if "intro" in sec else "a"
        role_prob = profile.get(key, profile["a"]).get(role, 55)
        block = max(0, bar // (2 if settings.bpm >= 150 else 4))
        stable = random.Random(settings.seed + _track_seed(track) * 19 + block * 211 + section.start_bar * 17)
        adjusted = clamp(role_prob + (track.activity - 70) * 0.25 + (section.energy - 60) * 0.08, 0, 100)
        if stable.randint(0, 100) >= adjusted:
            return False
    if _is_legacy_popcorn(settings):
        key = _legacy_activity_key(track)
        matrix = LEGACY_POPCORN_ACTIVITY.get(key)
        if matrix:
            section_idx = min(len(matrix) - 1, max(0, int(bar * len(matrix) / max(1, settings.bars))))
            return matrix[section_idx] == "*"
    probability = (track.activity * 0.55 + section.energy * 0.35 + settings.complexity * 0.10)
    if section.name == "Break" and track.role in ("drum", "bass"):
        probability -= 20
    if "Hook" in section.name and track.role in ("melody", "arpeggio", "chord"):
        probability += 12
    if track.role == "pad":
        probability += 10
    return rng.randint(0, 100) < clamp(probability, 0, 100)


def _setup_track(track: TrackSettings) -> MidiTrackData:
    data = MidiTrackData(track.name)
    data.add_program(0, track.channel, track.program)
    data.add_cc(0, track.channel, 7, track.volume)
    data.add_cc(0, track.channel, 10, track.pan)
    data.add_cc(0, track.channel, 91, 18 if track.role in ("pad", "texture") else 8)
    data.add_cc(0, track.channel, 93, 10 if track.role in ("melody", "arpeggio", "texture") else 2)
    if track.channel != 9 and getattr(track, "fine_tune_cents", 0):
        data.add_pitch_bend(0, track.channel, _fine_tune_pitch_bend_value(track))
    return data


def _add_lfo(track_data: MidiTrackData, settings: GeneratorSettings, track: TrackSettings, end_tick: int) -> None:
    if not settings.lfo_expression or track.channel == 9:
        return
    period = _bar_ticks(settings) * 8
    step = max(settings.ticks_per_beat, period // 16)
    for tick in range(0, end_tick, step):
        value = 74 + int(18 * math.sin((tick / max(1, period)) * math.tau + track.channel))
        track_data.add_cc(tick, track.channel, 11, clamp(value, 25, 127))


def _motif(settings: GeneratorSettings, rng: random.Random) -> List[int]:
    template = MELODY_TEMPLATES.get(settings.melody_template or "auto", [])
    if template:
        return template[:]
    length = 8 + (settings.complexity // 20) * 2
    degrees = [0]
    algomusic = _is_algomusic(settings)
    for _ in range(length - 1):
        if algomusic and rng.randint(0, 100) < settings.variation:
            move = rng.choice([-3, -2, -1, 0, 1, 2, 3, 5])
            degrees.append(0 if rng.random() < 0.18 else degrees[-1] + move)
        elif rng.randint(0, 100) < settings.motif_memory and degrees:
            move = rng.choice([-2, -1, 0, 1, 2, 3])
            degrees.append(degrees[-1] + move)
        else:
            degrees.append(rng.randint(-2, 7))
    return degrees


def _add_drum_bar(rng: random.Random, data: MidiTrackData, settings: GeneratorSettings, track: TrackSettings, bar: int, section: SectionEvent, total_bars: int) -> int:
    bar_len = _bar_ticks(settings)
    start = bar * bar_len
    beat = settings.ticks_per_beat
    sixteenth = beat // 4
    notes = 0
    energy = (section.energy + track.density + settings.complexity) / 3
    pattern = (track.pattern or "auto").lower()

    only_clap = "clap" in pattern and "base" not in pattern
    only_hihat = "hihat" in pattern or "hat" in pattern
    only_base_snare = "base_snare" in pattern or "base snare" in pattern
    is_amiga = "amiga" in pattern or "tracker" in pattern

    if _is_algomusic_drum_pattern(settings, track):
        row = _algomusic_drum_row(settings, track, bar)
        cell_len = max(1, bar_len // max(1, len(row)))
        for idx, symbol in enumerate(row):
            tick = start + idx * cell_len + _swing_offset(idx, cell_len, settings.swing)
            dur = max(1, int(cell_len * 0.55))
            sym = symbol.lower()
            if sym == "+":
                data.add_note(_human_tick(rng, tick, settings.humanize_ticks), dur, 9, DRUM_NOTES["kick"], _velocity(rng, 88, settings.humanize_velocity, 10 if idx % 4 == 0 else 0)); notes += 1
            elif sym == "^":
                data.add_note(_human_tick(rng, tick, settings.humanize_ticks), dur, 9, DRUM_NOTES["snare"], _velocity(rng, 82, settings.humanize_velocity, 6)); notes += 1
            elif sym == "*":
                data.add_note(_human_tick(rng, tick, settings.humanize_ticks), dur, 9, DRUM_NOTES["closed_hat"], _velocity(rng, 62, settings.humanize_velocity, 5 if idx % 4 == 0 else -5)); notes += 1
            elif sym == ".":
                data.add_note(_human_tick(rng, tick, settings.humanize_ticks), dur, 9, DRUM_NOTES["closed_hat"], _velocity(rng, 44, settings.humanize_velocity, -10)); notes += 1
            elif sym == ":":
                data.add_note(_human_tick(rng, tick, settings.humanize_ticks), dur, 9, DRUM_NOTES["rim"], _velocity(rng, 54, settings.humanize_velocity, -4)); notes += 1
            elif sym == "x":
                for drum, base_vel in (("kick", 92), ("snare", 88), ("crash", 82)):
                    data.add_note(_human_tick(rng, tick, settings.humanize_ticks), dur, 9, DRUM_NOTES[drum], _velocity(rng, base_vel, settings.humanize_velocity, 8)); notes += 1
        return notes

    if not only_clap and not only_hihat:
        kick_steps = [0, 8] if "four" not in pattern else [0, 4, 8, 12]
        if is_amiga and "four" in pattern:
            kick_steps = [0, 4, 8, 12, 14 if rng.random() < 0.35 else 10]
        if energy > 55 and "break" not in pattern:
            kick_steps += [6 if rng.random() < 0.45 else 10]
        if "broken" in pattern:
            kick_steps = [0, 3, 8, 11]
        for step in sorted(set(kick_steps)):
            vel = _velocity(rng, 88, settings.humanize_velocity, 12 if step == 0 else 0)
            data.add_note(_human_tick(rng, start + step * sixteenth, settings.humanize_ticks), max(1, sixteenth // 2), 9, DRUM_NOTES["kick"], vel)
            notes += 1

    if not only_hihat:
        for step in [4, 12]:
            snare = DRUM_NOTES["clap"] if only_clap or "electro" in pattern or energy > 72 else DRUM_NOTES["snare"]
            data.add_note(_human_tick(rng, start + step * sixteenth, settings.humanize_ticks), max(1, sixteenth // 2), 9, snare, _velocity(rng, 82, settings.humanize_velocity, 8))
            notes += 1

    if not only_clap and not only_base_snare:
        hat_rate = 1 if "tracker hats" in pattern else (2 if energy > 58 else 4)
        for step in range(0, 16, hat_rate):
            if rng.randint(0, 100) <= track.density:
                hat = DRUM_NOTES["open_hat"] if step % 8 == 6 and rng.random() < (0.45 if is_amiga else 0.35) else DRUM_NOTES["closed_hat"]
                accent = 10 if step % 4 == 0 else (-7 if is_amiga and step % 2 else -4)
                tick = start + step * sixteenth + _swing_offset(step, sixteenth, settings.swing)
                data.add_note(_human_tick(rng, tick, settings.humanize_ticks), max(1, sixteenth // 2), 9, hat, _velocity(rng, 58, settings.humanize_velocity, accent))
                notes += 1

    boundary = (bar + 1 == section.start_bar + section.bars) or (track.fill_every and (bar + 1) % track.fill_every == 0)
    if boundary and section.name != "Intro" and rng.randint(0, 100) < track.complexity:
        fill_notes = [DRUM_NOTES["low_tom"], DRUM_NOTES["mid_tom"], DRUM_NOTES["high_tom"], DRUM_NOTES["snare"]]
        for i, note in enumerate(fill_notes):
            tick = start + bar_len - beat + i * (beat // 4)
            data.add_note(_human_tick(rng, tick, settings.humanize_ticks), max(10, beat // 5), 9, note, _velocity(rng, 78, settings.humanize_velocity, i * 4))
            notes += 1
        if bar + 1 < total_bars:
            data.add_note(start + bar_len - beat // 8, beat // 4, 9, DRUM_NOTES["crash"], _velocity(rng, 92, settings.humanize_velocity, 10))
            notes += 1
    return notes


def _chord_notes_for_bar(chords: Sequence[ChordEvent], bar: int) -> List[int]:
    return chords[min(bar, len(chords) - 1)].notes


def _add_bass_bar(rng: random.Random, data: MidiTrackData, settings: GeneratorSettings, track: TrackSettings, bar: int, section: SectionEvent, chord: ChordEvent) -> int:
    bar_len = _bar_ticks(settings)
    start = bar * bar_len
    beat = settings.ticks_per_beat
    root = chord.notes[0] % 12
    base = 36 + root + 12 * track.octave
    if base < 30:
        base += 12
    if base > 55:
        base -= 12
    pattern = (track.pattern or "auto").lower()
    sixteenth = max(1, beat // 4)
    steps = [0, 2, 4, 6] if "eighth" in pattern or "elise" in pattern else [0, 4, 8, 12]
    if "sync" in pattern or (settings.variation > 55 and "elise" not in pattern):
        steps = [0, 3, 6, 8, 11, 14]
    if "acid" in pattern or "tracker" in pattern:
        steps = [0, 3, 4, 7, 8, 10, 12, 15]
        if settings.variation > 75:
            steps += [rng.choice([1, 5, 13])]
    if "elise" in pattern:
        third = chord.notes[1] - 24
        candidates = [base, base + 7, base + 12, third]
    elif settings.keep_bass_on_roots:
        candidates = [base, base + 12, base + 7]
    else:
        candidates = [base + i for i in [0, 3, 5, 7, 10, 12]]
    if "acid" in pattern or "tracker" in pattern:
        candidates = [base, base + 7, base + 12, base + 10, base + 3, base + 5]
    notes = 0
    for i, step in enumerate(steps):
        if rng.randint(0, 100) > track.density + section.energy // 4:
            continue
        low, high = _role_range(settings, track)
        pitch = _apply_track_pitch(candidates[i % len(candidates)], settings, track, low, high)
        duration = int(sixteenth * (0.95 if ("acid" in pattern or "tracker" in pattern) else (2.8 if len(steps) <= 4 else 1.6)))
        tick = start + step * sixteenth + _swing_offset(step, sixteenth, settings.swing)
        data.add_note(_human_tick(rng, tick, settings.humanize_ticks), duration, track.channel, pitch, _velocity(rng, track.volume, settings.humanize_velocity, 12 if step == 0 else 0))
        notes += 1
    return notes


def _add_chord_bar(rng: random.Random, data: MidiTrackData, settings: GeneratorSettings, track: TrackSettings, bar: int, section: SectionEvent, chord_notes: Sequence[int], previous_voicing: Sequence[int] | None) -> Tuple[int, List[int]]:
    bar_len = _bar_ticks(settings)
    start = bar * bar_len
    beat = settings.ticks_per_beat
    low, high = _role_range(settings, track)
    voicing = voice_lead([n + track.octave * 12 + _track_transpose(track) for n in chord_notes], previous_voicing, low=low, high=high)
    voicing = _fold_notes(voicing, low, high)
    pattern = (track.pattern or "auto").lower()
    notes = 0
    if "guitar" in pattern:
        offsets = [0, beat // 3, beat * 2 // 3, beat, beat + beat // 2, beat * 2 + beat // 3]
        for i, off in enumerate(offsets):
            if rng.randint(0, 100) > track.density:
                continue
            pitch = voicing[i % len(voicing)]
            data.add_note(_human_tick(rng, start + off, settings.humanize_ticks), beat // 2, track.channel, pitch, _velocity(rng, track.volume - 8, settings.humanize_velocity, 8 if i == 0 else 0))
            notes += 1
    elif "gate" in pattern:
        gate_steps = 8 if settings.complexity < 72 else 16
        gate_len = max(1, bar_len // gate_steps)
        for step in range(gate_steps):
            if rng.randint(0, 100) > track.density + (12 if step % 4 == 0 else -8):
                continue
            for pitch in voicing:
                data.add_note(_human_tick(rng, start + step * gate_len, settings.humanize_ticks), max(1, int(gate_len * 0.58)), track.channel, pitch, _velocity(rng, track.volume - 8, settings.humanize_velocity, 8 if step % 4 == 0 else -6))
                notes += 1
    elif "stab" in pattern:
        for off in [0, beat * 2, beat * 3 + beat // 2]:
            for pitch in voicing:
                data.add_note(_human_tick(rng, start + off, settings.humanize_ticks), beat // 2, track.channel, pitch, _velocity(rng, track.volume - 4, settings.humanize_velocity, 10 if off == 0 else 0))
                notes += 1
    else:
        reps = 2 if section.energy < 55 else 4
        for rep in range(reps):
            off = rep * (bar_len // reps)
            if rng.randint(0, 100) > track.density + 10:
                continue
            for pitch in voicing:
                data.add_note(_human_tick(rng, start + off, settings.humanize_ticks), int(bar_len / reps * 0.80), track.channel, pitch, _velocity(rng, track.volume - 10, settings.humanize_velocity, 8 if rep == 0 else 0))
                notes += 1
    return notes, voicing


def _add_pad_bar(rng: random.Random, data: MidiTrackData, settings: GeneratorSettings, track: TrackSettings, bar: int, section: SectionEvent, chord_notes: Sequence[int], previous_voicing: Sequence[int] | None) -> Tuple[int, List[int]]:
    if bar % max(1, settings.harmonic_rhythm) != 0 and previous_voicing:
        return 0, list(previous_voicing)
    bar_len = _bar_ticks(settings)
    start = bar * bar_len
    low, high = _role_range(settings, track)
    voicing = voice_lead([n + 12 + track.octave * 12 + _track_transpose(track) for n in chord_notes], previous_voicing, low=low, high=high)
    voicing = _fold_notes(voicing, low, high)
    length = bar_len * max(1, settings.harmonic_rhythm) - settings.ticks_per_beat // 8
    notes = 0
    for pitch in voicing:
        data.add_note(_human_tick(rng, start, settings.humanize_ticks // 2), length, track.channel, pitch, _velocity(rng, min(track.volume, 82), settings.humanize_velocity, -12))
        notes += 1
    return notes, voicing


def _add_arpeggio_bar(rng: random.Random, data: MidiTrackData, settings: GeneratorSettings, track: TrackSettings, bar: int, section: SectionEvent, chord_notes: Sequence[int]) -> int:
    bar_len = _bar_ticks(settings)
    start = bar * bar_len
    beat = settings.ticks_per_beat
    sixteenth = beat // 4
    low, high = _role_range(settings, track)
    pcs = voice_lead([n + 12 + track.octave * 12 + _track_transpose(track) for n in chord_notes], None, low=low, high=high)
    pcs = _fold_notes(pcs, low, high)
    if len(pcs) < 3:
        pcs = list(pcs) + [pcs[0] + 12]
    pattern = (track.pattern or "auto").lower()
    order = list(range(len(pcs)))
    if "tracker" in pattern:
        rotate = bar % max(1, len(pcs))
        order = order[rotate:] + order[:rotate]
        if bar % 2:
            order = list(reversed(order))
    elif "down" in pattern:
        order = list(reversed(order))
    elif "updown" in pattern:
        order = list(range(len(pcs))) + list(reversed(range(1, len(pcs) - 1)))
    depth = _seed_variation(settings)
    if order and depth > 0.05:
        vrng = random.Random(settings.seed + _track_seed(track) * 251 + bar * 613)
        if vrng.random() < 0.55 * depth:
            rot = vrng.randrange(len(order))
            order = order[rot:] + order[:rot]
        if vrng.random() < 0.25 * depth and "updown" not in pattern:
            order = list(reversed(order))
    notes = 0
    base_steps = 16 if ("tracker" in pattern or section.energy > 48 or settings.complexity > 55) else 8
    rate = _track_arp_rate(settings, track)
    if depth > 0.05 and settings.variation > 25:
        vrng = random.Random(settings.seed + _track_seed(track) * 263 + bar * 719)
        rate *= vrng.choice([0.75, 0.875, 1.0, 1.0, 1.125, 1.25])
    steps = _quantized_step_count(round(base_steps * rate), settings)
    for step in range(int(steps)):
        if rng.randint(0, 100) > track.density + settings.complexity // 5:
            continue
        pitch = pcs[order[step % len(order)]] + (12 if step >= 8 and rng.random() < (settings.variation / (120 if "tracker" in pattern else 180)) else 0)
        pitch = _fold_pitch(pitch, low, high)
        dur = int((bar_len / steps) * 0.78)
        tick = start + int(step * bar_len / steps) + _swing_offset(step, sixteenth, settings.swing)
        data.add_note(_human_tick(rng, tick, settings.humanize_ticks), dur, track.channel, pitch, _velocity(rng, track.volume - 6, settings.humanize_velocity, 8 if step % 4 == 0 else 0))
        notes += 1
    return notes


def _add_melody_bar(rng: random.Random, data: MidiTrackData, settings: GeneratorSettings, track: TrackSettings, bar: int, section: SectionEvent, chord: ChordEvent, motif: Sequence[int]) -> int:
    bar_len = _bar_ticks(settings)
    start = bar * bar_len
    beat = settings.ticks_per_beat
    key_pc = key_to_pc(settings.key)
    low, high = _role_range(settings, track)
    template_name = settings.melody_template or "auto"
    direct_template = template_name != "auto"
    algomusic_template = "algomusic" in template_name.lower()
    density = track.density + (18 if "Hook" in section.name else 0) - (20 if section.name == "Intro" else 0)
    step_count = 8 if settings.complexity < 70 else 16
    step_len = bar_len // step_count
    notes = 0
    last_pitch = None
    chromatic = _chromatic_template(settings) if direct_template else []
    if chromatic:
        used_len = _template_coverage_len(settings, [x for x in chromatic if x is not None])
        phrase = chromatic[:max(1, min(len(chromatic), used_len))]
        step_count = 8
        step_len = max(1, bar_len // step_count)
        base = 60 + key_pc
        if settings.key.upper().startswith("A") and "elise" in template_name.lower():
            base = 69
        phase = 0
        if _seed_variation(settings) > 0.45 and "elise" not in template_name.lower():
            phase = (settings.seed + bar * 3 + _track_seed(track)) % max(1, len(phrase))
        for step in range(step_count):
            idx = (bar * step_count + step + phase) % len(phrase)
            off = phrase[idx]
            if off is None:
                continue
            if "elise" not in template_name.lower() and rng.randint(0, 100) > density + 16:
                continue
            pitch = base + int(off) + track.octave * 12
            pitch = _apply_track_pitch(pitch, settings, track, low, high)
            tick = start + step * step_len
            dur_mult = 0.92 if "elise" in template_name.lower() else 0.72
            data.add_note(_human_tick(rng, tick, settings.humanize_ticks), max(1, int(step_len * dur_mult)), track.channel, pitch, _velocity(rng, track.volume, settings.humanize_velocity, 10 if step in (0, 4) else 0))
            notes += 1
        return notes

    if _is_algomusic_digit_pattern(settings, track):
        row = _algomusic_digit_row(settings, track, bar)
        step_count = max(8, min(32, len(row)))
        step_len = max(1, bar_len // step_count)
        tone_bank = voice_lead([n + track.octave * 12 + _track_transpose(track) for n in chord.notes] + [chord.notes[0] + 12 + track.octave * 12 + _track_transpose(track)], None, low=low, high=high)
        tone_bank = _fold_notes(tone_bank, low, high)
        for step in range(step_count):
            symbol = row[step % len(row)]
            if symbol not in "1234":
                continue
            if rng.randint(0, 100) > density + (10 if step % 4 == 0 else 0):
                continue
            pitch = tone_bank[(int(symbol) - 1) % len(tone_bank)]
            if last_pitch is not None and abs(pitch - last_pitch) > 12 and rng.randint(0, 100) < settings.motif_memory:
                pitch = pitch - 12 if pitch > last_pitch else pitch + 12
            pitch = _fold_pitch(pitch, low, high)
            tick = start + step * step_len + _swing_offset(step, step_len, settings.swing)
            duration = max(1, int(step_len * rng.choice([0.55, 0.75, 0.95])))
            data.add_note(_human_tick(rng, tick, settings.humanize_ticks), duration, track.channel, pitch, _velocity(rng, track.volume, settings.humanize_velocity, 10 if step % 4 == 0 else -2))
            last_pitch = pitch
            notes += 1
        return notes

    for step in range(step_count):
        if not direct_template and rng.randint(0, 100) > density:
            continue
        if direct_template and step >= len(motif) and rng.randint(0, 100) > density:
            continue
        if algomusic_template and step % 4 not in (0, 2) and rng.randint(0, 100) > density + settings.variation // 3:
            continue
        if direct_template:
            degree = _seeded_template_degree(settings, track, bar, step, motif, step_count)
        else:
            degree = motif[(bar * step_count + step) % len(motif)] if motif else rng.randint(0, 7)
        pitch = degree_pitch(degree, key_pc, settings.mode, 4 + track.octave)
        if not direct_template and step % 4 == 0:
            candidates = _fold_notes([n + track.octave * 12 for n in chord.notes], low, high)
            pitch = min(candidates, key=lambda p: abs(pitch - p))
        else:
            pitch = nearest_scale_pitch(pitch, key_pc, settings.mode, low, high)
            pitch = _fold_pitch(pitch, low, high)
        if last_pitch is not None and abs(pitch - last_pitch) > 12 and rng.randint(0, 100) < settings.motif_memory:
            pitch = pitch - 12 if pitch > last_pitch else pitch + 12
        pitch = _apply_track_pitch(pitch, settings, track, low, high)
        duration = int(step_len * (rng.choice([0.45, 0.62, 0.82]) if algomusic_template else rng.choice([0.75, 0.9, 1.4 if step_count == 8 else 1.0])))
        tick = start + step * step_len + _swing_offset(step, step_len, settings.swing)
        data.add_note(_human_tick(rng, tick, settings.humanize_ticks), duration, track.channel, pitch, _velocity(rng, track.volume, settings.humanize_velocity, 12 if step % 4 == 0 else 0))
        last_pitch = pitch
        notes += 1
        if settings.call_response and step in (2, 6, 10, 14) and rng.randint(0, 100) < settings.variation // 2:
            echo_pitch = nearest_scale_pitch(pitch + rng.choice([-7, -5, 4, 7]), key_pc, settings.mode, low, high)
            echo_pitch = _fold_pitch(echo_pitch, low, high)
            data.add_note(_human_tick(rng, tick + step_len // 2, settings.humanize_ticks), max(1, duration // 2), track.channel, echo_pitch, _velocity(rng, track.volume - 18, settings.humanize_velocity, -4))
            notes += 1
    return notes


def _add_counter_bar(rng: random.Random, data: MidiTrackData, settings: GeneratorSettings, track: TrackSettings, bar: int, section: SectionEvent, chord: ChordEvent) -> int:
    if rng.randint(0, 100) > track.density + settings.variation // 3:
        return 0
    bar_len = _bar_ticks(settings)
    start = bar * bar_len
    beat = settings.ticks_per_beat
    key_pc = key_to_pc(settings.key)
    low, high = _role_range(settings, track)
    candidates = scale_pitches(key_pc, settings.mode, low, high)
    chord_pcs = {n % 12 for n in chord.notes}
    candidates = [p for p in candidates if p % 12 in chord_pcs] or candidates
    notes = 0
    for off in [beat, beat * 3]:
        pitch = rng.choice(candidates)
        pitch = _apply_track_pitch(pitch, settings, track, low, high)
        data.add_note(_human_tick(rng, start + off, settings.humanize_ticks), beat, track.channel, pitch, _velocity(rng, track.volume - 12, settings.humanize_velocity, 0))
        notes += 1
    return notes


def _add_texture_bar(rng: random.Random, data: MidiTrackData, settings: GeneratorSettings, track: TrackSettings, bar: int, section: SectionEvent, chord: ChordEvent) -> int:
    if rng.randint(0, 100) > track.density:
        return 0
    bar_len = _bar_ticks(settings)
    start = bar * bar_len
    beat = settings.ticks_per_beat
    notes = 0
    for i in range(1 + settings.variation // 35):
        low, high = _role_range(settings, track)
        pitch = _apply_track_pitch((chord.notes[i % len(chord.notes)] + 12 + track.octave * 12), settings, track, low, high)
        tick = start + rng.randint(0, max(0, bar_len - beat))
        data.add_note(_human_tick(rng, tick, settings.humanize_ticks * 2), beat * rng.choice([1, 2, 3]), track.channel, pitch, _velocity(rng, min(track.volume, 70), settings.humanize_velocity, -18))
        notes += 1
    return notes




def _count_note_ons(tracks: Sequence[MidiTrackData]) -> int:
    return sum(1 for data in tracks for ev in data.events if ev.kind == "note_on" and ev.b > 0)


def _paired_note_events(data: MidiTrackData):
    """Return paired (note_on, note_off, duration) objects for post-processing."""
    open_notes: Dict[Tuple[int, int], List] = {}
    pairs = []
    for ev in sorted(data.events, key=lambda e: (e.tick, 0 if e.kind == "note_on" and e.b > 0 else 1)):
        if ev.kind == "note_on" and ev.b > 0:
            open_notes.setdefault((ev.channel, ev.a), []).append(ev)
        elif ev.kind in ("note_off", "note_on"):
            key = (ev.channel, ev.a)
            if open_notes.get(key):
                on_ev = open_notes[key].pop(0)
                if ev.tick > on_ev.tick:
                    pairs.append((on_ev, ev, ev.tick - on_ev.tick))
    return pairs


def _smooth_note_bursts(tracks: Sequence[MidiTrackData], settings: GeneratorSettings, track_settings: Sequence[TrackSettings]) -> None:
    """Reduce harsh machine-gun note bursts on tonal tracks.

    This is a post-generation musical hygiene pass. It does not quantize the song;
    it only removes very dense repeated triggers where one instrumental line fires
    too many separate notes in a short time window. Chord clusters that start at
    essentially the same tick are preserved.
    """
    if not getattr(settings, "rhythmic_smoothing", True):
        return
    strength = clamp(getattr(settings, "smoothing_strength", 55), 0, 100) / 100.0
    if getattr(settings, "calm_busy_tracks", True):
        strength = max(strength, clamp(getattr(settings, "relaxation_strength", 62), 0, 100) / 100.0 * 0.85)
    if strength <= 0:
        return
    beat = max(1, settings.ticks_per_beat)
    role_factor = {
        "bass": 0.28,
        "melody": 0.38,
        "counter": 0.42,
        "arpeggio": 0.30,
        "chord": 0.55,
        "pad": 0.80,
        "texture": 0.45,
    }
    for idx, data in enumerate(tracks):
        track = track_settings[idx] if idx < len(track_settings) else TrackSettings(name=data.name, role="melody")
        role = (track.role or "melody").lower().strip()
        if role == "drum":
            continue
        if role == "melody" and (track.pattern or "").lower() == "template" and (settings.melody_template or "auto") != "auto":
            continue
        pairs = _paired_note_events(data)
        if not pairs:
            continue
        density_boost = max(0.0, (track.density - 70) / 100.0)
        algo_boost = 0.12 if (_is_algomusic(settings) or "tracker" in (track.pattern or "").lower() or "acid" in (track.pattern or "").lower()) else 0.0
        min_gap = int(beat * role_factor.get(role, 0.38) * (0.45 + strength * 0.95 + density_boost + algo_boost))
        min_gap = max(1, min_gap)
        same_cluster = max(2, int(beat * 0.025))
        drop_ids = set()
        last_cluster_tick = -10**12
        for on_ev, off_ev, duration in sorted(pairs, key=lambda p: (p[0].tick, -p[0].b, p[0].a)):
            if abs(on_ev.tick - last_cluster_tick) <= same_cluster:
                continue
            if on_ev.tick - last_cluster_tick < min_gap:
                drop_ids.add(id(on_ev)); drop_ids.add(id(off_ev))
            else:
                last_cluster_tick = on_ev.tick
        if drop_ids:
            data.events = [ev for ev in data.events if id(ev) not in drop_ids]



def _relax_busy_tracks(tracks: Sequence[MidiTrackData], settings: GeneratorSettings, track_settings: Sequence[TrackSettings]) -> None:
    """Make dense tonal tracks less frantic without changing the song seed.

    This is stricter than the burst smoother: it works per bar and limits how
    many separate note-attack clusters one non-drum track may fire. It is meant
    for cases like fast DnB/Algo/Tracker presets where every channel is on-grid
    but some tracks still feel rushed, chirpy or nervous compared with the rest
    of the arrangement.
    """
    if not getattr(settings, "calm_busy_tracks", True):
        return
    strength = clamp(getattr(settings, "relaxation_strength", 62), 0, 100) / 100.0
    if strength <= 0:
        return
    beat = max(1, int(settings.ticks_per_beat))
    bar_len = max(1, _bar_ticks(settings))
    bpm_penalty = 1 if getattr(settings, "bpm", 120) >= 155 else 0
    role_caps = {
        "bass": (5, 10),
        "melody": (5, 10),
        "counter": (4, 8),
        "arpeggio": (6, 16),
        "chord": (4, 9),
        "pad": (1, 3),
        "texture": (3, 8),
    }
    min_duration_role = {
        "bass": 0.34,
        "melody": 0.42,
        "counter": 0.45,
        "arpeggio": 0.26,
        "chord": 0.48,
        "pad": 1.20,
        "texture": 0.35,
    }
    cluster_window = max(2, int(beat * 0.030))
    for idx, data in enumerate(tracks):
        track = track_settings[idx] if idx < len(track_settings) else TrackSettings(name=data.name, role="melody")
        role = (track.role or "melody").lower().strip()
        if role == "drum":
            continue
        if role == "melody" and (track.pattern or "").lower() == "template" and (settings.melody_template or "auto") != "auto":
            continue
        pairs = _paired_note_events(data)
        if not pairs:
            continue
        by_bar: Dict[int, List[Tuple[object, object, int]]] = {}
        for pair in pairs:
            on_ev, _off_ev, _dur = pair
            by_bar.setdefault(max(0, on_ev.tick) // bar_len, []).append(pair)

        drop_ids = set()
        for _bar, bar_pairs in by_bar.items():
            bar_pairs = sorted(bar_pairs, key=lambda p: (p[0].tick, p[0].a))
            clusters: List[List[Tuple[object, object, int]]] = []
            for pair in bar_pairs:
                on_ev = pair[0]
                if not clusters or abs(on_ev.tick - clusters[-1][0][0].tick) > cluster_window:
                    clusters.append([pair])
                else:
                    clusters[-1].append(pair)
            calm_cap, busy_cap = role_caps.get(role, (5, 10))
            density_allow = 1 if getattr(track, "density", 70) >= 86 and strength < 0.70 else 0
            cap = int(round(busy_cap - (busy_cap - calm_cap) * strength)) + density_allow - bpm_penalty
            if role == "arpeggio":
                cap = max(4, cap)
            else:
                cap = max(1, cap)
            if len(clusters) <= cap:
                continue

            def cluster_priority(cluster: List[Tuple[object, object, int]]) -> float:
                tick = cluster[0][0].tick
                local = tick % bar_len
                vel = sum(max(1, min(127, p[0].b)) for p in cluster) / max(1, len(cluster))
                beat_score = 0.0
                if local % beat == 0:
                    beat_score = 1.20
                elif local % max(1, beat // 2) == 0:
                    beat_score = 0.70
                elif local % max(1, beat // 4) == 0:
                    beat_score = 0.35
                chord_bonus = 0.18 if len(cluster) > 1 else 0.0
                early_bonus = max(0.0, 0.10 - (local / bar_len) * 0.10)
                return beat_score + chord_bonus + early_bonus + vel / 127.0

            keep_ids = {id(c) for c in sorted(clusters, key=cluster_priority, reverse=True)[:cap]}
            for cluster in clusters:
                if id(cluster) in keep_ids:
                    continue
                for on_ev, off_ev, _duration in cluster:
                    drop_ids.add(id(on_ev)); drop_ids.add(id(off_ev))

        min_dur = int(beat * min_duration_role.get(role, 0.40) * (0.45 + strength * 0.65))
        if min_dur > 1:
            for on_ev, off_ev, duration in pairs:
                if id(on_ev) in drop_ids:
                    continue
                if duration < min_dur:
                    off_ev.tick = max(off_ev.tick, on_ev.tick + min_dur)
                    off_ev.tick = min(off_ev.tick, on_ev.tick + max(min_dur, bar_len // 2))

        if drop_ids:
            data.events = [ev for ev in data.events if id(ev) not in drop_ids]

        retained_pairs = _paired_note_events(data)
        if retained_pairs:
            avg_clusters = len(retained_pairs) / max(1, settings.bars)
            loudness_trim = 1.0 - min(0.18, max(0.0, (avg_clusters - role_caps.get(role, (5, 10))[1] * 0.65) * 0.018 * strength))
            if loudness_trim < 0.995:
                for ev in data.events:
                    if ev.kind == "note_on" and ev.b > 0:
                        ev.b = clamp(round(ev.b * loudness_trim), 1, 127)



def _global_arrangement_coherence_pass(tracks: Sequence[MidiTrackData], settings: GeneratorSettings, track_settings: Sequence[TrackSettings]) -> None:
    """Prevent several tonal engines from shouting different rhythms at once.

    Per-track smoothing alone can leave a song busy when melody, arpeggio,
    counter, texture and chords all attack the same small time-cell. This pass
    keeps the structurally important clusters and removes lower-priority clutter.
    """
    if not getattr(settings, "musical_guardrails", True):
        return
    strength = clamp(getattr(settings, "coherence_strength", 84), 0, 100) / 100.0
    if strength <= 0:
        return
    beat = max(1, int(settings.ticks_per_beat))
    bar_len = max(1, _bar_ticks(settings))
    grid = max(1, beat // 4)
    max_clusters = 3 if settings.bpm >= 150 else 4
    if strength > 0.90 and settings.bpm >= 135:
        max_clusters = max(2, max_clusters - 1)
    role_priority = {
        "bass": 6.0,
        "drum": 9.0,
        "chord": 5.2,
        "pad": 4.8,
        "melody": 5.8,
        "arpeggio": 3.6,
        "counter": 3.1,
        "texture": 2.2,
    }
    cluster_window = max(2, int(beat * 0.030))
    clusters_by_cell: Dict[Tuple[int, int], List[dict]] = {}
    for idx, data in enumerate(tracks):
        ts = track_settings[idx] if idx < len(track_settings) else TrackSettings(name=data.name, role="melody")
        role = (ts.role or "melody").lower().strip()
        if role == "drum":
            continue
        pairs = sorted(_paired_note_events(data), key=lambda p: (p[0].tick, p[0].a))
        cur = []
        cur_tick = None
        def flush(cluster):
            if not cluster:
                return
            tick = cluster[0][0].tick
            bar = max(0, tick) // bar_len
            cell = int(round((tick - bar * bar_len) / grid))
            vel = sum(max(1, min(127, p[0].b)) for p in cluster) / max(1, len(cluster))
            local = tick % bar_len
            anchor = 1.5 if local % beat == 0 else (0.8 if local % max(1, beat // 2) == 0 else 0.25)
            protected = role == "melody" and (ts.pattern or "").lower() == "template" and (settings.melody_template or "auto") != "auto"
            score = role_priority.get(role, 3.0) + anchor + (vel / 127.0) + (0.2 if len(cluster) > 1 else 0.0) + (4.0 if protected else 0.0)
            clusters_by_cell.setdefault((bar, cell), []).append({"idx": idx, "role": role, "pairs": cluster[:], "score": score, "protected": protected})
        for pair in pairs:
            tick = pair[0].tick
            if cur_tick is None or abs(tick - cur_tick) <= cluster_window:
                cur.append(pair)
                cur_tick = tick if cur_tick is None else cur_tick
            else:
                flush(cur)
                cur = [pair]
                cur_tick = tick
        flush(cur)
    drop_ids = set()
    for _cell, clusters in clusters_by_cell.items():
        if len(clusters) <= max_clusters:
            continue
        keep = sorted(clusters, key=lambda c: c["score"], reverse=True)[:max_clusters]
        keep_ids = {id(c) for c in keep}
        for c in clusters:
            if id(c) in keep_ids or c.get("protected"):
                continue
            if c["role"] in ("chord", "pad") and not any(k["role"] in ("chord", "pad") for k in keep):
                continue
            for on_ev, off_ev, _duration in c["pairs"]:
                drop_ids.add(id(on_ev)); drop_ids.add(id(off_ev))
    if drop_ids:
        for data in tracks:
            data.events = [ev for ev in data.events if id(ev) not in drop_ids]


def _nearest_pitch_for_pcs(pitch: int, pcs: Sequence[int], low: int, high: int) -> int:
    pcs_set = {int(pc) % 12 for pc in pcs}
    if not pcs_set:
        return _fold_pitch(pitch, low, high)
    candidates = [p for p in range(max(0, low), min(127, high) + 1) if p % 12 in pcs_set]
    if not candidates:
        return _fold_pitch(pitch, low, high)
    return min(candidates, key=lambda p: (abs(p - pitch), p))


def _harmonic_coherence_pass(tracks: Sequence[MidiTrackData], settings: GeneratorSettings, track_settings: Sequence[TrackSettings], chords: Sequence[ChordEvent]) -> None:
    if not getattr(settings, "musical_guardrails", True):
        return
    strength = clamp(getattr(settings, "coherence_strength", 84), 0, 100)
    if strength < 35:
        return
    bar_len = max(1, _bar_ticks(settings))
    beat = max(1, int(settings.ticks_per_beat))
    key_pc = key_to_pc(settings.key)
    scale_pc = {n % 12 for n in scale_pitches(key_pc, settings.mode, 60, 72)}
    for idx, data in enumerate(tracks):
        track = track_settings[idx] if idx < len(track_settings) else TrackSettings(name=data.name, role="melody")
        role = (track.role or "melody").lower().strip()
        if role == "drum":
            continue
        low, high = _role_range(settings, track)
        pairs = _paired_note_events(data)
        for on_ev, off_ev, _duration in pairs:
            bar = max(0, min(len(chords) - 1, int(max(0, on_ev.tick) // bar_len))) if chords else 0
            chord = chords[bar] if chords else None
            chord_pcs = {n % 12 for n in (chord.notes if chord else [])}
            root_pc = (chord.notes[0] % 12) if chord else key_pc
            fifth_pc = (root_pc + 7) % 12
            local = max(0, on_ev.tick) % bar_len
            strong = (local % beat) <= max(2, beat // 24) or abs((local % beat) - beat) <= max(2, beat // 24)
            old_pitch = int(on_ev.a)
            chromatic_pcs = _chromatic_template_pcs(settings) if role == "melody" else set()
            if role == "bass":
                allowed = {root_pc, fifth_pc}
            elif role in ("chord", "pad", "arpeggio"):
                allowed = chord_pcs or scale_pc
            elif role in ("counter", "texture"):
                allowed = chord_pcs if strong else (chord_pcs | scale_pc)
            else:
                allowed = (chord_pcs if strong else (scale_pc | chord_pcs)) | chromatic_pcs
            if chromatic_pcs and old_pitch % 12 in chromatic_pcs:
                folded = _fold_pitch(old_pitch, low, high)
                if folded != old_pitch:
                    on_ev.a = folded; off_ev.a = folded
                continue
            if old_pitch % 12 not in allowed:
                new_pitch = _nearest_pitch_for_pcs(old_pitch, sorted(allowed), low, high)
                on_ev.a = new_pitch
                off_ev.a = new_pitch
            else:
                folded = _fold_pitch(old_pitch, low, high)
                if folded != old_pitch:
                    on_ev.a = folded
                    off_ev.a = folded

def _track_energy(data: MidiTrackData, total_ticks: int) -> float:
    pairs = _paired_note_events(data)
    if not pairs:
        return 0.0
    total_ticks = max(1, int(total_ticks))
    acc = 0.0
    for on_ev, _off_ev, duration in pairs:
        v = max(1, min(127, on_ev.b)) / 127.0
        acc += (v * v) * max(1, duration)
    return math.sqrt(acc / total_ticks)


def _cc7_volume(data: MidiTrackData, fallback: int) -> int:
    for ev in data.events:
        if ev.kind == "cc" and ev.a == 7:
            return clamp(ev.b, 0, 127)
    return clamp(fallback, 0, 127)

def _normalize_track_velocities(tracks: Sequence[MidiTrackData], settings: GeneratorSettings, track_settings: Sequence[TrackSettings] | None = None, total_ticks: int | None = None) -> None:
    """Equalize perceived loudness per track while preserving musical accents.

    v0.4.7 improves the earlier velocity-only pass. It now considers note density
    and note duration, so a very busy arpeggio/gate line is not left much louder
    than a sparser melody merely because its average velocity is similar.
    """
    if not settings.normalize_velocity:
        return
    target = clamp(settings.normalize_target, 35, 120)
    strength = clamp(settings.normalize_strength, 0, 100) / 100.0
    if strength <= 0:
        return
    track_settings = list(track_settings or [])
    total_ticks = int(total_ticks or max((ev.tick for data in tracks for ev in data.events), default=1))
    stats = []
    for idx, data in enumerate(tracks):
        note_ons = [ev for ev in data.events if ev.kind == "note_on" and ev.b > 0]
        if not note_ons:
            continue
        ts = track_settings[idx] if idx < len(track_settings) else TrackSettings(name=data.name, role="melody")
        role = (ts.role or "melody").lower().strip()
        avg = sum(ev.b for ev in note_ons) / max(1, len(note_ons))
        energy = _track_energy(data, total_ticks)
        role_weight = {
            "drum": 0.92,
            "bass": 0.96,
            "chord": 0.92,
            "pad": 0.86,
            "arpeggio": 1.10,
            "melody": 1.00,
            "counter": 1.06,
            "texture": 1.12,
        }.get(role, 1.0)
        stats.append({"data": data, "track": ts, "note_ons": note_ons, "avg": avg, "energy": max(energy * role_weight, 0.0001), "role": role})
    if not stats:
        return
    energies = sorted(x["energy"] for x in stats if x["energy"] > 0)
    median_energy = energies[len(energies) // 2] if energies else 0.01
    for st in stats:
        data = st["data"]; ts = st["track"]; note_ons = st["note_ons"]; avg = st["avg"]; role = st["role"]
        local_target = target
        if role == "drum":
            local_target = min(118, target + 1)
        elif role in ("arpeggio", "counter", "texture"):
            local_target = max(35, target - 5)
        elif role == "pad":
            local_target = max(35, target - 8)
        velocity_factor = max(0.50, min(1.60, local_target / max(1.0, avg)))
        energy_factor = max(0.42, min(1.70, median_energy / st["energy"]))
        factor = (energy_factor * 0.72 + velocity_factor * 0.28)
        for ev in note_ons:
            desired = ev.b * factor
            local_strength = strength
            if ev.b >= avg + 18:
                local_strength *= 0.35
            elif ev.b <= avg - 20:
                local_strength = min(1.0, local_strength * 1.15)
            ev.b = clamp(ev.b + (desired - ev.b) * local_strength, 1, 127)
        current_vol = _cc7_volume(data, getattr(ts, "volume", 96))
        desired_vol = current_vol * (1.0 + (factor - 1.0) * 0.55)
        new_vol = clamp(current_vol + (desired_vol - current_vol) * strength, 20, 127)
        for ev in data.events:
            if ev.kind == "cc" and ev.a == 7:
                ev.b = new_vol

def _default_title(settings: GeneratorSettings, seed: int) -> str:
    return generate_song_name(seed, settings.preset_name)


def _visualizer_event_payload(tracks: Sequence[MidiTrackData], settings: GeneratorSettings, track_settings: Sequence[TrackSettings], end_tick: int) -> Tuple[List[dict], float]:
    seconds_per_tick = 60.0 / max(1.0, float(settings.bpm) * float(settings.ticks_per_beat))
    events: List[dict] = []
    for idx, data in enumerate(tracks):
        ts = track_settings[idx] if idx < len(track_settings) else TrackSettings(name=data.name, role="melody")
        role = (ts.role or "melody").lower().strip()
        for on_ev, _off_ev, duration in _paired_note_events(data):
            if on_ev.b <= 0:
                continue
            events.append({
                "t": round(max(0, on_ev.tick) * seconds_per_tick, 4),
                "p": int(on_ev.a),
                "v": int(clamp(on_ev.b, 1, 127)),
                "d": round(max(1, duration) * seconds_per_tick, 4),
                "role": role,
            })
    events.sort(key=lambda e: e["t"])
    if len(events) > 4500:
        step = max(1, len(events) // 4500)
        kept = events[::step][:4500]
        events = kept
    duration = max(1.0, end_tick * seconds_per_tick)
    return events, duration


def generate_song(settings: GeneratorSettings, output_dir: str | os.PathLike[str], taste_profile: Optional[dict] = None, progress_callback=None) -> SongResult:
    """Generate an extended SoundHelix-inspired MIDI composition."""
    settings = GeneratorSettings.from_dict(settings.to_dict())
    if settings.randomize_seed:
        settings.seed = int(time.time_ns() % 2_147_483_647)
    _apply_musical_guardrails(settings)
    settings.progression = _effective_progression_pattern(settings)
    rng = random.Random(settings.seed)

    if taste_profile and settings.use_rating_memory and settings.randomize_seed:
        if taste_profile.get("positive_count", 0) >= 2:
            settings.bpm = clamp(round((settings.bpm + taste_profile.get("avg_bpm", settings.bpm)) / 2), 40, 240)
            settings.complexity = clamp(round((settings.complexity + taste_profile.get("avg_complexity", settings.complexity)) / 2), 1, 100)
            settings.variation = clamp(round((settings.variation + taste_profile.get("avg_variation", settings.variation)) / 2), 1, 100)
            if rng.random() < 0.35 and taste_profile.get("favorite_progression"):
                settings.custom_progression = taste_profile["favorite_progression"]
            if rng.random() < 0.25 and taste_profile.get("favorite_mode"):
                settings.mode = taste_profile["favorite_mode"]

    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    title = settings.title.strip() or _default_title(settings, settings.seed)
    settings.title = title
    safe = safe_filename(title)
    midi_path = output / f"{safe}.mid"
    json_path = output / f"{safe}.json"
    chord_sheet_path = output / f"{safe}_chords.txt"

    sections = build_sections(settings)
    chords = build_chords(settings, sections)
    bar_len = _bar_ticks(settings)
    end_tick = settings.bars * bar_len
    markers = [(section.start_bar * bar_len, section.name) for section in sections] if settings.add_markers else []

    tracks: List[MidiTrackData] = []
    note_count = 0
    motif = _motif(settings, rng)
    previous_voicings: Dict[str, List[int]] = {}

    for idx, track in enumerate(settings.tracks):
        if progress_callback:
            progress_callback(int(5 + 80 * idx / max(1, len(settings.tracks))), f"Generating {track.name}...")
        if not track.enabled:
            continue
        data = _setup_track(track)
        _add_lfo(data, settings, track, end_tick)
        for bar in range(settings.bars):
            section = section_for_bar(sections, bar)
            active_rng = random.Random(settings.seed + sum(ord(ch) for ch in track.name) * 31 + bar * 97)
            if not _is_active(active_rng, settings, track, section, bar):
                continue
            chord = chords[bar]
            role = track.role.lower().strip()
            if role == "drum":
                note_count += _add_drum_bar(rng, data, settings, track, bar, section, settings.bars)
            elif role == "bass":
                note_count += _add_bass_bar(rng, data, settings, track, bar, section, chord)
            elif role == "chord":
                count, voicing = _add_chord_bar(rng, data, settings, track, bar, section, chord.notes, previous_voicings.get(track.name))
                previous_voicings[track.name] = voicing
                note_count += count
            elif role == "pad":
                count, voicing = _add_pad_bar(rng, data, settings, track, bar, section, chord.notes, previous_voicings.get(track.name))
                previous_voicings[track.name] = voicing
                note_count += count
            elif role == "arpeggio":
                note_count += _add_arpeggio_bar(rng, data, settings, track, bar, section, chord.notes)
            elif role == "counter":
                note_count += _add_counter_bar(rng, data, settings, track, bar, section, chord)
            elif role == "texture":
                note_count += _add_texture_bar(rng, data, settings, track, bar, section, chord)
            else:
                note_count += _add_melody_bar(rng, data, settings, track, bar, section, chord, motif)
        tracks.append(data)

    if getattr(settings, "timing_grid_lock", True):
        if progress_callback:
            progress_callback(84, "Locking timing to musical grid...")
        _snap_timing_to_grid(tracks, settings, settings.tracks)

    if getattr(settings, "rhythmic_smoothing", True):
        if progress_callback:
            progress_callback(86, "Smoothing rapid note bursts...")
        _smooth_note_bursts(tracks, settings, settings.tracks)
        note_count = _count_note_ons(tracks)

    if getattr(settings, "calm_busy_tracks", True):
        if progress_callback:
            progress_callback(87, "Calming busy tonal tracks...")
        _relax_busy_tracks(tracks, settings, settings.tracks)
        note_count = _count_note_ons(tracks)

    if getattr(settings, "musical_guardrails", True):
        if progress_callback:
            progress_callback(88, "Balancing arrangement layers...")
        _global_arrangement_coherence_pass(tracks, settings, settings.tracks)
        if progress_callback:
            progress_callback(89, "Tuning tracks to the current harmony...")
        _harmonic_coherence_pass(tracks, settings, settings.tracks, chords)
        note_count = _count_note_ons(tracks)

    if settings.normalize_velocity:
        if progress_callback:
            progress_callback(89, "Normalizing instrument loudness...")
        _normalize_track_velocities(tracks, settings, settings.tracks, end_tick)

    note_count = _count_note_ons(tracks)

    if progress_callback:
        progress_callback(90, "Writing MIDI...")
    write_midi(str(midi_path), tracks, settings.ticks_per_beat, settings.bpm, settings.beats_per_bar, title, markers)

    chord_sheet_text = make_chord_sheet(title, settings, sections, chords, note_count)
    if settings.export_chord_sheet:
        chord_sheet_path.write_text(chord_sheet_text, encoding="utf-8")
    else:
        chord_sheet_path = Path("")

    result = SongResult(
        title=title,
        seed=settings.seed,
        midi_path=str(midi_path),
        json_path=str(json_path) if settings.export_json else "",
        chord_sheet_path=str(chord_sheet_path) if settings.export_chord_sheet else "",
        sections=sections,
        chords=chords,
        note_count=note_count,
        settings=settings,
    )
    result.visualizer_events, result.visualizer_duration = _visualizer_event_payload(tracks, settings, settings.tracks, end_tick)

    if settings.render_wav or settings.render_mp3:
        wav_path = output / f"{safe}.wav"
        mp3_path = output / f"{safe}.mp3"
        try:
            if progress_callback:
                progress_callback(92, "Rendering WAV with internal synth...")
            result.wav_path = render_tracks_to_wav(
                wav_path, tracks, settings.tracks, settings.bpm, settings.ticks_per_beat, end_tick, settings.audio_sample_rate, progress_callback, settings.normalize_velocity
            )
            result.render_log += "WAV rendered with the built-in lightweight synth. "
            if settings.render_mp3:
                if ffmpeg_available():
                    if progress_callback:
                        progress_callback(99, "Converting WAV to MP3 with ffmpeg...")
                    try:
                        result.mp3_path = convert_wav_to_mp3(result.wav_path, mp3_path)
                        result.render_log += "MP3 rendered via ffmpeg/libmp3lame. "
                    except Exception as mp3_exc:
                        result.mp3_path = ""
                        result.render_log += f"MP3 skipped: {mp3_exc} "
                else:
                    result.render_log += "MP3 skipped: ffmpeg was not found in PATH. "
        except Exception as exc:
            result.render_log += f"Audio render warning: {type(exc).__name__}: {exc}"

    if settings.export_json:
        payload = {
            "application": "PythonSoundHelix",
            "version": "0.4.25",
            "license": "GPLv3",
            "title": result.title,
            "seed": result.seed,
            "midi_path": result.midi_path,
            "wav_path": result.wav_path,
            "mp3_path": result.mp3_path,
            "render_log": result.render_log,
            "note_count": result.note_count,
            "visualizer_duration": result.visualizer_duration,
            "visualizer_events": result.visualizer_events,
            "settings": settings.to_dict(),
            "sections": [asdict(s) for s in sections],
            "chords": [asdict(c) for c in chords],
        }
        json_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    if progress_callback:
        progress_callback(100, "Done")
    return result


def make_chord_sheet(title: str, settings: GeneratorSettings, sections: Sequence[SectionEvent], chords: Sequence[ChordEvent], note_count: int) -> str:
    lines = [
        title,
        "=" * len(title),
        "",
        f"Generated by PythonSoundHelix 0.4.25 (GPLv3)",
        f"Preset: {settings.preset_name}",
        f"Seed: {settings.seed}",
        f"Tempo: {settings.bpm} BPM | Key: {settings.key} {settings.mode} | Bars: {settings.bars}",
        f"Progression: {settings.effective_progression()}",
        f"Notes: {note_count}",
        "",
        "Sections:",
    ]
    for s in sections:
        lines.append(f"  - {s.name}: bars {s.start_bar + 1}-{s.start_bar + s.bars}, energy {s.energy}%")
    lines += ["", "Chord map:"]
    current = None
    buffer: List[str] = []
    for chord in chords:
        if chord.section != current:
            if buffer:
                lines.append("    " + " | ".join(buffer))
                buffer.clear()
            current = chord.section
            lines.append(f"  [{current}]")
        root_name = midi_note_name(chord.notes[0])[:-1]
        buffer.append(f"{chord.bar + 1}:{chord.symbol}({root_name})")
        if len(buffer) >= 8:
            lines.append("    " + " | ".join(buffer))
            buffer.clear()
    if buffer:
        lines.append("    " + " | ".join(buffer))
    lines += [
        "",
        "Note: Template melodies use the configured melody coverage percentage and are generated as transformed contours rather than bundled recordings.",
    ]
    return "\n".join(lines) + "\n"
