
from __future__ import annotations

import argparse
import bisect
import json
import math
import os
import random
import platform
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

from . import __version__
from .audio_render import ffmpeg_available
from .generator import generate_song, MELODY_TEMPLATES
from .history import HistoryStore
from .models import GeneratorSettings, TrackSettings
from .music_theory import GM_PROGRAMS, clamp
from .presets import get_preset, preset_names, xml_reference_files
from .xml_tools import format_summary, summarize_xml

ROOT = Path(__file__).resolve().parents[1]
OUTPUT_DIR = ROOT / "output"
APP_DATA = ROOT / "app_data"
HISTORY_PATH = APP_DATA / "generation_history.json"

ROLE_OPTIONS = ["drum", "bass", "chord", "arpeggio", "melody", "pad", "counter", "texture"]
PATTERN_OPTIONS = [
    "auto", "template", "electro four", "four", "soft four", "broken electro", "sync eighth", "eighth",
    "stab", "block", "long", "updown", "up", "down", "answer", "spark", "guitar",
    "amiga four", "tracker hats", "acid pulse", "random gate", "tracker arp",
    "algomusic drums", "digit progression",
]


def _theme(bg: str, fg: str, panel: str, input_bg: str, accent: str, accent2: str, border: str) -> str:
    return f"""
QMainWindow, QWidget {{ background: {bg}; color: {fg}; font-size: 10pt; }}
QGroupBox {{ background: {panel}; border: 1px solid {border}; border-radius: 9px; margin-top: 12px; padding: 10px; font-weight: bold; }}
QGroupBox::title {{ subcontrol-origin: margin; left: 12px; padding: 0 6px; color: {fg}; }}
QPushButton {{ background: {accent}; color: white; border: 0; border-radius: 7px; padding: 8px 12px; }}
QPushButton:hover {{ background: {accent2}; }}
QPushButton:disabled {{ background: {border}; color: #9499a5; }}
QLineEdit, QTextEdit, QComboBox, QSpinBox, QTableWidget {{ background: {input_bg}; color: {fg}; border: 1px solid {border}; border-radius: 6px; padding: 4px; selection-background-color: {accent}; }}
QHeaderView::section {{ background: {panel}; color: {fg}; padding: 5px; border: 0; }}
QTabWidget::pane {{ border: 1px solid {border}; }}
QTabBar::tab {{ background: {panel}; color: {fg}; padding: 9px 14px; border-top-left-radius: 7px; border-top-right-radius: 7px; }}
QTabBar::tab:selected {{ background: {accent}; color: white; }}
QProgressBar {{ border: 1px solid {border}; border-radius: 6px; text-align: center; background: {input_bg}; }}
QProgressBar::chunk {{ background: {accent}; border-radius: 5px; }}
QToolTip {{ background: {input_bg}; color: {fg}; border: 1px solid {accent}; padding: 5px; }}
"""

THEMES = {
    "Dark": _theme("#17191f", "#e7eaf0", "#1f2330", "#222631", "#2f6fed", "#3d7cff", "#3b4050"),
    "Light": _theme("#f3f5f8", "#17202a", "#ffffff", "#ffffff", "#2866d8", "#497fe5", "#c8ced8"),
    "Hell": _theme("#1c0808", "#ffe8d8", "#2b0b0b", "#370f0f", "#c73518", "#f05a28", "#73251a"),
    "Matrix": _theme("#020805", "#b8ffd2", "#06150c", "#071c10", "#00994f", "#00c96a", "#0b5d35"),
    "Ocean": _theme("#071924", "#e1f7ff", "#0b2838", "#10364a", "#1586b8", "#1ba6df", "#21566f"),
    "Avatar": _theme("#070d18", "#e7f6ff", "#0b1c30", "#102b45", "#1f8cd6", "#4eb7ff", "#28587a"),
    "Amiga MUI": _theme("#8a8a8a", "#050505", "#b8b8b8", "#d8d8d8", "#315f9e", "#4a79bd", "#555555"),
    "MagicWB": _theme("#6f7895", "#080a10", "#9da6c0", "#c2c8d8", "#314a84", "#5a6fa8", "#3a4258"),
    "Synthwave": _theme("#120021", "#ffe6ff", "#24103a", "#2b1648", "#d12cff", "#ff4fd8", "#5d2d7a"),
    "Cyberpunk": _theme("#09060d", "#f6ffe8", "#171022", "#21152f", "#f5c542", "#00e0ff", "#4a375f"),
    "Amber Terminal": _theme("#090500", "#ffd17a", "#1a0f00", "#231400", "#b87300", "#ff9d00", "#5f3500"),
    "Forest": _theme("#07110a", "#e4f4df", "#102015", "#13291a", "#3b8f4a", "#5bbf62", "#31573a"),
    "Commodore 64": _theme("#2d236c", "#d9d3ff", "#5145a6", "#6c5fc7", "#8b7cff", "#b8adff", "#1a1440"),
    "Workbench Blue": _theme("#aeb8cf", "#05070c", "#cbd3e8", "#dde4f3", "#1f4e9b", "#3a72c8", "#5c6680"),
}

TRANSLATIONS: Dict[str, Dict[str, str]] = {
    "en": {
        "tab_generate": "Generate", "tab_tracks": "Tracks", "tab_options": "Options", "tab_finetune": "Fine Tune", "tab_history": "History / Ratings", "tab_xml": "Original XML Inspector", "tab_log": "Log",
        "menu_file": "File", "menu_help": "Help", "save_project_menu": "Save project JSON...", "load_project_menu": "Load project JSON...", "open_output_menu": "Open output folder", "about_menu": "About / License",
        "group_generator": "Generator", "group_harmony": "Harmony / structure", "group_perf": "Performance / advanced", "group_finetune": "Track pitch / arpeggio fine tuning", "group_audio": "Audio / loudness", "group_playback": "MIDI playback", "group_ui": "Interface", "group_presets": "Preset notes",
        "preset": "Preset", "song_title": "Song title", "seed": "Seed", "bpm": "BPM", "bars": "Bars", "beats": "Beats per bar", "tpb": "Ticks per beat",
        "key": "Key", "mode": "Mode", "progression": "Progression", "custom_progression": "Custom progression", "harmonic": "Harmonic rhythm", "sections": "Sections", "melody_template": "Melody template", "melody_coverage": "Melody coverage",
        "complexity": "Complexity", "variation": "Variation", "seed_variation": "Seed variation", "swing": "Swing", "motif": "Motif memory", "accent": "Accent", "human_ticks": "Humanize ticks", "human_vel": "Humanize velocity",
        "musical_guardrails": "Musical guardrails", "coherence_strength": "Coherence strength",
        "lfo": "LFO expression CC", "call_response": "call/response melody", "bass_roots": "bass favors chord roots", "markers": "section markers", "export_json": "export JSON result", "export_chords": "export chord sheet", "rating_memory": "use thumbs-up rating memory",
        "generate": "Generate Song", "play_midi": "Play MIDI", "stop_playback": "Stop playback", "play_audio": "Render/play audio", "start_visualizer": "Start visualizer", "auto_visualizer": "Visualizer on Play MIDI", "open_output": "Open output folder", "save_project": "Save project", "load_project": "Load project", "rate_good": "👍 Rate good", "rate_bad": "👎 Rate bad",
        "global_arp_rate": "Global arpeggio rate", "smart_finetune": "Smart Fine Tune", "reset_finetune": "Reset fine tune", "refresh_finetune": "Refresh from tracks", "finetune_info": "Use this tab to adjust octave/transpose/cents and arpeggio rate per track. These values are stored in project JSON and are applied deterministically when regenerating with the same seed.", "normalize_loudness": "Normalize instrument loudness", "normalize_target": "Target velocity", "normalize_strength": "Normalize strength", "smooth_bursts": "Reduce rapid note bursts", "smoothing_strength": "Burst smoothing strength", "calm_busy_tracks": "Calm busy tracks", "relaxation_strength": "Relaxation strength", "timing_grid_lock": "Lock timing to grid", "timing_grid_strength": "Timing lock strength", "strict_arp_grid": "Strict arpeggio grid", "range_guard": "Auto octave/range guard", "max_melody_pitch": "Max melody pitch", "render_wav": "Render WAV", "render_mp3": "Render MP3", "sample_rate": "Sample rate", "ffmpeg_status": "MP3 encoder", "midi_player_mode": "MIDI playback", "midi_soundfont": "MIDI soundfont", "browse_soundfont": "Browse...", "fluid_status": "SoundFont renderer", "theme": "Theme", "language": "Language",
        "tracks_info": "Tracks are editable. Use the instrument dropdown per row to choose GM instruments. Channel 10 is MIDI drum channel; internally it is shown as 9 because MIDI channels are 0-based.",
        "add_track": "Add melody track", "remove_track": "Remove selected", "normalize_channels": "Normalize channels", "history_play": "Play selected", "history_load": "Load selected settings", "reset_ratings": "Reset all ratings",
        "xml_note": "These XML files are bundled as GPLv3 reference/preset material. The Python generator does not require Java.", "xml_label": "Bundled original SoundHelix XML references",
        "random_seed": "randomize on generate", "history_up": "👍 selected", "history_down": "👎 selected", "ready": "Ready.", "generating": "Generating...", "rendering_audio": "No audio file exists yet; rendering WAV now...", "already_rendering": "Audio rendering is already running.", "no_tracks": "No tracks configured.", "already_running": "Generation is already running.", "generate_first": "Generate a song first.", "internal_player_needed": "Visualizer is intended for the internal player. Select Internal built-in synth or SoundFont playback in Options first.",
        "tooltip_title": "Leave this blank to create a deterministic SoundHelix-style random title during generation.",
        "tooltip_normalize": "Balances instruments by note velocity, channel volume and estimated note density, while preserving strong accents/fills.",
        "tooltip_global_arp_rate": "Controls how many arpeggio notes are generated. 50% is calmer, 100% is normal, 150-200% is busier.", "tooltip_smart_finetune": "Automatically spreads bass, chords, pads, melody and arpeggio into more sensible pitch lanes and reduces overly busy arps.", "tooltip_seed_variation": "Controls how strongly different seeds alter melodic phrase order, arpeggio rows and weak-note details. Higher values make randomize-on-generate more audible.", "tooltip_melody_coverage": "Controls how much of a named contour template is used. 25% uses only the first part; 100% can cycle through the full available contour.",
        "tooltip_smoothing": "Removes excessive rapid retriggers on tonal tracks while keeping true chord clusters and drums intact.",
        "tooltip_smoothing_strength": "Higher values make arpeggios, gates and melodies less hectic by enforcing a larger minimum spacing between separate note attacks.",
        "tooltip_musical_guardrails": "Keeps even extreme parameter combinations more musical: automatic style-aware harmony, timing grid, density limits, loudness balancing and arrangement cleanup.",
        "tooltip_coherence_strength": "Controls how strongly PythonSoundHelix corrects chaotic settings. Higher is more reliably structured; lower allows more experimental chaos.",
        "tooltip_calm_busy_tracks": "Limits dense tonal tracks per bar and softens short blips so individual channels do not sound rushed, chirpy or nervous.",
        "tooltip_relaxation_strength": "Higher values reduce busy arpeggio/melody/texture attacks and lengthen very short tonal notes. Drums are not affected.",
        "tooltip_timing_grid": "Snaps drums, bass, melodies and arpeggios to the same musical grid so generated channels stay synchronized instead of drifting into tuplet-like offsets.",
        "tooltip_timing_grid_strength": "How firmly tonal notes are moved to the common grid. Drums and bass are locked more strongly because they define the groove.",
        "tooltip_strict_arp_grid": "Keeps arpeggios on binary 4/4 divisions such as 8, 16 or 32 notes per bar. Disable only if you intentionally want triplet/polymetric arps.",
        "tooltip_range_guard": "Keeps melody, counter and arpeggio voices in a less piercing register by folding runaway notes down an octave instead of deleting them.",
        "tooltip_max_melody_pitch": "Upper pitch limit for melodic voices when the range guard is enabled. 79 is G5; higher values sound brighter.",
        "tooltip_render_wav": "Renders the MIDI through a lightweight built-in synth to a WAV file. No SoundFont is required.",
        "tooltip_render_mp3": "Creates an MP3 from the rendered WAV when ffmpeg is installed and available in PATH.",
        "tooltip_theme": "Switches the GUI color theme immediately.", "tooltip_language": "Switches visible GUI labels and button text between English and German.",
    },
    "de": {
        "tab_generate": "Generieren", "tab_tracks": "Spuren", "tab_options": "Optionen", "tab_finetune": "Fine-Tuning", "tab_history": "Historie / Bewertungen", "tab_xml": "Original-XML-Inspector", "tab_log": "Log",
        "menu_file": "Datei", "menu_help": "Hilfe", "save_project_menu": "Projekt-JSON speichern...", "load_project_menu": "Projekt-JSON laden...", "open_output_menu": "Ausgabeordner öffnen", "about_menu": "Über / Lizenz",
        "group_generator": "Generator", "group_harmony": "Harmonie / Struktur", "group_perf": "Performance / Erweitert", "group_finetune": "Spur-Tonhöhe / Arpeggio-Finetuning", "group_audio": "Audio / Lautstärke", "group_playback": "MIDI-Wiedergabe", "group_ui": "Oberfläche", "group_presets": "Preset-Hinweise",
        "preset": "Preset", "song_title": "Songtitel", "seed": "Seed", "bpm": "BPM", "bars": "Takte", "beats": "Schläge pro Takt", "tpb": "Ticks pro Schlag",
        "key": "Tonart", "mode": "Modus", "progression": "Akkordfolge", "custom_progression": "Eigene Akkordfolge", "harmonic": "Harmoniewechsel", "sections": "Songteile", "melody_template": "Melodievorlage", "melody_coverage": "Melodieanteil",
        "complexity": "Komplexität", "variation": "Variation", "seed_variation": "Seed-Variation", "swing": "Swing", "motif": "Motivgedächtnis", "accent": "Akzent", "human_ticks": "Timing-Humanize", "human_vel": "Velocity-Humanize",
        "lfo": "LFO Expression CC", "call_response": "Call/Response-Melodie", "bass_roots": "Bass bevorzugt Grundtöne", "markers": "Songteil-Marker", "export_json": "JSON-Ergebnis exportieren", "export_chords": "Akkordblatt exportieren", "rating_memory": "Daumen-hoch-Lerndaten nutzen",
        "generate": "Song generieren", "play_midi": "MIDI abspielen", "stop_playback": "Wiedergabe stoppen", "play_audio": "Audio rendern/abspielen", "start_visualizer": "Visualizer starten", "auto_visualizer": "Visualizer bei MIDI-Play", "open_output": "Ausgabeordner öffnen", "save_project": "Projekt speichern", "load_project": "Projekt laden", "rate_good": "👍 Gut bewerten", "rate_bad": "👎 Schlecht bewerten",
        "musical_guardrails": "Musikalische Leitplanken", "coherence_strength": "Kohärenzstärke",
        "global_arp_rate": "Globale Arpeggio-Rate", "smart_finetune": "Smart Fine Tune", "reset_finetune": "Fine-Tune zurücksetzen", "refresh_finetune": "Aus Spuren aktualisieren", "finetune_info": "In diesem Tab stellst du Oktave/Transponierung/Cents und Arpeggio-Rate pro Spur ein. Die Werte werden im Projekt-JSON gespeichert und beim Neugenerieren mit gleichem Seed deterministisch berücksichtigt.", "normalize_loudness": "Instrument-Lautstärke normalisieren", "normalize_target": "Ziel-Velocity", "normalize_strength": "Normalisierungsstärke", "smooth_bursts": "Schnelle Notenfolgen beruhigen", "smoothing_strength": "Beruhigungsstärke", "calm_busy_tracks": "Gehetzte Spuren beruhigen", "relaxation_strength": "Entspannungsstärke", "timing_grid_lock": "Timing am Raster halten", "timing_grid_strength": "Raster-Stärke", "strict_arp_grid": "Striktes Arpeggio-Raster", "range_guard": "Auto-Oktav-/Tonlagen-Schutz", "max_melody_pitch": "Max. Melodietonhöhe", "render_wav": "WAV rendern", "render_mp3": "MP3 rendern", "sample_rate": "Samplerate", "ffmpeg_status": "MP3-Encoder", "midi_player_mode": "MIDI-Wiedergabe", "midi_soundfont": "MIDI-SoundFont", "browse_soundfont": "Durchsuchen...", "fluid_status": "SoundFont-Renderer", "theme": "Theme", "language": "Sprache",
        "tracks_info": "Spuren sind editierbar. Über das Instrument-Dropdown pro Zeile kannst du GM-Instrumente wählen. MIDI-Kanal 10 ist der Drum-Kanal; intern wird er als 9 angezeigt, weil MIDI-Kanäle 0-basiert sind.",
        "add_track": "Melodiespur hinzufügen", "remove_track": "Auswahl entfernen", "normalize_channels": "Kanäle normalisieren", "history_play": "Auswahl abspielen", "history_load": "Auswahl laden", "reset_ratings": "Bewertungen zurücksetzen",
        "xml_note": "Diese XML-Dateien sind als GPLv3-Referenz-/Presetmaterial enthalten. Der Python-Generator benötigt kein Java.", "xml_label": "Mitgelieferte originale SoundHelix-XML-Referenzen",
        "random_seed": "beim Generieren randomisieren", "history_up": "👍 Auswahl", "history_down": "👎 Auswahl", "ready": "Bereit.", "generating": "Generiere...", "rendering_audio": "Es existiert noch keine Audiodatei; WAV wird jetzt gerendert...", "already_rendering": "Audio-Rendering läuft bereits.", "no_tracks": "Keine Spuren konfiguriert.", "already_running": "Die Generierung läuft bereits.", "generate_first": "Bitte zuerst einen Song generieren.", "internal_player_needed": "Der Visualizer ist für den internen Player gedacht. Wähle in den Optionen zuerst den eingebauten Synth oder SoundFont-Wiedergabe.",
        "tooltip_title": "Leer lassen, damit beim Generieren automatisch ein SoundHelix-artiger Zufallstitel entsteht.",
        "tooltip_normalize": "Balanciert Instrumente über Velocity, Kanal-Lautstärke und geschätzte Notendichte, lässt starke Akzente/Fills aber weitgehend stehen.",
        "tooltip_global_arp_rate": "Steuert, wie viele Arpeggio-Noten erzeugt werden. 50% ist ruhiger, 100% normal, 150-200% dichter.", "tooltip_smart_finetune": "Verteilt Bass, Akkorde, Pads, Melodie und Arpeggio automatisch sinnvoller auf Tonlagen und beruhigt zu dichte Arps.", "tooltip_seed_variation": "Steuert, wie stark unterschiedliche Seeds Melodie-Reihenfolge, Arpeggio-Zeilen und kleine Notendetails verändern. Höhere Werte machen Randomize-on-generate deutlicher hörbar.", "tooltip_smoothing": "Entfernt übertrieben schnelle Wiederholungen auf tonalen Spuren, behält echte Akkord-Cluster und Drums aber bei.",
        "tooltip_smoothing_strength": "Höhere Werte machen Arpeggios, Gates und Melodien entspannter, indem separate Notenanschläge stärker auseinandergehalten werden.",
        "tooltip_musical_guardrails": "Hält selbst extreme Parameterkombinationen musikalisch brauchbarer: automatische harmonische Progressionen, Timing-Raster, Dichte-Limits, Lautstärke-Balancing und Arrangement-Aufräumen.",
        "tooltip_coherence_strength": "Steuert, wie stark PythonSoundHelix wirre Parameter glättet. Höher klingt zuverlässiger strukturiert; niedriger lässt mehr Chaos/Experiment zu.",
        "tooltip_calm_busy_tracks": "Begrenzt dichte tonale Spuren pro Takt und entschärft kurze Blips, damit einzelne Kanäle nicht gehetzt, quirlig oder nervös wirken.",
        "tooltip_relaxation_strength": "Höhere Werte reduzieren dichte Arpeggio-/Melodie-/Textur-Anschläge und verlängern sehr kurze tonale Noten. Drums bleiben unberührt.",
        "tooltip_timing_grid": "Rastet Drums, Bass, Melodien und Arpeggios auf ein gemeinsames musikalisches Timing ein, damit Kanäle nicht gegeneinander in krumme Offsets driften.",
        "tooltip_timing_grid_strength": "Legt fest, wie stark tonale Noten ans gemeinsame Raster gezogen werden. Drums und Bass werden stärker fixiert, weil sie den Groove definieren.",
        "tooltip_strict_arp_grid": "Hält Arpeggios auf geraden 4/4-Teilungen wie 8, 16 oder 32 Noten pro Takt. Nur abschalten, wenn absichtlich triolische/polymetrische Arps gewünscht sind.",
        "tooltip_range_guard": "Hält Melodie-, Antwort- und Arpeggio-Stimmen in einer weniger spitzen Tonlage, indem Ausreißer eine Oktave heruntergefaltet werden.",
        "tooltip_max_melody_pitch": "Obergrenze für melodische Stimmen, wenn der Tonlagen-Schutz aktiv ist. 79 entspricht G5; höhere Werte klingen heller.",
        "tooltip_render_wav": "Rendert das MIDI über einen einfachen eingebauten Synth als WAV. Kein SoundFont nötig.",
        "tooltip_render_mp3": "Erzeugt aus der WAV-Datei eine MP3, wenn ffmpeg installiert und im PATH verfügbar ist.",
        "tooltip_midi_player_mode": "System default opens the MIDI file with your Windows default player, e.g. VLC. Built-in synth renders with the lightweight PythonSoundHelix synth and plays internally. SoundFont mode uses FluidSynth plus your selected SF2/SF3 file.",
        "tooltip_visualizer": "Starts the fullscreen note-reactive wormhole visualizer for internal playback. Esc exits fullscreen.", "tooltip_auto_visualizer": "When enabled, Play MIDI automatically opens the fullscreen visualizer for internal built-in synth or SoundFont playback.",
        "tooltip_midi_soundfont": "Choose an .sf2 or .sf3 SoundFont file. FluidSynth must be installed and available in PATH for SoundFont playback.",
        "tooltip_theme": "Schaltet das Farbschema der GUI sofort um.", "tooltip_language": "Schaltet sichtbare GUI-Texte zwischen Deutsch und Englisch um.",
    },
}


def tr(lang: str, key: str) -> str:
    return TRANSLATIONS.get(lang, TRANSLATIONS["en"]).get(key, TRANSLATIONS["en"].get(key, key))


def open_path(path: str | Path) -> None:
    path_obj = Path(path)
    if not str(path):
        return
    try:
        resolved = str(path_obj.resolve())
    except Exception:
        resolved = str(path)
    if platform.system() == "Windows":
        try:
            os.startfile(resolved)  # type: ignore[attr-defined]
            return
        except Exception:
            try:
                subprocess.Popen(["cmd", "/c", "start", "", resolved], shell=False)
                return
            except Exception:
                pass
    try:
        if 'QDesktopServices' in globals() and QDesktopServices.openUrl(QUrl.fromLocalFile(resolved)):
            return
    except Exception:
        pass
    if platform.system() == "Darwin":
        subprocess.Popen(["open", resolved])
    else:
        subprocess.Popen(["xdg-open", resolved])


try:
    from PyQt6.QtCore import Qt, QThread, pyqtSignal, QUrl, QTimer, QPointF
    from PyQt6.QtGui import QAction, QColor, QPainter, QPen, QBrush, QFont, QDesktopServices
    from PyQt6.QtWidgets import (
        QApplication, QAbstractItemView, QCheckBox, QComboBox, QFileDialog, QFormLayout,
        QGridLayout, QGroupBox, QHBoxLayout, QHeaderView, QLabel, QLineEdit, QMainWindow,
        QMessageBox, QProgressBar, QPushButton, QScrollArea, QSlider, QSpinBox, QTabWidget,
        QTableWidget, QTableWidgetItem, QTextEdit, QVBoxLayout, QWidget,
    )
except Exception:  # pragma: no cover - allows --nogui diagnostics without PyQt6 installed.
    QApplication = None  # type: ignore

    class _DummySignal:
        def connect(self, *args, **kwargs): pass
        def emit(self, *args, **kwargs): pass

    def pyqtSignal(*args, **kwargs):  # type: ignore
        return _DummySignal()

    class _DummyThread:
        def __init__(self, *args, **kwargs): pass
        def start(self): pass
        def isRunning(self): return False

    class _DummyWidget:
        def __init__(self, *args, **kwargs): pass
        def __getattr__(self, name):
            def _method(*args, **kwargs): return None
            return _method

    QThread = _DummyThread  # type: ignore
    QMainWindow = _DummyWidget  # type: ignore
    QTableWidgetItem = _DummyWidget  # type: ignore
    QWidget = _DummyWidget  # type: ignore
    QTimer = _DummyWidget  # type: ignore
    QPointF = _DummyWidget  # type: ignore
    QColor = _DummyWidget  # type: ignore
    QPainter = _DummyWidget  # type: ignore
    QPen = _DummyWidget  # type: ignore
    QBrush = _DummyWidget  # type: ignore
    QFont = _DummyWidget  # type: ignore
    class _DummyQt:
        class ItemFlag:
            ItemIsEditable = 1
        class CheckState:
            Checked = 2
            Unchecked = 0
        class ItemDataRole:
            UserRole = 32
    Qt = _DummyQt()  # type: ignore


try:
    from PyQt6.QtMultimedia import QMediaPlayer, QAudioOutput
except Exception:
    QMediaPlayer = None  # type: ignore
    QAudioOutput = None  # type: ignore

def fluidsynth_available() -> bool:
    return shutil.which("fluidsynth") is not None

def render_with_fluidsynth(midi_path: str, soundfont_path: str, wav_path: str, sample_rate: int) -> tuple[bool, str]:
    exe = shutil.which("fluidsynth")
    if not exe:
        return False, "FluidSynth was not found in PATH."
    if not soundfont_path or not Path(soundfont_path).exists():
        return False, "Selected SoundFont file was not found."
    Path(wav_path).parent.mkdir(parents=True, exist_ok=True)
    cmd = [exe, "-ni", str(soundfont_path), str(midi_path), "-F", str(wav_path), "-r", str(int(sample_rate))]
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=240)
    except Exception as exc:
        return False, f"FluidSynth failed to start: {exc}"
    if proc.returncode != 0 or not Path(wav_path).exists():
        msg = (proc.stderr or proc.stdout or "FluidSynth did not create a WAV file.").strip()
        return False, msg[-1200:]
    return True, f"SoundFont WAV rendered via FluidSynth: {wav_path}"


class VisualizerWindow(QWidget):
    def __init__(self, seed: int = 0, events: Optional[List[dict]] = None, bpm: int = 120, beats_per_bar: int = 4, duration: float = 0.0, parent=None):
        super().__init__(None)
        try:
            self.setWindowFlag(Qt.WindowType.Window, True)
            self.setWindowFlag(Qt.WindowType.FramelessWindowHint, True)
            self.setWindowFlag(Qt.WindowType.WindowStaysOnTopHint, True)
        except Exception:
            pass
        self.rng = random.Random(int(seed) ^ 0x51A7E11A)
        self.seed = int(seed)
        self.phase = self.rng.random() * math.tau
        self.hue_shift = self.rng.randrange(360)
        self.events = sorted(list(events or []), key=lambda e: float(e.get("t", 0.0)))
        self.event_times = [float(e.get("t", 0.0)) for e in self.events]
        self.bpm = max(1, int(bpm or 120))
        self.beats_per_bar = max(1, int(beats_per_bar or 4))
        self.duration = float(duration or (self.event_times[-1] + 4.0 if self.event_times else 180.0))
        self.started_at = time.perf_counter()
        self.energy = 0.0
        self.bass = 0.0
        self.mid = 0.0
        self.treble = 0.0
        self.tunnel = []
        for i in range(180):
            angle = self.rng.random() * math.tau
            radius = self.rng.uniform(0.18, 1.0)
            z = self.rng.random()
            self.tunnel.append((angle, radius, z, self.rng.random()))
        self.rings = [i / 28.0 for i in range(28)]
        self.setWindowTitle("PythonSoundHelix Visualizer - Esc exits fullscreen")
        self.setMinimumSize(900, 600)
        self.timer = QTimer(self)
        self.timer.timeout.connect(self._tick)
        self.timer.start(16)

    def _elapsed(self) -> float:
        elapsed = time.perf_counter() - self.started_at
        if self.duration > 4.0:
            elapsed = elapsed % self.duration
        return elapsed

    def _audio_state(self) -> Dict[str, float]:
        t = self._elapsed()
        window = 0.20
        left = bisect.bisect_left(self.event_times, max(0.0, t - window))
        right = bisect.bisect_right(self.event_times, t + 0.050)
        e = b = m = tr = 0.0
        for ev in self.events[left:right]:
            dt = abs(t - float(ev.get("t", 0.0)))
            weight = max(0.0, 1.0 - dt / max(0.001, window))
            vel = float(ev.get("v", 64)) / 127.0
            pitch = int(ev.get("p", 60))
            amp = vel * weight
            e += amp
            if pitch < 48:
                b += amp
            elif pitch > 72:
                tr += amp
            else:
                m += amp
        beat_phase = (t * self.bpm / 60.0) % 1.0
        beat_pulse = max(0.0, 1.0 - beat_phase * 6.0)
        bar_phase = (t * self.bpm / 60.0 / self.beats_per_bar) % 1.0
        bar_pulse = max(0.0, 1.0 - bar_phase * 10.0)
        e = min(1.0, e / 2.4 + beat_pulse * 0.20 + bar_pulse * 0.20)
        b = min(1.0, b / 1.7 + bar_pulse * 0.18)
        m = min(1.0, m / 1.8)
        tr = min(1.0, tr / 1.6)
        self.energy = max(e, self.energy * 0.88)
        self.bass = max(b, self.bass * 0.84)
        self.mid = max(m, self.mid * 0.86)
        self.treble = max(tr, self.treble * 0.80)
        return {"t": t, "energy": self.energy, "bass": self.bass, "mid": self.mid, "treble": self.treble, "beat": beat_pulse, "bar": bar_pulse}

    def _tick(self) -> None:
        st = self._audio_state()
        self.phase += 0.018 + st["energy"] * 0.055 + st["bass"] * 0.030
        self.update()

    def keyPressEvent(self, event) -> None:
        try:
            if event.key() == Qt.Key.Key_Escape:
                self.close()
                return
        except Exception:
            pass
        try:
            super().keyPressEvent(event)
        except Exception:
            pass

    def showEvent(self, event) -> None:
        try:
            self.setWindowState(self.windowState() | Qt.WindowState.WindowFullScreen)
            QTimer.singleShot(20, self.showFullScreen)
            QTimer.singleShot(60, lambda: self.setWindowState(self.windowState() | Qt.WindowState.WindowFullScreen))
            QTimer.singleShot(90, self.raise_)
            QTimer.singleShot(120, self.activateWindow)
        except Exception:
            pass
        try:
            super().showEvent(event)
        except Exception:
            pass

    def paintEvent(self, event) -> None:
        try:
            st = self._audio_state()
            w = max(1, self.width())
            h = max(1, self.height())
            p = QPainter(self)
            p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
            bg_hue = (self.hue_shift + int(self.phase * 15) + int(st["bass"] * 90)) % 360
            p.fillRect(self.rect(), QColor.fromHsv(bg_hue, 220, 4 + int(st["energy"] * 18)))
            cx, cy = w * 0.5, h * 0.5
            scale = min(w, h)
            focal = scale * (0.70 + st["bass"] * 0.22)
            twist = self.phase * (1.6 + st["mid"] * 1.3)
            speed = 0.45 + st["energy"] * 1.10 + st["treble"] * 0.45
            pulse = 1.0 + st["beat"] * 0.45 + st["bar"] * 0.60 + st["energy"] * 0.55

            p.setBrush(QBrush(QColor(0, 0, 0, 235)))
            p.setPen(Qt.PenStyle.NoPen)
            p.drawEllipse(QPointF(cx, cy), scale * 0.055 * (1.0 + st["bass"] * 0.8), scale * 0.055 * (1.0 + st["bass"] * 0.8))

            for i, (angle0, radius0, z0, color_jit) in enumerate(self.tunnel):
                z = (z0 + self.phase * speed * (0.14 + color_jit * 0.18)) % 1.0
                angle = angle0 + twist * (0.40 + radius0 * 0.65) + z * 5.5
                outer = scale * (0.08 + radius0 * 0.92) / (0.22 + z * 0.92)
                inner = outer * (0.42 - 0.20 * st["energy"])
                x1 = cx + math.cos(angle) * outer
                y1 = cy + math.sin(angle) * outer * 0.76
                x2 = cx + math.cos(angle - 0.17 - st["bass"] * 0.12) * inner
                y2 = cy + math.sin(angle - 0.17 - st["bass"] * 0.12) * inner * 0.76
                hue = (self.hue_shift + int(color_jit * 360) + int(z * 180) + int(st["treble"] * 120)) % 360
                alpha = max(22, min(235, int((1.0 - z) * 210 + st["energy"] * 90)))
                width = 0.8 + (1.0 - z) * 4.5 + st["beat"] * 3.5
                p.setPen(QPen(QColor.fromHsv(hue, 255, 190 + int(st["energy"] * 65), alpha), width))
                p.drawLine(QPointF(x1, y1), QPointF(x2, y2))

            for base_z in self.rings:
                z = (base_z + self.phase * speed * 0.18) % 1.0
                depth = 0.08 + z
                r = focal * (1.15 - z) * pulse
                a = twist + z * 5.2
                wobble_x = math.sin(a * 0.7) * scale * 0.045 * (1.0 - z)
                wobble_y = math.cos(a * 0.9) * scale * 0.035 * (1.0 - z)
                hue = (self.hue_shift + int(z * 220) + int(st["treble"] * 120)) % 360
                alpha = max(30, int(210 * (1.0 - z)))
                p.setPen(QPen(QColor.fromHsv(hue, 240, 165 + int(st["energy"] * 80), alpha), 1.0 + (1.0 - z) * 4.0 + st["bass"] * 3.0))
                p.setBrush(Qt.BrushStyle.NoBrush)
                p.drawEllipse(QPointF(cx + wobble_x, cy + wobble_y), r, r * (0.64 + 0.10 * math.sin(a)))

            for i, (angle0, radius0, z0, color_jit) in enumerate(self.tunnel):
                z = (z0 + self.phase * speed * (0.10 + color_jit * 0.10)) % 1.0
                depth = 0.06 + z
                angle = angle0 + twist * (0.35 + radius0 * 0.40) + math.sin(z * 9.0 + self.phase) * 0.12
                tube_r = scale * (0.18 + radius0 * 0.55) / (0.35 + depth)
                x = cx + math.cos(angle) * tube_r
                y = cy + math.sin(angle) * tube_r * (0.70 + 0.10 * math.sin(self.phase + radius0))
                z_tail = min(1.0, z + 0.035 + st["energy"] * 0.055)
                tail_r = scale * (0.18 + radius0 * 0.55) / (0.35 + z_tail)
                x2 = cx + math.cos(angle - 0.08 - st["bass"] * 0.05) * tail_r
                y2 = cy + math.sin(angle - 0.08 - st["bass"] * 0.05) * tail_r * 0.74
                hue = (self.hue_shift + int(color_jit * 360) + int(st["mid"] * 130) + i * 3) % 360
                val = 150 + int(st["energy"] * 85) + int((1.0 - z) * 55)
                width = 1.0 + (1.0 - z) * 3.5 + st["treble"] * 3.0
                p.setPen(QPen(QColor.fromHsv(hue, 245, min(255, val), 210), width))
                p.drawLine(QPointF(x2, y2), QPointF(x, y))
                if st["bar"] > 0.5 and i % 17 == 0:
                    p.setBrush(QBrush(QColor.fromHsv((hue + 80) % 360, 250, 255, 160)))
                    p.setPen(Qt.PenStyle.NoPen)
                    p.drawEllipse(QPointF(x, y), 2.0 + st["bar"] * 7.0, 2.0 + st["bar"] * 7.0)

            for band in range(5):
                hue = (self.hue_shift + band * 55 + int(self.phase * 35) + int(st["treble"] * 100)) % 360
                p.setPen(QPen(QColor.fromHsv(hue, 230, 140 + int(st["energy"] * 95), 175), 1.2 + band * 0.7 + st["bass"] * 2.5))
                last = None
                for j in range(110):
                    tt = j / 109.0
                    a = tt * math.tau * (1.0 + band * 0.35) + self.phase * (1.4 + band * 0.11)
                    rad = scale * (0.12 + 0.38 * tt) * (1.0 + st["energy"] * 0.20)
                    x = cx + math.cos(a + math.sin(tt * 7 + self.phase) * 0.4) * rad
                    y = cy + math.sin(a * 0.82) * rad * 0.62
                    if last is not None and j % 2 == 0:
                        p.drawLine(QPointF(last[0], last[1]), QPointF(x, y))
                    last = (x, y)

            p.setPen(QPen(QColor(255, 255, 255, 160), 1))
            p.setFont(QFont("Consolas", 12))
            p.drawText(18, 28, f"PythonSoundHelix Visualizer  |  wormhole  |  notes={len(self.events)}  |  Esc exits fullscreen")
            p.end()
        except Exception:
            pass


class GenerateWorker(QThread):
    progress = pyqtSignal(int, str)
    done = pyqtSignal(object)
    failed = pyqtSignal(str)

    def __init__(self, settings: GeneratorSettings, output_dir: Path, taste_profile: dict):
        super().__init__()
        self.settings = settings
        self.output_dir = output_dir
        self.taste_profile = taste_profile

    def run(self) -> None:
        try:
            result = generate_song(self.settings, self.output_dir, self.taste_profile, self.progress.emit)
            self.done.emit(result)
        except Exception as exc:
            self.failed.emit(f"{type(exc).__name__}: {exc}")


class RenderAudioWorker(QThread):
    progress = pyqtSignal(int, str)
    done = pyqtSignal(object)
    failed = pyqtSignal(str)

    def __init__(self, settings: GeneratorSettings, output_dir: Path, taste_profile: dict):
        super().__init__()
        self.settings = settings
        self.output_dir = output_dir
        self.taste_profile = taste_profile

    def run(self) -> None:
        try:
            result = generate_song(self.settings, self.output_dir, self.taste_profile, self.progress.emit)
            self.done.emit(result)
        except Exception as exc:
            self.failed.emit(f"{type(exc).__name__}: {exc}")


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.lang = "en"
        self.theme = "Dark"
        self.labels: Dict[str, QLabel] = {}
        self.group_titles: List[tuple[QGroupBox, str]] = []
        self.tab_keys: List[str] = []
        self.tooltip_widgets: List[tuple[QWidget, str]] = []
        self.history = HistoryStore(HISTORY_PATH)
        self.current_settings = get_preset("Elise Synth") if "Elise Synth" in preset_names() else get_preset(preset_names()[0])
        self.current_result = None
        self.current_record_id = ""
        self.worker: Optional[GenerateWorker] = None
        self.audio_worker: Optional[RenderAudioWorker] = None
        self.audio_output = None
        self.media_player = None
        self.visualizer_window = None
        if QMediaPlayer is not None and QAudioOutput is not None:
            try:
                self.audio_output = QAudioOutput()
                self.media_player = QMediaPlayer()
                self.media_player.setAudioOutput(self.audio_output)
                self.audio_output.setVolume(0.85)
            except Exception:
                self.audio_output = None
                self.media_player = None
        self.setWindowTitle(f"PythonSoundHelix v{__version__} - PyQt6 GPLv3")
        self.resize(1360, 880)
        self._build_ui()
        self.apply_settings_to_ui(self.current_settings)
        self.refresh_history_table()
        self.refresh_xml_list()
        self.apply_theme("Dark")
        self.apply_language("en")

    def _label(self, key: str) -> QLabel:
        lbl = QLabel(key)
        self.labels[key] = lbl
        return lbl

    def _row(self, form: QFormLayout, key: str, widget: QWidget) -> None:
        form.addRow(self._label(key), widget)

    def _group(self, key: str) -> QGroupBox:
        box = QGroupBox(key)
        self.group_titles.append((box, key))
        return box

    def _tip(self, widget: QWidget, key: str) -> None:
        self.tooltip_widgets.append((widget, key))

    def _scroll_tab(self, content: QWidget) -> QScrollArea:
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(content)
        return scroll

    def _add_tab(self, widget: QWidget, key: str) -> None:
        self.tabs.addTab(widget, key)
        self.tab_keys.append(key)

    def _build_ui(self) -> None:
        central = QWidget()
        root = QVBoxLayout(central)
        self.tabs = QTabWidget()
        root.addWidget(self.tabs)
        self.setCentralWidget(central)
        self._build_generate_tab()
        self._build_tracks_tab()
        self._build_fine_tune_tab()
        self._build_options_tab()
        self._build_history_tab()
        self._build_xml_tab()
        self._build_log_tab()
        self._build_menu()

    def _build_menu(self) -> None:
        self.file_menu = self.menuBar().addMenu("File")
        self.save_project_action = QAction("Save project JSON...", self)
        self.save_project_action.triggered.connect(self.save_project)
        self.load_project_action = QAction("Load project JSON...", self)
        self.load_project_action.triggered.connect(self.load_project)
        self.open_output_action = QAction("Open output folder", self)
        self.open_output_action.triggered.connect(lambda: open_path(OUTPUT_DIR))
        self.file_menu.addAction(self.save_project_action)
        self.file_menu.addAction(self.load_project_action)
        self.file_menu.addSeparator()
        self.file_menu.addAction(self.open_output_action)
        self.help_menu = self.menuBar().addMenu("Help")
        self.about_action = QAction("About / License", self)
        self.about_action.triggered.connect(self.show_about)
        self.help_menu.addAction(self.about_action)

    def _build_generate_tab(self) -> None:
        tab = QWidget(); outer = QVBoxLayout(tab)
        top = QHBoxLayout(); outer.addLayout(top)

        general = self._group("group_generator"); form = QFormLayout(general)
        self.preset_combo = QComboBox(); self.preset_combo.addItems(preset_names()); self.preset_combo.currentTextChanged.connect(self.load_preset_by_name)
        self.title_edit = QLineEdit(); self.title_edit.setPlaceholderText("auto title when blank")
        self._tip(self.title_edit, "tooltip_title")
        self.seed_spin = QSpinBox(); self.seed_spin.setRange(0, 2_147_483_647)
        self.random_seed_check = QCheckBox("randomize on generate")
        seed_row = QHBoxLayout(); seed_row.addWidget(self.seed_spin); seed_row.addWidget(self.random_seed_check)
        seed_widget = QWidget(); seed_widget.setLayout(seed_row)
        self.bpm_spin = QSpinBox(); self.bpm_spin.setRange(40, 240)
        self.bars_spin = QSpinBox(); self.bars_spin.setRange(8, 512); self.bars_spin.setSingleStep(8)
        self.beats_spin = QSpinBox(); self.beats_spin.setRange(2, 12)
        self.tpb_spin = QSpinBox(); self.tpb_spin.setRange(12, 1920); self.tpb_spin.setSingleStep(12)
        for key, widget in [("preset", self.preset_combo), ("song_title", self.title_edit), ("seed", seed_widget), ("bpm", self.bpm_spin), ("bars", self.bars_spin), ("beats", self.beats_spin), ("tpb", self.tpb_spin)]:
            self._row(form, key, widget)
        top.addWidget(general, 1)

        harmony = self._group("group_harmony"); hform = QFormLayout(harmony)
        self.key_combo = QComboBox(); self.key_combo.addItems(["C", "C#", "D", "Eb", "E", "F", "F#", "G", "Ab", "A", "Bb", "B"])
        self.mode_combo = QComboBox(); self.mode_combo.addItems(["major", "minor", "dorian", "mixolydian", "phrygian", "lydian", "pentatonic major", "pentatonic minor", "blues"])
        self.progression_combo = QComboBox(); self.progression_combo.setEditable(True)
        self.progression_combo.addItems([
            "Random progression (style-aware)",
            "Major lift: I-V-vi-IV",
            "Major cycle: I-vi-IV-V",
            "Major circle: I-vi-ii-V",
            "Major classic: I-IV-V-I",
            "Major folk: I-IV-I-V",
            "Major canon cycle: I-V-vi-iii-IV-I-IV-V",
            "Major wistful: vi-IV-I-V",
            "Minor drive: i-VII-VI-V",
            "Minor natural loop: i-VII-VI-VII",
            "Minor cinematic: i-VI-III-VII",
            "Minor cadence: i-iv-V-i",
            "Minor classic: i-V-i-iv",
            "Dorian groove: i-IV-v-bVII",
            "Phrygian dark: i-bII-bVII-i",
            "Lydian dream: I-II-I-V",
            "Mixolydian rock: I-bVII-IV-I",
            "Blues rock: I-IV-I-V",
            "Jazz turnaround: ii-V-I-vi",
            "House minor: i-VI-III-VII",
            "Techno pedal: i-i-VI-VII",
            "Ambient drift: I-iii-IV-V",
            "Modal folk: i-bVII-IV-i",
            "SoundHelix legacy harmony A",
            "SoundHelix legacy duration pattern A",
            "SoundHelix legacy simple minor",
        ])
        self.custom_progression = QLineEdit(); self.custom_progression.setPlaceholderText("Optional override, e.g. I,V,vi,IV or Am,G,F,Em")
        self.harmonic_spin = QSpinBox(); self.harmonic_spin.setRange(1, 8)
        self.section_spin = QSpinBox(); self.section_spin.setRange(3, 64)
        self.melody_template_combo = QComboBox(); self.melody_template_combo.addItems(list(MELODY_TEMPLATES.keys()))
        self.melody_coverage_spin = QSpinBox(); self.melody_coverage_spin.setRange(5, 100); self.melody_coverage_spin.setSuffix(" %"); self._tip(self.melody_coverage_spin, "tooltip_melody_coverage")
        for key, widget in [("key", self.key_combo), ("mode", self.mode_combo), ("progression", self.progression_combo), ("custom_progression", self.custom_progression), ("harmonic", self.harmonic_spin), ("sections", self.section_spin), ("melody_template", self.melody_template_combo), ("melody_coverage", self.melody_coverage_spin)]:
            self._row(hform, key, widget)
        top.addWidget(harmony, 1)

        performance = self._group("group_perf"); grid = QGridLayout(performance)
        self.complexity_spin = QSpinBox(); self.complexity_spin.setRange(1, 100)
        self.variation_spin = QSpinBox(); self.variation_spin.setRange(1, 100)
        self.seed_variation_spin = QSpinBox(); self.seed_variation_spin.setRange(0, 100)
        self._tip(self.seed_variation_spin, "tooltip_seed_variation")
        self.swing_spin = QSpinBox(); self.swing_spin.setRange(0, 60)
        self.motif_spin = QSpinBox(); self.motif_spin.setRange(0, 100)
        self.accent_spin = QSpinBox(); self.accent_spin.setRange(0, 100)
        self.human_ticks_spin = QSpinBox(); self.human_ticks_spin.setRange(0, 80)
        self.human_vel_spin = QSpinBox(); self.human_vel_spin.setRange(0, 40)
        self.lfo_check = QCheckBox(); self.call_response_check = QCheckBox(); self.bass_roots_check = QCheckBox(); self.markers_check = QCheckBox(); self.export_json_check = QCheckBox(); self.export_chords_check = QCheckBox(); self.rating_memory_check = QCheckBox()
        for i, (key, widget) in enumerate([("complexity", self.complexity_spin), ("variation", self.variation_spin), ("seed_variation", self.seed_variation_spin), ("swing", self.swing_spin), ("motif", self.motif_spin), ("accent", self.accent_spin), ("human_ticks", self.human_ticks_spin), ("human_vel", self.human_vel_spin)]):
            lbl = self._label(key); grid.addWidget(lbl, i, 0); grid.addWidget(widget, i, 1)
        for i, (key, check) in enumerate([("lfo", self.lfo_check), ("call_response", self.call_response_check), ("bass_roots", self.bass_roots_check), ("markers", self.markers_check), ("export_json", self.export_json_check), ("export_chords", self.export_chords_check), ("rating_memory", self.rating_memory_check)]):
            check.setText(key); grid.addWidget(check, i, 2)
        outer.addWidget(performance)

        buttons = QHBoxLayout()
        self.generate_btn = QPushButton(); self.generate_btn.clicked.connect(self.generate_clicked)
        self.play_btn = QPushButton(); self.play_btn.clicked.connect(self.play_last_midi)
        self.stop_btn = QPushButton(); self.stop_btn.clicked.connect(self.stop_playback)
        self.open_output_btn = QPushButton(); self.open_output_btn.clicked.connect(lambda: open_path(OUTPUT_DIR))
        self.save_project_btn = QPushButton(); self.save_project_btn.clicked.connect(self.save_project)
        self.load_project_btn = QPushButton(); self.load_project_btn.clicked.connect(self.load_project)
        self.thumb_up_btn = QPushButton(); self.thumb_up_btn.clicked.connect(lambda: self.rate_current(1))
        self.thumb_down_btn = QPushButton(); self.thumb_down_btn.clicked.connect(lambda: self.rate_current(-1))
        for b in [self.generate_btn, self.play_btn, self.stop_btn, self.open_output_btn, self.save_project_btn, self.load_project_btn, self.thumb_up_btn, self.thumb_down_btn]:
            buttons.addWidget(b)
        outer.addLayout(buttons)
        self.progress = QProgressBar(); self.progress.setRange(0, 100); outer.addWidget(self.progress)
        self.summary_box = QTextEdit(); self.summary_box.setReadOnly(True); self.summary_box.setMinimumHeight(170); outer.addWidget(self.summary_box)
        self._add_tab(self._scroll_tab(tab), "tab_generate")

    def _build_tracks_tab(self) -> None:
        tab = QWidget(); layout = QVBoxLayout(tab)
        self.tracks_info = QLabel(); self.tracks_info.setWordWrap(True); layout.addWidget(self.tracks_info)
        self.track_table = QTableWidget(0, 12)
        self.track_table.setHorizontalHeaderLabels(["Enabled", "Name", "Role", "Instrument", "Volume", "Pan", "Octave", "Density", "Complexity", "Activity", "Pattern", "Channel"])
        self.track_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.track_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        layout.addWidget(self.track_table)
        row = QHBoxLayout()
        self.add_track_btn = QPushButton(); self.add_track_btn.clicked.connect(self.add_track)
        self.remove_track_btn = QPushButton(); self.remove_track_btn.clicked.connect(self.remove_track)
        self.normalize_channels_btn = QPushButton(); self.normalize_channels_btn.clicked.connect(self.normalize_channels)
        row.addWidget(self.add_track_btn); row.addWidget(self.remove_track_btn); row.addWidget(self.normalize_channels_btn); row.addStretch(1)
        layout.addLayout(row)
        self._add_tab(tab, "tab_tracks")


    def _slider_cell(self, value: int, lo: int, hi: int, suffix: str = "") -> QWidget:
        box = QWidget()
        lay = QHBoxLayout(box)
        lay.setContentsMargins(0, 0, 0, 0)
        slider = QSlider(Qt.Orientation.Horizontal)
        slider.setRange(lo, hi)
        slider.setValue(clamp(value, lo, hi))
        label = QLabel(f"{slider.value()}{suffix}")
        label.setMinimumWidth(52)
        slider.valueChanged.connect(lambda v, lbl=label, suf=suffix: lbl.setText(f"{v}{suf}"))
        lay.addWidget(slider, 1)
        lay.addWidget(label)
        return box

    def _slider_value(self, row: int, col: int, default: int = 0) -> int:
        cell = self.fine_table.cellWidget(row, col)
        if not cell:
            return default
        slider = cell.findChild(QSlider)
        return int(slider.value()) if slider else default

    def _set_slider_value(self, row: int, col: int, value: int) -> None:
        cell = self.fine_table.cellWidget(row, col)
        if not cell:
            return
        slider = cell.findChild(QSlider)
        if slider:
            slider.setValue(value)

    def _build_fine_tune_tab(self) -> None:
        tab = QWidget(); layout = QVBoxLayout(tab)
        info = QLabel(); info.setWordWrap(True); self.finetune_info = info; layout.addWidget(info)
        box = self._group("group_finetune"); form = QFormLayout(box)
        self.global_arp_rate_slider = QSlider(Qt.Orientation.Horizontal); self.global_arp_rate_slider.setRange(25, 240); self.global_arp_rate_slider.setValue(100)
        self.global_arp_rate_spin = QSpinBox(); self.global_arp_rate_spin.setRange(25, 240); self.global_arp_rate_spin.setSuffix(" %"); self.global_arp_rate_spin.setValue(100)
        self.global_arp_rate_slider.valueChanged.connect(self.global_arp_rate_spin.setValue)
        self.global_arp_rate_spin.valueChanged.connect(self.global_arp_rate_slider.setValue)
        self._tip(self.global_arp_rate_slider, "tooltip_global_arp_rate")
        arp_row = QHBoxLayout(); arp_row.addWidget(self.global_arp_rate_slider, 1); arp_row.addWidget(self.global_arp_rate_spin)
        arp_widget = QWidget(); arp_widget.setLayout(arp_row)
        self._row(form, "global_arp_rate", arp_widget)
        layout.addWidget(box)

        self.fine_table = QTableWidget(0, 7)
        self.fine_table.setHorizontalHeaderLabels(["Track", "Role", "Octave", "Transpose", "Fine cents", "Arp rate", "Program"])
        self.fine_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.fine_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        layout.addWidget(self.fine_table)
        row = QHBoxLayout()
        self.smart_finetune_btn = QPushButton(); self.smart_finetune_btn.clicked.connect(self.smart_fine_tune); self._tip(self.smart_finetune_btn, "tooltip_smart_finetune")
        self.reset_finetune_btn = QPushButton(); self.reset_finetune_btn.clicked.connect(self.reset_fine_tune)
        self.refresh_finetune_btn = QPushButton(); self.refresh_finetune_btn.clicked.connect(self.refresh_fine_tune_from_tracks)
        row.addWidget(self.smart_finetune_btn); row.addWidget(self.reset_finetune_btn); row.addWidget(self.refresh_finetune_btn); row.addStretch(1)
        layout.addLayout(row)
        self._add_tab(tab, "tab_finetune")

    def _build_options_tab(self) -> None:
        tab = QWidget(); layout = QVBoxLayout(tab)
        audio = self._group("group_audio"); aform = QFormLayout(audio)
        self.normalize_check = QCheckBox(); self._tip(self.normalize_check, "tooltip_normalize")
        self.normalize_target_spin = QSpinBox(); self.normalize_target_spin.setRange(35, 120)
        self.normalize_strength_spin = QSpinBox(); self.normalize_strength_spin.setRange(0, 100)
        self.musical_guardrails_check = QCheckBox(); self._tip(self.musical_guardrails_check, "tooltip_musical_guardrails")
        self.coherence_strength_spin = QSpinBox(); self.coherence_strength_spin.setRange(0, 100); self._tip(self.coherence_strength_spin, "tooltip_coherence_strength")
        self.smooth_check = QCheckBox(); self._tip(self.smooth_check, "tooltip_smoothing")
        self.smoothing_strength_spin = QSpinBox(); self.smoothing_strength_spin.setRange(0, 100); self._tip(self.smoothing_strength_spin, "tooltip_smoothing_strength")
        self.calm_busy_check = QCheckBox(); self._tip(self.calm_busy_check, "tooltip_calm_busy_tracks")
        self.relaxation_strength_spin = QSpinBox(); self.relaxation_strength_spin.setRange(0, 100); self._tip(self.relaxation_strength_spin, "tooltip_relaxation_strength")
        self.timing_grid_check = QCheckBox(); self._tip(self.timing_grid_check, "tooltip_timing_grid")
        self.timing_grid_strength_spin = QSpinBox(); self.timing_grid_strength_spin.setRange(0, 100); self._tip(self.timing_grid_strength_spin, "tooltip_timing_grid_strength")
        self.strict_arp_grid_check = QCheckBox(); self._tip(self.strict_arp_grid_check, "tooltip_strict_arp_grid")
        self.range_guard_check = QCheckBox(); self._tip(self.range_guard_check, "tooltip_range_guard")
        self.max_melody_pitch_spin = QSpinBox(); self.max_melody_pitch_spin.setRange(60, 96); self._tip(self.max_melody_pitch_spin, "tooltip_max_melody_pitch")
        self.render_wav_check = QCheckBox(); self._tip(self.render_wav_check, "tooltip_render_wav")
        self.render_mp3_check = QCheckBox(); self._tip(self.render_mp3_check, "tooltip_render_mp3")
        self.sample_rate_spin = QSpinBox(); self.sample_rate_spin.setRange(8000, 192000); self.sample_rate_spin.setSingleStep(1000)
        self.ffmpeg_label = QLabel("ffmpeg: " + ("available" if ffmpeg_available() else "not found"))
        for key, widget in [("normalize_loudness", self.normalize_check), ("normalize_target", self.normalize_target_spin), ("normalize_strength", self.normalize_strength_spin), ("musical_guardrails", self.musical_guardrails_check), ("coherence_strength", self.coherence_strength_spin), ("timing_grid_lock", self.timing_grid_check), ("timing_grid_strength", self.timing_grid_strength_spin), ("strict_arp_grid", self.strict_arp_grid_check), ("smooth_bursts", self.smooth_check), ("smoothing_strength", self.smoothing_strength_spin), ("calm_busy_tracks", self.calm_busy_check), ("relaxation_strength", self.relaxation_strength_spin), ("range_guard", self.range_guard_check), ("max_melody_pitch", self.max_melody_pitch_spin), ("render_wav", self.render_wav_check), ("render_mp3", self.render_mp3_check), ("sample_rate", self.sample_rate_spin), ("ffmpeg_status", self.ffmpeg_label)]:
            self._row(aform, key, widget)
        layout.addWidget(audio)

        playback = self._group("group_playback"); pform = QFormLayout(playback)
        self.midi_player_combo = QComboBox()
        self.midi_player_combo.addItem("System default MIDI player", "system")
        self.midi_player_combo.addItem("Internal built-in synth", "builtin")
        self.midi_player_combo.addItem("Internal SoundFont / FluidSynth", "soundfont")
        self._tip(self.midi_player_combo, "tooltip_midi_player_mode")
        self.soundfont_edit = QLineEdit(); self.soundfont_edit.setPlaceholderText("Optional .sf2/.sf3 SoundFont path")
        self._tip(self.soundfont_edit, "tooltip_midi_soundfont")
        self.browse_soundfont_btn = QPushButton(); self.browse_soundfont_btn.clicked.connect(self.browse_soundfont)
        sf_row = QHBoxLayout(); sf_row.addWidget(self.soundfont_edit, 1); sf_row.addWidget(self.browse_soundfont_btn)
        sf_widget = QWidget(); sf_widget.setLayout(sf_row)
        self.fluidsynth_label = QLabel("FluidSynth: " + ("available" if fluidsynth_available() else "not found"))
        self.auto_visualizer_check = QCheckBox(); self.auto_visualizer_check.setChecked(True); self._tip(self.auto_visualizer_check, "tooltip_auto_visualizer")
        self.play_audio_btn = QPushButton(); self.play_audio_btn.clicked.connect(self.play_last_audio)
        self.visualizer_btn = QPushButton(); self.visualizer_btn.clicked.connect(self.start_visualizer); self._tip(self.visualizer_btn, "tooltip_visualizer")
        self._row(pform, "midi_player_mode", self.midi_player_combo)
        self._row(pform, "midi_soundfont", sf_widget)
        self._row(pform, "fluid_status", self.fluidsynth_label)
        self._row(pform, "auto_visualizer", self.auto_visualizer_check)
        pform.addRow("", self.play_audio_btn)
        pform.addRow("", self.visualizer_btn)
        layout.addWidget(playback)

        ui = self._group("group_ui"); uform = QFormLayout(ui)
        self.theme_combo = QComboBox(); self.theme_combo.addItems(list(THEMES.keys())); self.theme_combo.currentTextChanged.connect(self.apply_theme); self._tip(self.theme_combo, "tooltip_theme")
        self.language_combo = QComboBox(); self.language_combo.addItem("English", "en"); self.language_combo.addItem("Deutsch", "de"); self.language_combo.currentIndexChanged.connect(self._language_combo_changed); self._tip(self.language_combo, "tooltip_language")
        self._row(uform, "theme", self.theme_combo); self._row(uform, "language", self.language_combo)
        layout.addWidget(ui)
        notes = self._group("group_presets"); nlayout = QVBoxLayout(notes)
        self.preset_notes = QTextEdit(); self.preset_notes.setReadOnly(True); self.preset_notes.setMinimumHeight(220)
        nlayout.addWidget(self.preset_notes)
        layout.addWidget(notes)
        layout.addStretch(1)
        self._add_tab(self._scroll_tab(tab), "tab_options")

    def _build_history_tab(self) -> None:
        tab = QWidget(); layout = QVBoxLayout(tab)
        self.history_table = QTableWidget(0, 7)
        self.history_table.setHorizontalHeaderLabels(["Rating", "Created", "Title", "Seed", "Notes", "Preset", "MIDI path"])
        self.history_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.history_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        layout.addWidget(self.history_table)
        row = QHBoxLayout()
        self.hist_play_btn = QPushButton(); self.hist_play_btn.clicked.connect(self.play_selected_history)
        self.hist_load_btn = QPushButton(); self.hist_load_btn.clicked.connect(self.load_selected_history_settings)
        self.hist_up_btn = QPushButton("👍 selected"); self.hist_up_btn.clicked.connect(lambda: self.rate_selected_history(1))
        self.hist_down_btn = QPushButton("👎 selected"); self.hist_down_btn.clicked.connect(lambda: self.rate_selected_history(-1))
        self.reset_ratings_btn = QPushButton(); self.reset_ratings_btn.clicked.connect(self.reset_ratings)
        for b in [self.hist_play_btn, self.hist_load_btn, self.hist_up_btn, self.hist_down_btn, self.reset_ratings_btn]: row.addWidget(b)
        row.addStretch(1); layout.addLayout(row)
        self.profile_box = QTextEdit(); self.profile_box.setReadOnly(True); self.profile_box.setMaximumHeight(130); layout.addWidget(self.profile_box)
        self._add_tab(tab, "tab_history")

    def _build_xml_tab(self) -> None:
        tab = QWidget(); layout = QHBoxLayout(tab)
        left = QVBoxLayout(); self.xml_label = QLabel(); self.xml_combo = QComboBox(); self.xml_combo.currentTextChanged.connect(self.xml_selected)
        left.addWidget(self.xml_label); left.addWidget(self.xml_combo)
        self.xml_note = QLabel(); self.xml_note.setWordWrap(True); left.addWidget(self.xml_note); left.addStretch(1)
        layout.addLayout(left, 1)
        self.xml_preview = QTextEdit(); self.xml_preview.setReadOnly(True); layout.addWidget(self.xml_preview, 3)
        self._add_tab(tab, "tab_xml")

    def _build_log_tab(self) -> None:
        tab = QWidget(); layout = QVBoxLayout(tab)
        self.log_box = QTextEdit(); self.log_box.setReadOnly(True); layout.addWidget(self.log_box)
        self._add_tab(tab, "tab_log")

    def apply_language(self, lang: str) -> None:
        self.lang = lang if lang in TRANSLATIONS else "en"
        for idx, key in enumerate(self.tab_keys):
            self.tabs.setTabText(idx, tr(self.lang, key))
        for box, key in self.group_titles:
            box.setTitle(tr(self.lang, key))
        for key, label in self.labels.items():
            label.setText(tr(self.lang, key))
        for widget, key in self.tooltip_widgets:
            widget.setToolTip(tr(self.lang, key))
        self.file_menu.setTitle(tr(self.lang, "menu_file")); self.help_menu.setTitle(tr(self.lang, "menu_help"))
        self.save_project_action.setText(tr(self.lang, "save_project_menu")); self.load_project_action.setText(tr(self.lang, "load_project_menu")); self.open_output_action.setText(tr(self.lang, "open_output_menu")); self.about_action.setText(tr(self.lang, "about_menu"))
        for key, check in [("lfo", self.lfo_check), ("call_response", self.call_response_check), ("bass_roots", self.bass_roots_check), ("markers", self.markers_check), ("export_json", self.export_json_check), ("export_chords", self.export_chords_check), ("rating_memory", self.rating_memory_check), ("normalize_loudness", self.normalize_check), ("musical_guardrails", self.musical_guardrails_check), ("timing_grid_lock", self.timing_grid_check), ("strict_arp_grid", self.strict_arp_grid_check), ("smooth_bursts", self.smooth_check), ("calm_busy_tracks", self.calm_busy_check), ("range_guard", self.range_guard_check), ("render_wav", self.render_wav_check), ("render_mp3", self.render_mp3_check)]:
            check.setText(tr(self.lang, key))
        for key, btn in [("generate", self.generate_btn), ("play_midi", self.play_btn), ("stop_playback", self.stop_btn), ("play_audio", self.play_audio_btn), ("start_visualizer", self.visualizer_btn), ("open_output", self.open_output_btn), ("save_project", self.save_project_btn), ("load_project", self.load_project_btn), ("rate_good", self.thumb_up_btn), ("rate_bad", self.thumb_down_btn), ("add_track", self.add_track_btn), ("remove_track", self.remove_track_btn), ("normalize_channels", self.normalize_channels_btn), ("smart_finetune", self.smart_finetune_btn), ("reset_finetune", self.reset_finetune_btn), ("refresh_finetune", self.refresh_finetune_btn), ("history_play", self.hist_play_btn), ("history_load", self.hist_load_btn), ("history_up", self.hist_up_btn), ("history_down", self.hist_down_btn), ("reset_ratings", self.reset_ratings_btn), ("browse_soundfont", self.browse_soundfont_btn)]:
            btn.setText(tr(self.lang, key))
        self.random_seed_check.setText(tr(self.lang, "random_seed"));
        self.tracks_info.setText(tr(self.lang, "tracks_info")); self.finetune_info.setText(tr(self.lang, "finetune_info")); self.xml_note.setText(tr(self.lang, "xml_note")); self.xml_label.setText(tr(self.lang, "xml_label"))
        if self.summary_box.toPlainText() in ("Ready.", "Bereit."):
            self.summary_box.setText(tr(self.lang, "ready"))
        self._update_preset_notes()

    def _language_combo_changed(self) -> None:
        self.apply_language(self.language_combo.currentData() or "en")

    def apply_theme(self, theme_name: str) -> None:
        self.theme = theme_name if theme_name in THEMES else "Dark"
        if QApplication.instance():
            QApplication.instance().setStyleSheet(THEMES[self.theme])

    def _update_preset_notes(self) -> None:
        names = preset_names()
        self.preset_notes.setText("\n".join(f"- {name}" for name in names))

    def log(self, text: str) -> None:
        self.log_box.append(text)

    def load_preset_by_name(self, name: str) -> None:
        if not name:
            return
        old_mode = self.midi_player_combo.currentData() if hasattr(self, "midi_player_combo") else "system"
        old_sf = self.soundfont_edit.text() if hasattr(self, "soundfont_edit") else ""
        self.current_settings = get_preset(name)
        self.apply_settings_to_ui(self.current_settings, keep_combo=True)
        if hasattr(self, "midi_player_combo"):
            idx = self.midi_player_combo.findData(old_mode)
            self.midi_player_combo.setCurrentIndex(idx if idx >= 0 else 0)
            self.soundfont_edit.setText(old_sf)

    def apply_settings_to_ui(self, s: GeneratorSettings, keep_combo: bool = False, apply_interface: bool = False) -> None:
        if not keep_combo:
            idx = self.preset_combo.findText(s.preset_name)
            if idx >= 0:
                self.preset_combo.setCurrentIndex(idx)
        self.title_edit.setText(s.title)
        self.seed_spin.setValue(s.seed); self.random_seed_check.setChecked(s.randomize_seed)
        self.bpm_spin.setValue(s.bpm); self.bars_spin.setValue(s.bars); self.beats_spin.setValue(s.beats_per_bar); self.tpb_spin.setValue(s.ticks_per_beat)
        self.key_combo.setCurrentText(s.key); self.mode_combo.setCurrentText(s.mode); self.progression_combo.setCurrentText(s.progression); self.custom_progression.setText(s.custom_progression)
        self.harmonic_spin.setValue(s.harmonic_rhythm); self.section_spin.setValue(s.section_count); self.melody_template_combo.setCurrentText(s.melody_template); self.melody_coverage_spin.setValue(getattr(s, "melody_coverage", 100))
        self.complexity_spin.setValue(s.complexity); self.variation_spin.setValue(s.variation); self.seed_variation_spin.setValue(getattr(s, "seed_variation_strength", 70)); self.swing_spin.setValue(s.swing)
        self.motif_spin.setValue(s.motif_memory); self.accent_spin.setValue(s.accent_strength); self.human_ticks_spin.setValue(s.humanize_ticks); self.human_vel_spin.setValue(s.humanize_velocity)
        self.lfo_check.setChecked(s.lfo_expression); self.call_response_check.setChecked(s.call_response); self.bass_roots_check.setChecked(s.keep_bass_on_roots)
        self.markers_check.setChecked(s.add_markers); self.export_json_check.setChecked(s.export_json); self.export_chords_check.setChecked(s.export_chord_sheet); self.rating_memory_check.setChecked(s.use_rating_memory)
        self.normalize_check.setChecked(s.normalize_velocity); self.normalize_target_spin.setValue(s.normalize_target); self.normalize_strength_spin.setValue(s.normalize_strength)
        self.musical_guardrails_check.setChecked(getattr(s, "musical_guardrails", True)); self.coherence_strength_spin.setValue(getattr(s, "coherence_strength", 84))
        self.timing_grid_check.setChecked(getattr(s, "timing_grid_lock", True)); self.timing_grid_strength_spin.setValue(getattr(s, "timing_grid_strength", 92)); self.strict_arp_grid_check.setChecked(getattr(s, "strict_arpeggio_grid", True))
        self.smooth_check.setChecked(getattr(s, "rhythmic_smoothing", True)); self.smoothing_strength_spin.setValue(getattr(s, "smoothing_strength", 55))
        self.calm_busy_check.setChecked(getattr(s, "calm_busy_tracks", True)); self.relaxation_strength_spin.setValue(getattr(s, "relaxation_strength", 62))
        self.range_guard_check.setChecked(getattr(s, "auto_range_guard", True)); self.max_melody_pitch_spin.setValue(getattr(s, "max_melody_pitch", 79))
        self.render_wav_check.setChecked(s.render_wav); self.render_mp3_check.setChecked(s.render_mp3); self.sample_rate_spin.setValue(s.audio_sample_rate)
        if hasattr(self, "midi_player_combo"):
            mode = getattr(s, "midi_playback_mode", "system")
            idx = self.midi_player_combo.findData(mode)
            self.midi_player_combo.setCurrentIndex(idx if idx >= 0 else 0)
            self.soundfont_edit.setText(getattr(s, "midi_soundfont_path", ""))
            if hasattr(self, "auto_visualizer_check"):
                self.auto_visualizer_check.setChecked(bool(getattr(s, "auto_visualizer", True)))
        if apply_interface:
            if s.ui_theme in THEMES:
                self.theme_combo.setCurrentText(s.ui_theme); self.apply_theme(s.ui_theme)
            lang_idx = self.language_combo.findData(s.language)
            if lang_idx >= 0:
                self.language_combo.setCurrentIndex(lang_idx); self.apply_language(s.language)
        else:
            current_theme_idx = self.theme_combo.findText(self.theme)
            if current_theme_idx >= 0 and self.theme_combo.currentIndex() != current_theme_idx:
                self.theme_combo.blockSignals(True); self.theme_combo.setCurrentIndex(current_theme_idx); self.theme_combo.blockSignals(False)
            current_lang_idx = self.language_combo.findData(self.lang)
            if current_lang_idx >= 0 and self.language_combo.currentIndex() != current_lang_idx:
                self.language_combo.blockSignals(True); self.language_combo.setCurrentIndex(current_lang_idx); self.language_combo.blockSignals(False)
        self.populate_track_table(s.tracks)
        self.global_arp_rate_spin.setValue(getattr(s, "global_arpeggio_rate", 100))
        self.populate_fine_tune_table(s.tracks)
        self.summary_box.setText(s.description or tr(self.lang, "ready"))

    def settings_from_ui(self) -> GeneratorSettings:
        s = GeneratorSettings()
        s.preset_name = self.preset_combo.currentText() or "Custom"
        s.title = self.title_edit.text().strip()
        s.seed = self.seed_spin.value(); s.randomize_seed = self.random_seed_check.isChecked()
        s.bpm = self.bpm_spin.value(); s.bars = self.bars_spin.value(); s.beats_per_bar = self.beats_spin.value(); s.ticks_per_beat = self.tpb_spin.value()
        s.key = self.key_combo.currentText(); s.mode = self.mode_combo.currentText(); s.progression = self.progression_combo.currentText().strip() or "Random progression (style-aware)"; s.custom_progression = self.custom_progression.text().strip()
        s.harmonic_rhythm = self.harmonic_spin.value(); s.section_count = self.section_spin.value(); s.melody_template = self.melody_template_combo.currentText(); s.melody_coverage = self.melody_coverage_spin.value()
        s.complexity = self.complexity_spin.value(); s.variation = self.variation_spin.value(); s.seed_variation_strength = self.seed_variation_spin.value(); s.swing = self.swing_spin.value(); s.motif_memory = self.motif_spin.value(); s.accent_strength = self.accent_spin.value(); s.humanize_ticks = self.human_ticks_spin.value(); s.humanize_velocity = self.human_vel_spin.value()
        s.lfo_expression = self.lfo_check.isChecked(); s.call_response = self.call_response_check.isChecked(); s.keep_bass_on_roots = self.bass_roots_check.isChecked(); s.add_markers = self.markers_check.isChecked(); s.export_json = self.export_json_check.isChecked(); s.export_chord_sheet = self.export_chords_check.isChecked(); s.use_rating_memory = self.rating_memory_check.isChecked()
        s.normalize_velocity = self.normalize_check.isChecked(); s.normalize_target = self.normalize_target_spin.value(); s.normalize_strength = self.normalize_strength_spin.value(); s.musical_guardrails = self.musical_guardrails_check.isChecked(); s.coherence_strength = self.coherence_strength_spin.value(); s.global_arpeggio_rate = self.global_arp_rate_spin.value(); s.timing_grid_lock = self.timing_grid_check.isChecked(); s.timing_grid_strength = self.timing_grid_strength_spin.value(); s.strict_arpeggio_grid = self.strict_arp_grid_check.isChecked(); s.rhythmic_smoothing = self.smooth_check.isChecked(); s.smoothing_strength = self.smoothing_strength_spin.value(); s.calm_busy_tracks = self.calm_busy_check.isChecked(); s.relaxation_strength = self.relaxation_strength_spin.value(); s.auto_range_guard = self.range_guard_check.isChecked(); s.max_melody_pitch = self.max_melody_pitch_spin.value(); s.render_wav = self.render_wav_check.isChecked(); s.render_mp3 = self.render_mp3_check.isChecked(); s.audio_sample_rate = self.sample_rate_spin.value(); s.ui_theme = self.theme; s.language = self.lang
        s.midi_playback_mode = self.midi_player_combo.currentData() if hasattr(self, "midi_player_combo") and self.midi_player_combo.currentData() else "system"
        s.midi_soundfont_path = self.soundfont_edit.text().strip() if hasattr(self, "soundfont_edit") else ""
        s.auto_visualizer = self.auto_visualizer_check.isChecked() if hasattr(self, "auto_visualizer_check") else True
        s.tracks = self.tracks_from_table()
        self.apply_fine_tune_to_tracks(s.tracks)
        return s

    def populate_track_table(self, tracks: List[TrackSettings]) -> None:
        self.track_table.setRowCount(0)
        for t in tracks:
            self._append_track_row(t)

    def _item(self, text: str, editable: bool = True) -> QTableWidgetItem:
        item = QTableWidgetItem(text)
        if not editable:
            item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
        return item

    def _program_combo(self, program: int) -> QComboBox:
        combo = QComboBox()
        combo.addItem("Drum Kit / Percussion", 0)
        for name, num in sorted(GM_PROGRAMS.items(), key=lambda kv: kv[1]):
            combo.addItem(f"{num:03d} - {name}", num)
        idx = combo.findData(program)
        combo.setCurrentIndex(idx if idx >= 0 else 0)
        return combo

    def _simple_combo(self, values: List[str], current: str) -> QComboBox:
        combo = QComboBox(); combo.addItems(values)
        idx = combo.findText(current)
        if idx < 0 and current:
            combo.addItem(current)
            idx = combo.findText(current)
        combo.setCurrentIndex(idx if idx >= 0 else 0)
        return combo

    def _append_track_row(self, t: TrackSettings) -> None:
        row = self.track_table.rowCount(); self.track_table.insertRow(row)
        enabled = QTableWidgetItem("yes"); enabled.setCheckState(Qt.CheckState.Checked if t.enabled else Qt.CheckState.Unchecked); self.track_table.setItem(row, 0, enabled)
        self.track_table.setItem(row, 1, self._item(t.name))
        self.track_table.setCellWidget(row, 2, self._simple_combo(ROLE_OPTIONS, t.role))
        self.track_table.setCellWidget(row, 3, self._program_combo(t.program))
        for col, value in [(4, t.volume), (5, t.pan), (6, t.octave), (7, t.density), (8, t.complexity), (9, t.activity), (11, t.channel)]:
            self.track_table.setItem(row, col, self._item(str(value)))
        self.track_table.setCellWidget(row, 10, self._simple_combo(PATTERN_OPTIONS, t.pattern))

    def tracks_from_table(self) -> List[TrackSettings]:
        tracks: List[TrackSettings] = []
        for row in range(self.track_table.rowCount()):
            def text(col: int, default: str = "") -> str:
                item = self.track_table.item(row, col)
                return item.text().strip() if item else default
            def combo_text(col: int, default: str = "") -> str:
                w = self.track_table.cellWidget(row, col)
                return w.currentText() if isinstance(w, QComboBox) else default
            def combo_data(col: int, default: int = 0) -> int:
                w = self.track_table.cellWidget(row, col)
                return int(w.currentData()) if isinstance(w, QComboBox) and w.currentData() is not None else default
            def try_int(value: str, default: int, lo: int, hi: int) -> int:
                try:
                    return clamp(int(value), lo, hi)
                except Exception:
                    return default
            enabled_item = self.track_table.item(row, 0)
            enabled = enabled_item.checkState() == Qt.CheckState.Checked if enabled_item else True
            tracks.append(TrackSettings(
                name=text(1, "Track"), role=combo_text(2, "melody"), enabled=enabled,
                channel=try_int(text(11, "0"), 0, 0, 15), program=combo_data(3, 0),
                volume=try_int(text(4, "90"), 90, 1, 127), pan=try_int(text(5, "64"), 64, 0, 127), octave=try_int(text(6, "0"), 0, -4, 4), density=try_int(text(7, "70"), 70, 0, 100), complexity=try_int(text(8, "55"), 55, 0, 100), activity=try_int(text(9, "80"), 80, 0, 100), pattern=combo_text(10, "auto"),
            ))
        return tracks


    def populate_fine_tune_table(self, tracks: List[TrackSettings]) -> None:
        if not hasattr(self, "fine_table"):
            return
        self.fine_table.setRowCount(0)
        for t in tracks:
            row = self.fine_table.rowCount(); self.fine_table.insertRow(row)
            self.fine_table.setItem(row, 0, self._item(t.name, editable=False))
            self.fine_table.setItem(row, 1, self._item(t.role, editable=False))
            self.fine_table.setCellWidget(row, 2, self._slider_cell(getattr(t, "octave", 0), -4, 4))
            self.fine_table.setCellWidget(row, 3, self._slider_cell(getattr(t, "transpose", 0), -12, 12, " st"))
            self.fine_table.setCellWidget(row, 4, self._slider_cell(getattr(t, "fine_tune_cents", 0), -50, 50, " ct"))
            self.fine_table.setCellWidget(row, 5, self._slider_cell(getattr(t, "arp_rate", 100), 25, 240, " %"))
            program = getattr(t, "program", 0)
            self.fine_table.setItem(row, 6, self._item(f"{program:03d}", editable=False))

    def refresh_fine_tune_from_tracks(self) -> None:
        tracks = self.tracks_from_table()
        old = {}
        if hasattr(self, "fine_table"):
            for row in range(self.fine_table.rowCount()):
                name_item = self.fine_table.item(row, 0)
                if name_item:
                    old[name_item.text()] = (
                        self._slider_value(row, 3, 0),
                        self._slider_value(row, 4, 0), self._slider_value(row, 5, 100)
                    )
        for t in tracks:
            if t.name in old:
                t.transpose, t.fine_tune_cents, t.arp_rate = old[t.name]
        self.populate_fine_tune_table(tracks)

    def apply_fine_tune_to_tracks(self, tracks: List[TrackSettings]) -> None:
        if not hasattr(self, "fine_table"):
            return
        for row, track in enumerate(tracks):
            if row >= self.fine_table.rowCount():
                break
            track.octave = self._slider_value(row, 2, getattr(track, "octave", 0))
            track.transpose = self._slider_value(row, 3, getattr(track, "transpose", 0))
            track.fine_tune_cents = self._slider_value(row, 4, getattr(track, "fine_tune_cents", 0))
            track.arp_rate = self._slider_value(row, 5, getattr(track, "arp_rate", 100))

    def _sync_fine_octaves_to_track_table(self) -> None:
        for row in range(min(self.track_table.rowCount(), self.fine_table.rowCount())):
            self.track_table.setItem(row, 6, self._item(str(self._slider_value(row, 2, 0))))

    def smart_fine_tune(self) -> None:
        self.refresh_fine_tune_from_tracks()
        role_seen: Dict[str, int] = {}
        for row in range(self.fine_table.rowCount()):
            role_item = self.fine_table.item(row, 1)
            role = (role_item.text() if role_item else "melody").lower().strip()
            role_seen[role] = role_seen.get(role, 0) + 1
            nth = role_seen[role]
            if role == "drum":
                octave, transpose, cents, arp = 0, 0, 0, 100
            elif role == "bass":
                octave, transpose, cents, arp = -1, 0, 0, 85
            elif role in ("chord",):
                octave, transpose, cents, arp = 0, 0, 0, 80
            elif role == "pad":
                octave, transpose, cents, arp = -1 if nth == 1 else 0, 0, -3 if nth % 2 else 3, 70
            elif role == "arpeggio":
                octave, transpose, cents, arp = 0, 0, 2 if nth % 2 else -2, 72
            elif role == "counter":
                octave, transpose, cents, arp = -1, 0, -2, 75
            elif role == "texture":
                octave, transpose, cents, arp = -1, 0, 4, 60
            else:
                octave, transpose, cents, arp = 0, 0, 0, 90
            self._set_slider_value(row, 2, octave)
            self._set_slider_value(row, 3, transpose)
            self._set_slider_value(row, 4, cents)
            self._set_slider_value(row, 5, arp)
        self.global_arp_rate_spin.setValue(85)
        self._sync_fine_octaves_to_track_table()
        self.log("Smart Fine Tune applied: pitch lanes, subtle cents and arpeggio rates adjusted.")

    def reset_fine_tune(self) -> None:
        for row in range(self.fine_table.rowCount()):
            self._set_slider_value(row, 2, 0)
            self._set_slider_value(row, 3, 0)
            self._set_slider_value(row, 4, 0)
            self._set_slider_value(row, 5, 100)
        self.global_arp_rate_spin.setValue(100)
        self._sync_fine_octaves_to_track_table()
        self.log("Fine Tune reset.")

    def add_track(self) -> None:
        channels = {t.channel for t in self.tracks_from_table()}
        ch = next((i for i in range(16) if i not in channels and i != 9), 7)
        self._append_track_row(TrackSettings(name="New Melody", role="melody", channel=ch, program=80, volume=88, pan=64, density=60, complexity=55, activity=70))
        self.refresh_fine_tune_from_tracks()

    def remove_track(self) -> None:
        rows = sorted({idx.row() for idx in self.track_table.selectedIndexes()}, reverse=True)
        for row in rows:
            self.track_table.removeRow(row)
        self.refresh_fine_tune_from_tracks()

    def normalize_channels(self) -> None:
        next_channel = 0
        for row in range(self.track_table.rowCount()):
            role = self.track_table.cellWidget(row, 2).currentText().lower() if isinstance(self.track_table.cellWidget(row, 2), QComboBox) else ""
            ch = 9 if role == "drum" else next_channel
            if role != "drum":
                next_channel += 1
                if next_channel == 9: next_channel += 1
                next_channel = min(next_channel, 15)
            self.track_table.setItem(row, 11, self._item(str(ch)))

    def generate_clicked(self) -> None:
        if self.worker and self.worker.isRunning():
            QMessageBox.information(self, "PythonSoundHelix", tr(self.lang, "already_running")); return
        settings = self.settings_from_ui()
        if not settings.tracks:
            QMessageBox.warning(self, "PythonSoundHelix", tr(self.lang, "no_tracks")); return
        self.progress.setValue(0); self.generate_btn.setEnabled(False); self.summary_box.setText(tr(self.lang, "generating"))
        self.worker = GenerateWorker(settings, OUTPUT_DIR, self.history.taste_profile())
        self.worker.progress.connect(self.on_progress); self.worker.done.connect(self.on_done); self.worker.failed.connect(self.on_failed); self.worker.start()

    def on_progress(self, value: int, text: str) -> None:
        self.progress.setValue(value); self.log(text)

    def on_done(self, result) -> None:
        self.generate_btn.setEnabled(True); self.current_result = result; self.seed_spin.setValue(result.seed); self.title_edit.setText(result.title)
        record = self.history.add_result(result.title, result.midi_path, result.settings.to_dict(), result.note_count, result.seed); self.current_record_id = record["id"]
        self.summary_box.setText(self._result_text(result)); self.refresh_history_table(); self.log(f"Generated: {result.midi_path}")
        if result.render_log:
            self.log(result.render_log)

    def on_failed(self, message: str) -> None:
        self.generate_btn.setEnabled(True); self.progress.setValue(0); self.summary_box.setText(message); QMessageBox.critical(self, "Generation failed", message)

    def _result_text(self, result) -> str:
        lines = [result.summary(), "", f"MIDI: {result.midi_path}"]
        if result.wav_path: lines.append(f"WAV: {result.wav_path}")
        if result.mp3_path: lines.append(f"MP3: {result.mp3_path}")
        if result.json_path: lines.append(f"JSON: {result.json_path}")
        if result.chord_sheet_path: lines.append(f"Chord sheet: {result.chord_sheet_path}")
        if result.render_log: lines += ["", f"Audio render: {result.render_log}"]
        lines.append(""); lines.append("Sections: " + ", ".join(f"{s.name} {s.bars} bars" for s in result.sections)); lines.append("First chords: " + ", ".join(f"{c.bar+1}:{c.symbol}" for c in result.chords[:16]))
        return "\n".join(lines)

    def _play_audio_file(self, path: str | Path) -> None:
        path = str(path)
        mode = self.midi_player_combo.currentData() if hasattr(self, "midi_player_combo") else "system"
        if mode in ("builtin", "soundfont") and self.media_player is not None:
            try:
                resolved = str(Path(path).resolve())
                if self.audio_output is not None:
                    self.audio_output.setVolume(0.90)
                self.media_player.stop()
                self.media_player.setSource(QUrl.fromLocalFile(resolved))
                self.media_player.play()
                self.log(f"Internal player: {resolved}")
                QTimer.singleShot(900, lambda: self._media_fallback_check(resolved))
                return
            except Exception as exc:
                self.log(f"Internal player fallback: {exc}")
        self.log(f"Opening with system player: {path}")
        open_path(path)

    def _media_fallback_check(self, resolved: str) -> None:
        try:
            if self.media_player is None:
                return
            err = self.media_player.errorString() if hasattr(self.media_player, "errorString") else ""
            state = str(self.media_player.playbackState()).lower()
            if "playing" not in state:
                detail = f" ({err})" if err else ""
                self.log(f"Internal player did not start cleanly{detail}; opening with system player.")
                open_path(resolved)
        except Exception:
            pass

    def stop_playback(self) -> None:
        stopped = False
        try:
            if self.media_player is not None:
                self.media_player.stop()
                stopped = True
        except Exception as exc:
            self.log(f"Internal player stop failed: {exc}")
        try:
            if self.visualizer_window is not None:
                self.visualizer_window.close()
                self.visualizer_window = None
                stopped = True
        except Exception:
            pass
        if stopped:
            self.log("Playback/visualizer stopped.")
        else:
            self.log("No internal playback was active. If a system player such as VLC was used, stop it in that player.")

    def play_last_midi(self) -> None:
        if not self.current_result or not self.current_result.midi_path:
            QMessageBox.information(self, "PythonSoundHelix", tr(self.lang, "generate_first")); return
        mode = self.midi_player_combo.currentData() if hasattr(self, "midi_player_combo") else "system"
        if mode == "system":
            self.log(f"Opening MIDI with system default player: {self.current_result.midi_path}")
            try:
                open_path(self.current_result.midi_path)
                self._auto_start_visualizer_if_needed()
            except Exception as exc:
                QMessageBox.warning(self, "MIDI playback", f"Could not open MIDI with the system player: {exc}")
            return
        if mode == "builtin":
            path = self._existing_audio_path(prefer_wav=True)
            if path:
                self._play_audio_file(path)
                self._auto_start_visualizer_if_needed()
                return
            self.render_audio_for_playback()
            return
        if mode == "soundfont":
            self.render_soundfont_for_playback()
            return
        self.log(f"Opening MIDI with system default player: {self.current_result.midi_path}")
        open_path(self.current_result.midi_path)

    def _existing_audio_path(self, prefer_wav: bool = False) -> str:
        if not self.current_result:
            return ""
        paths = [self.current_result.wav_path, self.current_result.mp3_path] if prefer_wav else [self.current_result.mp3_path, self.current_result.wav_path]
        for path in paths:
            if path and Path(path).exists():
                return path
        return ""

    def play_last_audio(self) -> None:
        path = self._existing_audio_path()
        if path:
            self._play_audio_file(path); return
        if self.current_result and self.current_result.midi_path:
            self.render_audio_for_playback(); return
        QMessageBox.information(self, "PythonSoundHelix", tr(self.lang, "generate_first"))

    def render_audio_for_playback(self) -> None:
        if self.audio_worker and self.audio_worker.isRunning():
            QMessageBox.information(self, "PythonSoundHelix", tr(self.lang, "already_rendering")); return
        if not self.current_result:
            QMessageBox.information(self, "PythonSoundHelix", tr(self.lang, "generate_first")); return
        settings = GeneratorSettings.from_dict(self.current_result.settings.to_dict())
        settings.title = self.current_result.title
        settings.seed = self.current_result.seed
        settings.randomize_seed = False
        settings.render_wav = True
        settings.render_mp3 = self.render_mp3_check.isChecked()
        settings.audio_sample_rate = self.sample_rate_spin.value()
        self.summary_box.append("\n" + tr(self.lang, "rendering_audio"))
        self.progress.setValue(0)
        self.play_audio_btn.setEnabled(False)
        self.generate_btn.setEnabled(False)
        self.audio_worker = RenderAudioWorker(settings, OUTPUT_DIR, self.history.taste_profile())
        self.audio_worker.progress.connect(self.on_progress)
        self.audio_worker.done.connect(self.on_audio_done)
        self.audio_worker.failed.connect(self.on_audio_failed)
        self.audio_worker.start()

    def on_audio_done(self, result) -> None:
        self.play_audio_btn.setEnabled(True)
        self.generate_btn.setEnabled(True)
        self.current_result = result
        self.summary_box.setText(self._result_text(result))
        if result.render_log:
            self.log(result.render_log)
        path = self._existing_audio_path()
        if path:
            self.log(f"Audio ready: {path}")
            self._play_audio_file(path)
            self._auto_start_visualizer_if_needed()
        else:
            QMessageBox.warning(self, "PythonSoundHelix", result.render_log or "Audio rendering finished, but no WAV/MP3 file was created.")

    def on_audio_failed(self, message: str) -> None:
        self.play_audio_btn.setEnabled(True)
        self.generate_btn.setEnabled(True)
        self.progress.setValue(0)
        QMessageBox.critical(self, "Audio render failed", message)

    def render_soundfont_for_playback(self) -> None:
        if not self.current_result or not self.current_result.midi_path:
            QMessageBox.information(self, "PythonSoundHelix", tr(self.lang, "generate_first")); return
        sf = self.soundfont_edit.text().strip() if hasattr(self, "soundfont_edit") else ""
        if not sf or not Path(sf).exists():
            QMessageBox.warning(self, "PythonSoundHelix", "Please select an existing .sf2/.sf3 SoundFont in Options first."); return
        if not fluidsynth_available():
            QMessageBox.warning(self, "PythonSoundHelix", "FluidSynth was not found in PATH. Install FluidSynth or choose another MIDI playback mode."); return
        midi = Path(self.current_result.midi_path)
        out = OUTPUT_DIR / f"{midi.stem}_soundfont.wav"
        self.progress.setValue(0)
        self.log(f"Rendering MIDI with SoundFont: {sf}")
        ok, msg = render_with_fluidsynth(str(midi), sf, str(out), self.sample_rate_spin.value() if hasattr(self, "sample_rate_spin") else 44100)
        if ok:
            self.progress.setValue(100)
            self.log(msg)
            self._play_audio_file(out)
            self._auto_start_visualizer_if_needed()
        else:
            self.progress.setValue(0)
            self.log("SoundFont render failed: " + msg)
            QMessageBox.warning(self, "SoundFont render failed", msg)


    def _visualizer_enabled_for_play(self) -> bool:
        try:
            return bool(self.auto_visualizer_check.isChecked())
        except Exception:
            return True

    def _open_visualizer_window(self, silent: bool = False) -> bool:
        if not self.current_result or not self.current_result.midi_path:
            if not silent:
                QMessageBox.information(self, "PythonSoundHelix", tr(self.lang, "generate_first"))
            return False
        mode = self.midi_player_combo.currentData() if hasattr(self, "midi_player_combo") else "system"
        try:
            if self.visualizer_window is not None and self.visualizer_window.isVisible():
                self.visualizer_window.raise_()
                self.visualizer_window.activateWindow()
                return True
        except Exception:
            pass
        try:
            seed = int(getattr(self.current_result, "seed", 0) or self.seed_spin.value())
            events = list(getattr(self.current_result, "visualizer_events", []) or [])
            duration = float(getattr(self.current_result, "visualizer_duration", 0.0) or 0.0)
            self.visualizer_window = VisualizerWindow(seed, events, self.current_result.settings.bpm, self.current_result.settings.beats_per_bar, duration, None)
            self.visualizer_window.showFullScreen()
            self.visualizer_window.raise_()
            self.visualizer_window.activateWindow()
            self.log(f"Visualizer started with {len(events)} note events. Press Esc to exit fullscreen.")
            return True
        except Exception as exc:
            if not silent:
                QMessageBox.warning(self, "Visualizer", f"Could not start visualizer: {exc}")
            return False

    def _auto_start_visualizer_if_needed(self) -> None:
        if self._visualizer_enabled_for_play():
            self._open_visualizer_window(silent=True)

    def start_visualizer(self) -> None:
        opened = self._open_visualizer_window(silent=False)
        if not opened:
            return
        try:
            if self.media_player is not None and "playing" in str(self.media_player.playbackState()).lower():
                return
        except Exception:
            pass
        self.play_last_midi()

    def browse_soundfont(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Choose MIDI SoundFont", str(ROOT), "SoundFont files (*.sf2 *.sf3);;All files (*.*)")
        if path:
            self.soundfont_edit.setText(path)

    def rate_current(self, rating: int) -> None:
        if not self.current_record_id:
            QMessageBox.information(self, "PythonSoundHelix", "No generated song selected for rating."); return
        self.history.rate(self.current_record_id, rating); self.refresh_history_table()

    def refresh_history_table(self) -> None:
        rows = self.history.rows(); self.history_table.setRowCount(0)
        for r in rows:
            row = self.history_table.rowCount(); self.history_table.insertRow(row)
            rating = "👍" if r.get("rating") == 1 else "👎" if r.get("rating") == -1 else ""
            values = [rating, r.get("created_at", ""), r.get("title", ""), str(r.get("seed", "")), str(r.get("note_count", "")), r.get("settings", {}).get("preset_name", ""), r.get("midi_path", "")]
            for col, value in enumerate(values):
                item = self._item(str(value), editable=False); item.setData(Qt.ItemDataRole.UserRole, r.get("id", "")); self.history_table.setItem(row, col, item)
        self.profile_box.setText(json.dumps(self.history.taste_profile(), indent=2, ensure_ascii=False))

    def _selected_history_record(self) -> Optional[Dict[str, Any]]:
        rows = {idx.row() for idx in self.history_table.selectedIndexes()}
        if not rows: return None
        item = self.history_table.item(min(rows), 0); rid = item.data(Qt.ItemDataRole.UserRole) if item else ""
        for record in self.history.records:
            if record.get("id") == rid: return record
        return None

    def play_selected_history(self) -> None:
        r = self._selected_history_record()
        if r and r.get("midi_path"): open_path(r["midi_path"])

    def load_selected_history_settings(self) -> None:
        r = self._selected_history_record()
        if r and r.get("settings"): self.apply_settings_to_ui(GeneratorSettings.from_dict(r["settings"]))

    def rate_selected_history(self, rating: int) -> None:
        r = self._selected_history_record()
        if r: self.history.rate(r["id"], rating); self.refresh_history_table()

    def reset_ratings(self) -> None:
        self.history.reset_ratings(); self.refresh_history_table()

    def save_project(self) -> None:
        path, _ = QFileDialog.getSaveFileName(self, "Save PythonSoundHelix project", str(ROOT / "project.psh.json"), "PythonSoundHelix JSON (*.json)")
        if path: Path(path).write_text(json.dumps(self.settings_from_ui().to_dict(), indent=2, ensure_ascii=False), encoding="utf-8")

    def load_project(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Load PythonSoundHelix project", str(ROOT), "PythonSoundHelix JSON (*.json)")
        if path: self.apply_settings_to_ui(GeneratorSettings.from_dict(json.loads(Path(path).read_text(encoding="utf-8"))))

    def refresh_xml_list(self) -> None:
        self.xml_combo.clear(); files = xml_reference_files(ROOT)
        for path in files: self.xml_combo.addItem(path.name, str(path))
        if files: self.xml_selected(files[0].name)

    def xml_selected(self, _: str) -> None:
        path = self.xml_combo.currentData()
        if not path: return
        try: self.xml_preview.setText(format_summary(summarize_xml(path)))
        except Exception as exc: self.xml_preview.setText(str(exc))

    def show_about(self) -> None:
        QMessageBox.about(self, "About PythonSoundHelix", f"""PythonSoundHelix v{__version__}

GPLv3 Python/PyQt6 project inspired by SoundHelix.

Original SoundHelix project: https://www.soundhelix.com/
Original SoundHelix author: Thomas Schürger.
Original source archive reference: soundhelix-code-r896-trunk / SoundHelix 0.10u.
Historical inspiration: Thomas Schürger's Amiga AlgoMusic 2.4, especially its Techno/House algorithmic-generator idea.

PythonSoundHelix project/update origin: https://github.com/zeittresor/PythonSH
Associated account/root: https://github.com/zeittresor
Important attribution note: PythonSoundHelix is an independent Python/PyQt6 reimplementation and expansion inspired by SoundHelix. It is not authored by Thomas Schürger and is not the original SoundHelix project.

This Python version writes Standard MIDI Files without Java and adds GUI presets, random SoundHelix-style song titles, instrument dropdowns, musical range guard, loudness normalization, timing-grid lock, relaxed-track smoothing, WAV/MP3 rendering, Amiga/MagicWB-inspired themes, language switching, rating memory, project JSON and chord sheets. v0.4.25 improves default musical coherence, MIDI/audio playback fallbacks and note-reactive fullscreen visualizer behavior.""")


def run_gui() -> int:
    if QApplication is None:
        print("PyQt6 is not installed. Run install_windows.bat first, or pip install -r requirements.txt", file=sys.stderr)
        return 2
    app = QApplication(sys.argv)
    win = MainWindow(); win.show()
    return app.exec()


def run_cli(args: argparse.Namespace) -> int:
    settings = get_preset(args.preset) if args.preset else get_preset(preset_names()[0])
    if args.seed is not None: settings.seed = args.seed
    settings.randomize_seed = args.random_seed
    if args.title: settings.title = args.title
    if args.bpm: settings.bpm = args.bpm
    if args.bars: settings.bars = args.bars
    settings.normalize_velocity = args.normalize or settings.normalize_velocity
    settings.musical_guardrails = not args.no_musical_guardrails
    if args.coherence_strength is not None:
        settings.coherence_strength = clamp(args.coherence_strength, 0, 100)
    if args.arpeggio_rate is not None:
        settings.global_arpeggio_rate = clamp(args.arpeggio_rate, 25, 240)
    if args.seed_variation is not None:
        settings.seed_variation_strength = clamp(args.seed_variation, 0, 100)
    if args.melody_coverage is not None:
        settings.melody_coverage = clamp(args.melody_coverage, 5, 100)
    settings.timing_grid_lock = not args.no_timing_grid_lock
    if args.timing_grid_strength is not None:
        settings.timing_grid_strength = clamp(args.timing_grid_strength, 0, 100)
    settings.strict_arpeggio_grid = not args.allow_tuplet_arps
    settings.rhythmic_smoothing = not args.no_smoothing
    if args.smoothing_strength is not None:
        settings.smoothing_strength = args.smoothing_strength
    settings.calm_busy_tracks = not args.no_calm_busy_tracks
    if args.relaxation_strength is not None:
        settings.relaxation_strength = clamp(args.relaxation_strength, 0, 100)
    settings.auto_range_guard = not args.no_range_guard
    settings.max_melody_pitch = args.max_melody_pitch
    settings.render_wav = args.render_wav or args.render_mp3
    settings.render_mp3 = args.render_mp3
    result = generate_song(settings, args.output or OUTPUT_DIR)
    print(result.summary()); print(result.midi_path)
    if result.wav_path: print(result.wav_path)
    if result.mp3_path: print(result.mp3_path)
    if result.render_log: print(result.render_log)
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="PythonSoundHelix PyQt6 GPLv3 algorithmic MIDI generator")
    parser.add_argument("--nogui", action="store_true", help="generate from the command line without opening PyQt6")
    parser.add_argument("--preset", choices=preset_names(), help="preset name for --nogui")
    parser.add_argument("--output", help="output directory for --nogui")
    parser.add_argument("--seed", type=int, help="fixed seed for --nogui")
    parser.add_argument("--random-seed", action="store_true", help="randomize seed for --nogui")
    parser.add_argument("--title", help="song title for --nogui; omitted means SoundHelix-style random title")
    parser.add_argument("--bpm", type=int, help="override BPM for --nogui")
    parser.add_argument("--bars", type=int, help="override bars for --nogui")
    parser.add_argument("--normalize", action="store_true", help="normalize per-instrument MIDI velocity/loudness")
    parser.add_argument("--no-musical-guardrails", action="store_true", help="disable coherence guardrails that keep extreme settings musical")
    parser.add_argument("--coherence-strength", type=int, default=None, help="0-100 strength for global musical coherence guardrails")
    parser.add_argument("--arpeggio-rate", type=int, default=None, help="global arpeggio rate percent, 25-240")
    parser.add_argument("--seed-variation", type=int, default=None, help="0-100 strength for seed-based melodic and pattern variation")
    parser.add_argument("--melody-coverage", type=int, default=None, help="5-100 percent of named melody contour templates to use")
    parser.add_argument("--no-timing-grid-lock", action="store_true", help="disable shared musical grid timing lock")
    parser.add_argument("--timing-grid-strength", type=int, default=None, help="0-100 strength for snapping tonal note starts to the common timing grid")
    parser.add_argument("--allow-tuplet-arps", action="store_true", help="allow triplet/polymetric arpeggio step counts instead of strict 4/4 grid counts")
    parser.add_argument("--no-smoothing", action="store_true", help="disable rapid note burst smoothing")
    parser.add_argument("--smoothing-strength", type=int, default=None, help="0-100 strength for rapid note burst smoothing")
    parser.add_argument("--no-calm-busy-tracks", action="store_true", help="disable per-bar calming of overly busy tonal tracks")
    parser.add_argument("--relaxation-strength", type=int, default=None, help="0-100 strength for calming rushed/quirky tonal tracks")
    parser.add_argument("--no-range-guard", action="store_true", help="disable automatic octave/range guard")
    parser.add_argument("--max-melody-pitch", type=int, default=79, help="upper pitch for melodic voices when range guard is enabled")
    parser.add_argument("--render-wav", action="store_true", help="render a WAV through the built-in synth")
    parser.add_argument("--render-mp3", action="store_true", help="render MP3 through ffmpeg; implies WAV rendering")
    args = parser.parse_args()
    if args.nogui: return run_cli(args)
    return run_gui()


if __name__ == "__main__":
    raise SystemExit(main())
