@echo off
setlocal
cd /d "%~dp0"
if exist "env_windows.bat" call "env_windows.bat"
echo ============================================================
echo  PythonSoundHelix v0.4.26 - Nuitka onefile build
echo ============================================================
if not exist ".venv\Scripts\python.exe" (
    echo [INFO] Local venv missing. Running installer first...
    call install_windows.bat
    if errorlevel 1 exit /b 1
)
set WHEELHOUSE=%CD%\wheelhouse
if exist "%WHEELHOUSE%\*.whl" (
    echo [1/2] Installing/updating Nuitka build requirements from wheelhouse when available...
    ".venv\Scripts\python.exe" -m pip install --find-links="%WHEELHOUSE%" nuitka ordered-set zstandard
) else (
    echo [1/2] Installing/updating Nuitka build requirements online...
    ".venv\Scripts\python.exe" -m pip install --upgrade nuitka ordered-set zstandard
)
if errorlevel 1 goto fail
echo [2/2] Building onefile/no-console EXE...
".venv\Scripts\python.exe" -m nuitka ^
  --standalone ^
  --onefile ^
  --enable-plugin=pyqt6 ^
  --windows-console-mode=disable ^
  --include-data-dir=resources=resources ^
  --include-data-dir=presets=presets ^
  --include-data-dir=docs=docs ^
  --output-dir=dist ^
  --output-filename=PythonSoundHelix.exe ^
  PythonSoundHelix.py
if errorlevel 1 goto fail
echo.
echo [OK] Build complete: dist\PythonSoundHelix.exe
pause
exit /b 0
:fail
echo [ERROR] Build failed.
pause
exit /b 1
