# PythonSoundHelix version info

version: 0.4.26
package_date: 2026-06-06
project: PythonSoundHelix
origin: https://github.com/zeittresor/PythonSH

Update rule: remote GitHub project files may replace local files only when the remote version is strictly newer than this local version.
