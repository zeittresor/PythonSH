from __future__ import annotations

import json
import math
import os
import random
import time
from dataclasses import asdict
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

from .audio_render import convert_wav_to_mp3, ffmpeg_available, render_tracks_to_wav
from .midi_writer import MidiTrackData, write_midi
from .models import ChordEvent, GeneratorSettings, SectionEvent, SongResult, TrackSettings
from .music_theory import DRUM_NOTES, clamp, key_to_pc, midi_note_name, notes_for_chord, parse_progression_units, safe_filename, scale_for_mode, voice_lead
from .song_names import generate_song_name

APP_VERSION = "0.5.0"

MELODY_TEMPLATES = [
    "auto",
    "Fuer-Elise contour",
    "Popcorn-style recognizable contour",
    "SoundHelix piano contour",
    "Ode-to-Joy contour",
    "Canon contour",
    "Row Boat round",
    "Twinkle music-box contour",
    "Frere Jacques round",
    "Amazing Grace hymn contour",
    "Original arcade anthem",
]

QUALITY_DEFAULTS = {
    "bpm_min": 76,
    "bpm_max": 138,
    "max_notes_per_minute": 520,
    "melody_velocity": 82,
    "bass_velocity": 68,
    "chord_velocity": 56,
    "pad_velocity": 44,
    "drum_velocity": 62,
}


def _bar_ticks(settings: GeneratorSettings) -> int:
    return max(1, int(settings.ticks_per_beat) * max(1, int(settings.beats_per_bar)))


def _beat_ticks(settings: GeneratorSettings, beats: float) -> int:
    return int(round(float(beats) * settings.ticks_per_beat))


def _role(track: TrackSettings) -> str:
    return (track.role or "melody").strip().lower()


def _section_ratios(preset: str) -> List[Tuple[str, float, int]]:
    p = preset.lower()
    if "elise" in p or "piano" in p or "canon" in p:
        return [("Intro", 0.125, 24), ("A", 0.25, 62), ("B", 0.25, 74), ("A2", 0.25, 86), ("Outro", 0.125, 30)]
    if "ambient" in p or "pad" in p or "drift" in p:
        return [("Fade In", 0.18, 18), ("Bloom", 0.27, 48), ("Deep", 0.28, 62), ("Return", 0.17, 42), ("Fade Out", 0.10, 18)]
    return [("Intro", 0.125, 28), ("A", 0.25, 66), ("B", 0.25, 78), ("Hook", 0.25, 92), ("Outro", 0.125, 32)]


def build_sections(settings: GeneratorSettings) -> List[SectionEvent]:
    bars = max(8, int(settings.bars))
    ratios = _section_ratios(settings.preset_name)
    allocated: List[int] = []
    used = 0
    for i, (_, ratio, _) in enumerate(ratios):
        if i == len(ratios) - 1:
            n = bars - used
        else:
            n = max(2, int(round(bars * ratio)))
            used += n
        allocated.append(n)
    while sum(allocated) > bars:
        j = max(range(len(allocated)), key=lambda i: allocated[i])
        allocated[j] -= 1
    while sum(allocated) < bars:
        allocated[-2 if len(allocated) > 1 else 0] += 1
    start = 0
    sections: List[SectionEvent] = []
    for (name, _, energy), n in zip(ratios, allocated):
        sections.append(SectionEvent(name=name, start_bar=start, bars=n, energy=energy))
        start += n
    return sections


def section_for_bar(sections: Sequence[SectionEvent], bar: int) -> SectionEvent:
    for s in sections:
        if s.start_bar <= bar < s.start_bar + s.bars:
            return s
    return sections[-1]


def _progression_bank(settings: GeneratorSettings, rng: random.Random) -> List[str]:
    p = (settings.preset_name or "").lower()
    mode = (settings.mode or "major").lower()
    if "elise" in p:
        return ["Am,E,Am,E,Am,C,G,Am,Dm,Am,E,Am,F,C,E,Am"]
    if "popcorn" in p:
        return ["Am,G,F,Am,Am,G,F,Am,C,Em,D,C,C,Em,D,C"]
    if "canon" in p:
        return ["I,V,vi,iii,IV,I,IV,V"]
    if "piano" in p:
        return ["I,vi,IV,V", "I,IV,V,I", "I,V,vi,IV"]
    if "house" in p or "techno" in p or "trance" in p or "drum and bass" in p:
        return ["i,VII,VI,VII", "i,VI,III,VII", "i,iv,VII,III", "i,bVII,bVI,bVII"]
    if "ambient" in p or "pad" in p or "drift" in p:
        return ["i,VI,III,VII", "I,V,vi,IV", "i,VII,iv,VI"]
    if "blues" in p or "rock" in p:
        return ["I,IV,I,V", "i,bVII,IV,I"]
    if "minor" in mode:
        return ["i,VI,III,VII", "i,iv,V,i", "i,VII,VI,V"]
    return ["I,V,vi,IV", "I,vi,IV,V", "I,IV,V,I", "vi,IV,I,V"]


def _normalize_progression_name(text: str, settings: GeneratorSettings, rng: random.Random) -> str:
    raw = (text or "").strip()
    if settings.custom_progression.strip():
        return settings.custom_progression.strip()
    low = raw.lower()
    if not raw or "random" in low or "auto" in low or "style-aware" in low or "major wistful" in low:
        return rng.choice(_progression_bank(settings, rng))
    aliases = {
        "major pop: i-v-vi-iv": "I,V,vi,IV",
        "pop: i-v-vi-iv": "I,V,vi,IV",
        "major circle: i-vi-ii-v": "I,vi,ii,V",
        "major classic: i-iv-v-i": "I,IV,V,I",
        "major canon cycle: i-v-vi-iii-iv-i-iv-v": "I,V,vi,iii,IV,I,IV,V",
        "minor drive: i-vii-vi-v": "i,VII,VI,V",
        "mixolydian rock: i-bvii-iv-i": "I,bVII,IV,I",
        "soundhelix legacy harmony a": "Am,G,F,Am,Am,G,F,Am,C,Em,D,C,C,Em,D,C",
        "soundhelix legacy duration pattern a": "Am/10,G/2,F/2,Am/12,G/2,F/2,Am/2,C/8,Em/2,D/2,C/12,Em/2,D/2,C/4",
        "soundhelix legacy simple minor": "i,VII,VI,VII",
    }
    if low in aliases:
        return aliases[low]
    return raw


def build_chords(settings: GeneratorSettings, sections: Sequence[SectionEvent]) -> List[ChordEvent]:
    rng = random.Random(settings.seed ^ 0xCA11AB1E)
    key_pc = key_to_pc(settings.key)
    progression = _normalize_progression_name(settings.effective_progression(), settings, rng)
    units = parse_progression_units(progression, default_units=max(1, settings.harmonic_rhythm), max_units_per_token=16, divide_duration_by_four=True)
    expanded: List[str] = []
    for symbol, n in units:
        expanded.extend([symbol] * max(1, n))
    if not expanded:
        expanded = ["I", "V", "vi", "IV"]
    chords: List[ChordEvent] = []
    bar_len = _bar_ticks(settings)
    for bar in range(max(1, settings.bars)):
        sym = expanded[bar % len(expanded)]
        try:
            notes = notes_for_chord(sym, key_pc, settings.mode, octave=4)
        except Exception:
            notes = notes_for_chord("I", key_pc, settings.mode, octave=4)
            sym = "I"
        section = section_for_bar(sections, bar).name
        chords.append(ChordEvent(bar=bar, tick=bar * bar_len, symbol=sym, root=notes[0] % 12, notes=notes, section=section))
    settings.progression = progression
    return chords


def _setup_track(track: TrackSettings) -> MidiTrackData:
    data = MidiTrackData(track.name)
    ch = 9 if _role(track) == "drum" else clamp(track.channel, 0, 15)
    data.add_program(0, ch, track.program)
    data.add_cc(0, ch, 7, clamp(track.volume, 0, 127))
    data.add_cc(0, ch, 10, clamp(track.pan, 0, 127))
    data.add_cc(0, ch, 91, 18)
    data.add_cc(0, ch, 93, 8)
    if getattr(track, "fine_tune_cents", 0):
        bend = 8192 + int(clamp(track.fine_tune_cents, -100, 100) * 4096 / 100)
        data.add_pitch_bend(0, ch, bend)
    return data


def _add_note(data: MidiTrackData, track: TrackSettings, start: int, dur: int, pitch: int, velocity: int) -> int:
    ch = 9 if _role(track) == "drum" else clamp(track.channel, 0, 15)
    data.add_note(start, max(1, dur), ch, clamp(pitch, 0, 127), clamp(velocity, 1, 127))
    return 1


def _note(name: str) -> int:
    import re
    from .music_theory import NOTE_TO_PC
    m = re.match(r"^([A-Ga-g])([#bB]?)(-?\d+)$", name.strip())
    if not m:
        return 60
    pc = NOTE_TO_PC[(m.group(1).upper() + m.group(2).upper()).strip()]
    octave = int(m.group(3))
    return 12 * (octave + 1) + pc


def _transpose_template_pitch(pitch: int, settings: GeneratorSettings, reference_key: str = "A") -> int:
    delta = (key_to_pc(settings.key) - key_to_pc(reference_key)) % 12
    if delta > 6:
        delta -= 12
    p = pitch + delta
    while p > max(72, settings.max_melody_pitch):
        p -= 12
    while p < 55:
        p += 12
    return p


def _seq_from_names(items: Sequence[Tuple[str, float]]) -> List[Tuple[float, float, int]]:
    out: List[Tuple[float, float, int]] = []
    pos = 0.0
    for name, dur in items:
        if name.upper() != "REST":
            out.append((pos, dur, _note(name)))
        pos += dur
    return out


ELISE_A = _seq_from_names([
    ("E5", .5), ("D#5", .5), ("E5", .5), ("D#5", .5), ("E5", .5), ("B4", .5), ("D5", .5), ("C5", .5), ("A4", 1.0),
    ("C4", .5), ("E4", .5), ("A4", .5), ("B4", 1.0), ("E4", .5), ("G#4", .5), ("B4", .5), ("C5", 1.0),
    ("E4", .5), ("E5", .5), ("D#5", .5), ("E5", .5), ("D#5", .5), ("E5", .5), ("B4", .5), ("D5", .5), ("C5", .5), ("A4", 1.0),
    ("C4", .5), ("E4", .5), ("A4", .5), ("B4", 1.0), ("E4", .5), ("C5", .5), ("B4", .5), ("A4", 1.5),
])
ELISE_B = _seq_from_names([
    ("B4", .5), ("C5", .5), ("D5", .5), ("E5", 1.0), ("G4", .5), ("F5", .5), ("E5", .5), ("D5", 1.0),
    ("F4", .5), ("E5", .5), ("D5", .5), ("C5", 1.0), ("E4", .5), ("D5", .5), ("C5", .5), ("B4", 1.0),
    ("E4", .5), ("E5", .5), ("D#5", .5), ("E5", .5), ("D#5", .5), ("E5", .5), ("B4", .5), ("D5", .5), ("C5", .5), ("A4", 1.0),
    ("C4", .5), ("E4", .5), ("A4", .5), ("B4", 1.0), ("E4", .5), ("C5", .5), ("B4", .5), ("A4", 1.5),
])

POPCORN_A = _seq_from_names([
    ("A4", .5), ("C5", .5), ("E5", .5), ("A5", .5), ("G5", .5), ("E5", .5), ("C5", .5), ("A4", .5),
    ("G4", .5), ("B4", .5), ("D5", .5), ("G5", .5), ("F5", .5), ("D5", .5), ("B4", .5), ("G4", .5),
    ("F4", .5), ("A4", .5), ("C5", .5), ("F5", .5), ("E5", .5), ("C5", .5), ("A4", .5), ("F4", .5),
    ("A4", .5), ("C5", .5), ("E5", .5), ("A5", .5), ("C6", 1.0), ("B5", .5), ("A5", .5),
])

ODE_A = _seq_from_names([("E4", .5), ("E4", .5), ("F4", .5), ("G4", .5), ("G4", .5), ("F4", .5), ("E4", .5), ("D4", .5), ("C4", .5), ("C4", .5), ("D4", .5), ("E4", .5), ("E4", .75), ("D4", .25), ("D4", 1.0)])
ROW_A = _seq_from_names([("C4", .75), ("C4", .75), ("C4", .5), ("D4", .5), ("E4", .75), ("E4", .5), ("D4", .5), ("E4", .5), ("F4", .5), ("G4", 1.5), ("C5", .5), ("C5", .5), ("C5", .5), ("G4", .5), ("G4", .5), ("G4", .5), ("E4", .5), ("E4", .5), ("E4", .5), ("C4", .5), ("C4", .5), ("C4", .5), ("G4", .5), ("F4", .5), ("E4", .5), ("D4", .5), ("C4", 1.5)])
TWINKLE_A = _seq_from_names([("C4", .5), ("C4", .5), ("G4", .5), ("G4", .5), ("A4", .5), ("A4", .5), ("G4", 1.0), ("F4", .5), ("F4", .5), ("E4", .5), ("E4", .5), ("D4", .5), ("D4", .5), ("C4", 1.0)])
CANON_A = _seq_from_names([("F#4", .5), ("E4", .5), ("D4", .5), ("C#4", .5), ("B3", .5), ("A3", .5), ("B3", .5), ("C#4", .5), ("D4", 1.0), ("A3", 1.0), ("B3", 1.0), ("F#3", 1.0), ("G3", 1.0), ("D3", 1.0), ("G3", 1.0), ("A3", 1.0)])
ARCADE_A = _seq_from_names([("C5", .25), ("E5", .25), ("G5", .5), ("E5", .25), ("C5", .25), ("D5", .5), ("F5", .25), ("A5", .25), ("G5", 1.0), ("E5", .5), ("G5", .5), ("C6", .5), ("G5", .5)])


def _template_segments(settings: GeneratorSettings) -> List[List[Tuple[float, float, int]]]:
    name = (settings.melody_template or "auto").lower()
    preset = (settings.preset_name or "").lower()
    if "elise" in name or "elise" in preset:
        return [ELISE_A, ELISE_B, ELISE_A, ELISE_B]
    if "popcorn" in name or "popcorn" in preset:
        return [POPCORN_A, POPCORN_A]
    if "ode" in name:
        return [ODE_A, ODE_A]
    if "row" in name:
        return [ROW_A, ROW_A]
    if "twinkle" in name:
        return [TWINKLE_A, TWINKLE_A]
    if "canon" in name or "canon" in preset:
        return [CANON_A, CANON_A]
    if "arcade" in name or "arcade" in preset:
        return [ARCADE_A, ARCADE_A]
    return []


def _make_generic_phrase(settings: GeneratorSettings, rng: random.Random) -> List[Tuple[float, float, int]]:
    key_pc = key_to_pc(settings.key)
    scale = scale_for_mode(settings.mode)
    degrees = [0, 2, 4, 5, 4, 2, 1, 0, 0, 2, 3, 4, 5, 4, 2, 0]
    if rng.random() < 0.4:
        degrees = [0, 1, 2, 4, 5, 4, 2, 0, 4, 5, 6, 5, 4, 2, 1, 0]
    out = []
    pos = 0.0
    for d in degrees:
        pc = (key_pc + scale[d % len(scale)]) % 12
        pitch = 60 + pc
        while pitch < 62:
            pitch += 12
        while pitch > 76:
            pitch -= 12
        dur = rng.choice([0.5, 0.5, 1.0])
        out.append((pos, dur, pitch))
        pos += dur
    return out


def _phrase_duration(phrase: Sequence[Tuple[float, float, int]]) -> float:
    return max((o + d for o, d, _ in phrase), default=1.0)


def _active_notes_for_phrase(settings: GeneratorSettings, section: SectionEvent, phrase: Sequence[Tuple[float, float, int]], cycle_start_bar: int, cycle_bars: int, variant: int) -> List[Tuple[int, int, int]]:
    coverage = clamp(getattr(settings, "melody_coverage", 100), 5, 100) / 100.0
    max_time = _phrase_duration(phrase) * coverage
    out = []
    bar_ticks = _bar_ticks(settings)
    beat_ticks = settings.ticks_per_beat
    start_tick = cycle_start_bar * bar_ticks
    transpose_oct = 0
    if section.name.lower() in ("b", "hook", "a2") and variant % 2 == 1:
        transpose_oct = 12 if "elise" not in (settings.preset_name or "").lower() else 0
    for off, dur, pitch in phrase:
        if off >= max_time:
            continue
        p = _transpose_template_pitch(pitch + transpose_oct, settings, "A" if "elise" in (settings.preset_name or "").lower() or "popcorn" in (settings.preset_name or "").lower() else "C")
        tick = start_tick + int(round(off * beat_ticks))
        length = max(beat_ticks // 4, int(round(dur * beat_ticks * 0.88)))
        if tick < (cycle_start_bar + cycle_bars) * bar_ticks:
            out.append((tick, length, p))
    return out


def _add_melody(data: MidiTrackData, track: TrackSettings, settings: GeneratorSettings, sections: Sequence[SectionEvent], rng: random.Random) -> int:
    segments = _template_segments(settings)
    if not segments:
        segments = [_make_generic_phrase(settings, rng), _make_generic_phrase(settings, random.Random(settings.seed ^ 333))]
    count = 0
    for si, sec in enumerate(sections):
        if track.mute_in_intro and si == 0:
            continue
        if sec.energy < 25 and si == 0 and "elise" not in (settings.preset_name or "").lower():
            continue
        phrase = segments[si % len(segments)]
        phrase_bars = max(1, int(math.ceil(_phrase_duration(phrase) / settings.beats_per_bar)))
        phrase_bars = min(max(2, phrase_bars), max(2, sec.bars))
        repeats = max(1, sec.bars // phrase_bars)
        if sec.bars - repeats * phrase_bars >= phrase_bars // 2:
            repeats += 1
        for r in range(repeats):
            start_bar = sec.start_bar + r * phrase_bars
            if start_bar >= sec.start_bar + sec.bars:
                break
            notes = _active_notes_for_phrase(settings, sec, phrase, start_bar, min(phrase_bars, sec.start_bar + sec.bars - start_bar), si + r)
            for tick, dur, pitch in notes:
                vel = clamp(track.volume * 0.78 + (10 if sec.name.lower() in ("hook", "a2") else 0), 42, 96)
                count += _add_note(data, track, tick, dur, pitch + track.octave * 12 + getattr(track, "transpose", 0), vel)
    return count


def _fold(p: int, low: int, high: int) -> int:
    while p < low:
        p += 12
    while p > high:
        p -= 12
    return clamp(p, low, high)


def _chord_roots(chord: ChordEvent, octave: int = 2) -> Tuple[int, int, int]:
    root = 12 * (octave + 1) + chord.root
    fifth = root + 7
    octave_p = root + 12
    return root, fifth, octave_p


def _add_bass(data: MidiTrackData, track: TrackSettings, settings: GeneratorSettings, sections: Sequence[SectionEvent], chords: Sequence[ChordEvent]) -> int:
    count = 0
    bar_ticks = _bar_ticks(settings)
    beat = settings.ticks_per_beat
    pset = (settings.preset_name or "").lower()
    for bar, chord in enumerate(chords):
        sec = section_for_bar(sections, bar)
        root, fifth, octv = _chord_roots(chord, 2)
        root = _fold(root + track.octave * 12 + track.transpose, 28, 52)
        fifth = _fold(fifth + track.octave * 12 + track.transpose, 31, 55)
        octv = _fold(octv + track.octave * 12 + track.transpose, 36, 60)
        start = bar * bar_ticks
        vel = clamp(track.volume * 0.68 + sec.energy * 0.18, 42, 86)
        if "elise" in pset or "piano" in pset:
            pattern = [(0.0, root), (0.75, fifth), (1.5, octv), (2.25, fifth)] if settings.beats_per_bar == 3 else [(0, root), (1, fifth), (2, octv), (3, fifth)]
            for off, p in pattern:
                count += _add_note(data, track, start + _beat_ticks(settings, off), _beat_ticks(settings, 0.58), p, vel)
        else:
            pattern = [(0, root), (1.5, fifth), (2, root), (3, octv)] if settings.beats_per_bar >= 4 else [(0, root), (1.5, fifth)]
            if sec.energy > 75 and "house" in pset:
                pattern += [(0.5, root), (2.5, root)]
            for off, p in pattern:
                count += _add_note(data, track, start + _beat_ticks(settings, off), _beat_ticks(settings, 0.45), p, vel)
    return count


def _add_chords(data: MidiTrackData, track: TrackSettings, settings: GeneratorSettings, sections: Sequence[SectionEvent], chords: Sequence[ChordEvent], pad: bool = False) -> int:
    count = 0
    prev: List[int] | None = None
    bar_ticks = _bar_ticks(settings)
    for bar, chord in enumerate(chords):
        sec = section_for_bar(sections, bar)
        if pad and sec.energy < 22:
            continue
        low, high = (44, 65) if pad else (48, 72)
        voicing = voice_lead(chord.notes, prev, low=low, high=high)
        prev = voicing
        start = bar * bar_ticks
        if pad:
            dur = int(bar_ticks * 1.85) if bar % 2 == 0 else 0
            vel = clamp(track.volume * 0.48 + sec.energy * 0.05, 24, 56)
            if dur <= 0:
                continue
            for p in voicing:
                count += _add_note(data, track, start, dur, p + track.octave * 12 + track.transpose, vel)
        else:
            vel = clamp(track.volume * 0.56 + sec.energy * 0.10, 34, 70)
            hits = [0] if settings.beats_per_bar == 3 else [0, 2]
            if "house" in (settings.preset_name or "").lower():
                hits = [1, 3]
            for off in hits:
                for p in voicing:
                    count += _add_note(data, track, start + _beat_ticks(settings, off), _beat_ticks(settings, 0.72), p + track.octave * 12 + track.transpose, vel)
    return count


def _add_arpeggio(data: MidiTrackData, track: TrackSettings, settings: GeneratorSettings, sections: Sequence[SectionEvent], chords: Sequence[ChordEvent]) -> int:
    count = 0
    bar_ticks = _bar_ticks(settings)
    rate = max(25, min(100, getattr(settings, "global_arpeggio_rate", 60), getattr(track, "arp_rate", 100))) / 100.0
    step_beats = 1.0 if rate < 0.55 else 0.5
    pset = (settings.preset_name or "").lower()
    if "elise" in pset:
        return 0
    for bar, chord in enumerate(chords):
        sec = section_for_bar(sections, bar)
        if sec.energy < 55 or (bar - sec.start_bar) % 2 == 1:
            continue
        voicing = voice_lead([n + 12 for n in chord.notes], None, low=56, high=76)
        start = bar * bar_ticks
        steps = int(settings.beats_per_bar / step_beats)
        vel = clamp(track.volume * 0.45 + sec.energy * 0.07, 28, 62)
        for i in range(steps):
            if i % 2 and rate < 0.75:
                continue
            p = voicing[i % len(voicing)]
            count += _add_note(data, track, start + _beat_ticks(settings, i * step_beats), _beat_ticks(settings, step_beats * 0.58), p + track.octave * 12 + track.transpose, vel)
    return count


def _add_drums(data: MidiTrackData, track: TrackSettings, settings: GeneratorSettings, sections: Sequence[SectionEvent]) -> int:
    count = 0
    bar_ticks = _bar_ticks(settings)
    beat = settings.ticks_per_beat
    pset = (settings.preset_name or "").lower()
    if "elise" in pset or "canon" in pset or "piano" in pset:
        return 0
    for bar in range(settings.bars):
        sec = section_for_bar(sections, bar)
        if sec.energy < 25:
            continue
        start = bar * bar_ticks
        base = clamp(track.volume * 0.54 + sec.energy * 0.20, 42, 88)
        if "drum and bass" in pset:
            hits = [(0, "kick", base), (1.5, "snare", base+8), (2.0, "kick", base-8), (3.0, "snare", base+6), (0.5, "closed_hat", base-24), (1.0, "closed_hat", base-26), (2.5, "closed_hat", base-24), (3.5, "closed_hat", base-26)]
        elif "house" in pset or "techno" in pset or "trance" in pset:
            hits = [(0, "kick", base+8), (1, "kick", base+2), (2, "kick", base+6), (3, "kick", base+2), (1, "closed_hat", base-22), (3, "closed_hat", base-22), (2, "snare", base-8)]
        else:
            hits = [(0, "kick", base), (2, "snare", base-4), (1, "closed_hat", base-28), (3, "closed_hat", base-28)]
        if bar == sec.start_bar + sec.bars - 1 and sec.energy > 60:
            hits += [(settings.beats_per_bar - 0.5, "snare", base+6)]
        for off, name, vel in hits:
            if off < settings.beats_per_bar:
                count += _add_note(data, track, start + int(off * beat), max(1, beat // 12), DRUM_NOTES[name], vel)
    return count


def _add_counter(data: MidiTrackData, track: TrackSettings, settings: GeneratorSettings, sections: Sequence[SectionEvent], chords: Sequence[ChordEvent]) -> int:
    count = 0
    if "elise" in (settings.preset_name or "").lower():
        return 0
    bar_ticks = _bar_ticks(settings)
    for bar, chord in enumerate(chords):
        sec = section_for_bar(sections, bar)
        if sec.energy < 70 or bar % 8 not in (6, 7):
            continue
        voicing = voice_lead([n + 12 for n in chord.notes], None, low=60, high=79)
        p = voicing[(bar // 2) % len(voicing)] + track.octave * 12 + track.transpose
        count += _add_note(data, track, bar * bar_ticks + _beat_ticks(settings, settings.beats_per_bar - 1), _beat_ticks(settings, 0.5), p, clamp(track.volume * 0.5, 32, 60))
    return count


def _count_note_ons(tracks: Sequence[MidiTrackData]) -> int:
    return sum(1 for t in tracks for e in t.events if e.kind == "note_on" and e.b > 0)


def _normalize_tracks(tracks: Sequence[MidiTrackData], active_settings: Sequence[TrackSettings]) -> None:
    for data, track in zip(tracks, active_settings):
        role = _role(track)
        target = {"drum": 68, "bass": 66, "melody": 74, "chord": 54, "pad": 42, "arpeggio": 48, "counter": 46, "texture": 34}.get(role, 56)
        ons = [e for e in data.events if e.kind == "note_on" and e.b > 0]
        if not ons:
            continue
        avg = sum(e.b for e in ons) / len(ons)
        shift = target - avg
        for e in ons:
            e.b = clamp(e.b + shift * 0.75, 18, 108 if role == "drum" else 96)


def _visualizer_event_payload(tracks: Sequence[MidiTrackData], settings: GeneratorSettings, active_settings: Sequence[TrackSettings], end_tick: int) -> Tuple[List[Dict], float]:
    seconds_per_tick = 60.0 / max(1, settings.bpm) / max(1, settings.ticks_per_beat)
    roles: Dict[int, str] = {clamp(t.channel, 0, 15): _role(t) for t in active_settings}
    roles[9] = "drum"
    events = []
    for data in tracks:
        for e in data.events:
            if e.kind == "note_on" and e.b > 0:
                events.append({"t": round(e.tick * seconds_per_tick, 4), "p": int(e.a), "v": int(e.b), "d": 0.2, "role": roles.get(e.channel, "melody")})
    events.sort(key=lambda e: e["t"])
    if len(events) > 5000:
        step = max(1, len(events) // 5000)
        events = events[::step]
    return events, max(1.0, end_tick * seconds_per_tick)


def _smart_sanitize_settings(settings: GeneratorSettings) -> None:
    p = (settings.preset_name or "").lower()
    settings.randomize_seed = bool(settings.randomize_seed)
    settings.musical_guardrails = True
    settings.timing_grid_lock = True
    settings.strict_arpeggio_grid = True
    settings.rhythmic_smoothing = True
    settings.calm_busy_tracks = True
    settings.normalize_velocity = True
    settings.humanize_ticks = min(settings.humanize_ticks, 2)
    settings.humanize_velocity = min(settings.humanize_velocity, 6)
    settings.coherence_strength = max(settings.coherence_strength, 92)
    settings.relaxation_strength = max(settings.relaxation_strength, 88)
    settings.global_arpeggio_rate = min(settings.global_arpeggio_rate, 70)
    if "elise" in p:
        settings.key = "A" if not settings.key else settings.key
        settings.mode = "minor"
        settings.bpm = clamp(settings.bpm if settings.bpm else 96, 82, 108)
        settings.beats_per_bar = 3
        settings.bars = clamp(settings.bars if settings.bars else 96, 48, 128)
        settings.progression = "Am,E,Am,E,Am,C,G,Am,Dm,Am,E,Am,F,C,E,Am"
        settings.melody_template = "Fuer-Elise contour"
        settings.render_mp3 = False
    else:
        settings.bpm = clamp(settings.bpm, QUALITY_DEFAULTS["bpm_min"], 180 if "drum and bass" in p else QUALITY_DEFAULTS["bpm_max"])
        settings.beats_per_bar = clamp(settings.beats_per_bar, 3, 4)
        settings.bars = clamp(settings.bars, 48, 160)
    for t in settings.tracks:
        r = _role(t)
        if r == "arpeggio":
            t.density = min(t.density, 55)
            t.activity = min(t.activity, 72)
            t.volume = min(t.volume, 58)
            t.arp_rate = min(getattr(t, "arp_rate", 100), 70)
        elif r == "texture":
            t.enabled = False
        elif r == "counter":
            t.density = min(t.density, 35)
            t.activity = min(t.activity, 45)
            t.volume = min(t.volume, 52)
        elif r == "pad":
            t.volume = min(t.volume, 54)
        elif r == "drum" and "elise" in p:
            t.enabled = False


def generate_song(settings: GeneratorSettings, output_dir: str | os.PathLike[str], taste_profile: Optional[dict] = None, progress_callback=None) -> SongResult:
    settings = GeneratorSettings.from_dict(settings.to_dict())
    if settings.randomize_seed:
        settings.seed = int(time.time_ns() % 2_147_483_647)
    _smart_sanitize_settings(settings)
    rng = random.Random(settings.seed)
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    title = settings.title.strip() or generate_song_name(settings.seed, settings.preset_name)
    settings.title = title
    safe = safe_filename(title)
    midi_path = output / f"{safe}.mid"
    json_path = output / f"{safe}.json"
    chord_sheet_path = output / f"{safe}_chords.txt"
    if progress_callback:
        progress_callback(5, "Planning song structure...")
    sections = build_sections(settings)
    chords = build_chords(settings, sections)
    bar_len = _bar_ticks(settings)
    end_tick = settings.bars * bar_len
    markers = [(s.start_bar * bar_len, s.name) for s in sections] if settings.add_markers else []
    tracks: List[MidiTrackData] = []
    active: List[TrackSettings] = []
    note_count = 0
    role_done = set()
    for idx, track in enumerate(settings.tracks):
        if not track.enabled:
            continue
        r = _role(track)
        data = _setup_track(track)
        if progress_callback:
            progress_callback(10 + int(70 * idx / max(1, len(settings.tracks))), f"Arranging {track.name}...")
        if r == "drum":
            note_count += _add_drums(data, track, settings, sections)
        elif r == "bass":
            note_count += _add_bass(data, track, settings, sections, chords)
        elif r == "melody":
            if "melody" in role_done:
                note_count += _add_counter(data, track, settings, sections, chords)
            else:
                note_count += _add_melody(data, track, settings, sections, rng)
                role_done.add("melody")
        elif r == "chord":
            note_count += _add_chords(data, track, settings, sections, chords, pad=False)
        elif r == "pad":
            note_count += _add_chords(data, track, settings, sections, chords, pad=True)
        elif r == "arpeggio":
            note_count += _add_arpeggio(data, track, settings, sections, chords)
        elif r in ("counter", "texture"):
            note_count += _add_counter(data, track, settings, sections, chords)
        else:
            note_count += _add_melody(data, track, settings, sections, rng)
        tracks.append(data)
        active.append(track)
    if settings.normalize_velocity:
        if progress_callback:
            progress_callback(84, "Balancing track loudness...")
        _normalize_tracks(tracks, active)
    note_count = _count_note_ons(tracks)
    if progress_callback:
        progress_callback(90, "Writing MIDI...")
    write_midi(str(midi_path), tracks, settings.ticks_per_beat, settings.bpm, settings.beats_per_bar, title, markers)
    chord_sheet_text = make_chord_sheet(title, settings, sections, chords, note_count)
    if settings.export_chord_sheet:
        chord_sheet_path.write_text(chord_sheet_text, encoding="utf-8")
    else:
        chord_sheet_path = Path("")
    result = SongResult(title=title, seed=settings.seed, midi_path=str(midi_path), json_path=str(json_path) if settings.export_json else "", chord_sheet_path=str(chord_sheet_path) if settings.export_chord_sheet else "", sections=sections, chords=chords, note_count=note_count, settings=settings)
    result.visualizer_events, result.visualizer_duration = _visualizer_event_payload(tracks, settings, active, end_tick)
    if settings.render_wav or settings.render_mp3:
        wav_path = output / f"{safe}.wav"
        mp3_path = output / f"{safe}.mp3"
        try:
            if progress_callback:
                progress_callback(94, "Rendering WAV...")
            result.wav_path = render_tracks_to_wav(wav_path, tracks, active, settings.bpm, settings.ticks_per_beat, end_tick, settings.audio_sample_rate, progress_callback, settings.normalize_velocity)
            result.render_log += "WAV rendered with the v0.5 coordinated engine. "
            if settings.render_mp3:
                if ffmpeg_available():
                    result.mp3_path = convert_wav_to_mp3(result.wav_path, mp3_path)
                    result.render_log += "MP3 rendered via ffmpeg/libmp3lame. "
                else:
                    result.render_log += "MP3 skipped: ffmpeg was not found in PATH. "
        except Exception as exc:
            result.render_log += f"Audio render warning: {type(exc).__name__}: {exc} "
    if settings.export_json:
        payload = {
            "application": "PythonSoundHelix",
            "version": APP_VERSION,
            "license": "GPLv3",
            "title": result.title,
            "seed": result.seed,
            "midi_path": result.midi_path,
            "wav_path": result.wav_path,
            "mp3_path": result.mp3_path,
            "render_log": result.render_log,
            "note_count": result.note_count,
            "visualizer_duration": result.visualizer_duration,
            "visualizer_events": result.visualizer_events,
            "engine": "v0.5 coordinated song-first engine",
            "settings": settings.to_dict(),
            "sections": [asdict(s) for s in sections],
            "chords": [asdict(c) for c in chords],
        }
        json_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    if progress_callback:
        progress_callback(100, "Done")
    return result


def make_chord_sheet(title: str, settings: GeneratorSettings, sections: Sequence[SectionEvent], chords: Sequence[ChordEvent], note_count: int) -> str:
    lines = [
        title,
        "=" * len(title),
        "",
        f"Generated by PythonSoundHelix {APP_VERSION} (GPLv3)",
        "Engine: coordinated song-first engine",
        f"Preset: {settings.preset_name}",
        f"Seed: {settings.seed}",
        f"Tempo: {settings.bpm} BPM | Key: {settings.key} {settings.mode} | Bars: {settings.bars} | Beats/bar: {settings.beats_per_bar}",
        f"Progression: {settings.effective_progression()}",
        f"Notes: {note_count}",
        "",
        "Sections:",
    ]
    for s in sections:
        lines.append(f"  - {s.name}: bars {s.start_bar + 1}-{s.start_bar + s.bars}, energy {s.energy}%")
    lines += ["", "Chord map:"]
    current = None
    buffer: List[str] = []
    for chord in chords:
        if chord.section != current:
            if buffer:
                lines.append("    " + " | ".join(buffer)); buffer.clear()
            current = chord.section
            lines.append(f"  [{current}]")
        root_name = midi_note_name(chord.notes[0])[:-1]
        buffer.append(f"{chord.bar + 1}:{chord.symbol}({root_name})")
        if len(buffer) >= 8:
            lines.append("    " + " | ".join(buffer)); buffer.clear()
    if buffer:
        lines.append("    " + " | ".join(buffer))
    lines += ["", "Note: v0.5 generates a complete song plan first, then derives bass/chords/melody/drums from that shared plan."]
    return "\n".join(lines) + "\n"
