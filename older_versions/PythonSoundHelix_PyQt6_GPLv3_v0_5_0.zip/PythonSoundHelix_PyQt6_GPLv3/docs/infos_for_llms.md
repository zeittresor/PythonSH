# infos_for_llms.md

Purpose: compact development context for future LLM-assisted work on PythonSoundHelix. Keep broad rationale here instead of scattering explanatory comments through Python source files.

Project identity:
- PythonSoundHelix is GPLv3.
- Original SoundHelix is by Thomas Schürger / Thomas Schuerger and is a Java/XML algorithmic random-music framework.
- PythonSoundHelix is an independent Python/PyQt6 project inspired by SoundHelix and associated with https://github.com/zeittresor. Current updater target: https://github.com/zeittresor/PythonSH.
- Do not imply that Thomas Schürger authored PythonSoundHelix.

Naming policy:
- Preset display names should be clean musical names. Avoid legal/status prefixes such as Public Domain or Traditional in preset names.
- Legal/source context for classic melody contours may live in documentation/resources, not in the preset dropdown.
- Progression labels should be generic musical labels, not song-specific marketing labels.

Generator goals:
- Defaults should produce coherent, pleasant, non-frantic songs.
- Different seeds should audibly change melody/pattern order while preserving musical structure.
- Bass/chords/melody are the backbone. Arp/counter/texture should support, not dominate.
- High-BPM styles need strong grid lock, low humanize ticks, reduced arp rates and busy-track calming.
- Normalize must account for density/energy, not only velocity.
- A named melody template may use melody_coverage percent; 25% means only the opening contour, 100% means the full available contour can cycle through the arrangement.

SoundHelix / AlgoMusic notes:
- SoundHelix Popcorn compatibility uses the original-style Am/G/F/C/Em/D harmony duration pattern and a 36-section activity matrix derived from the supplied console log.
- AlgoMusic was an Amiga-era algorithmic music program by the same author as SoundHelix. Use it as historical inspiration for tracker-like rows and Techno/House structure.
- MUI is an Amiga GUI toolkit/context, not a music genre. Use MUI only as UI/theme naming.

Code hygiene:
- Keep Python source comments sparse.
- Put project memory, source references, TODOs and long rationale here.
- Preserve necessary type-checker pragmas such as inline # type: ignore when needed.


## v0.4.15 playback architecture note

The Generate tab should stay focused on generation and MIDI output. Audio rendering is an option/workflow detail and belongs under Options. MIDI playback has three user-facing modes: system default player, internal built-in synth, and internal SoundFont/FluidSynth. Do not bundle third-party SoundFonts. Let the user pick `.sf2`/`.sf3` files. FluidSynth is optional and detected via PATH.


## v0.4.24 offline/update workflow note

The app should remain copyable/offline-friendly. `wheelhouse/` is the preferred offline install source. `install_windows.bat` must try local wheels first and only then online pip. `update.bat` is the online refresh step: it downloads matching wheels for the current Windows Python and optional helper programs into app-local folders. Do not globally modify Windows PATH; use `env_windows.bat` so ffmpeg/FluidSynth are visible only to PythonSoundHelix sessions. Do not bundle SoundFonts unless licensing is explicitly verified; let the user choose `.sf2`/`.sf3`.


## v0.4.24 wheelhouse policy note

Do not bundle `.whl` files in normal source ZIP releases. Keep `wheelhouse/` as an initially empty cache with documentation only. `update.bat` is the online preparation step and should download current compatible wheels into `wheelhouse/`, plus optional helper tools such as ffmpeg and FluidSynth into `tools/`. `install_windows.bat` should install from `wheelhouse/` first when populated, otherwise fall back to online pip. For an offline copy, the user runs `update.bat` once on an online PC and then copies the entire folder.


## v0.4.24 installer/updater behavior note

`install_windows.bat` should ask whether `update.bat` should run first and default to Yes after 10 seconds. It should also default to launching the app after 10 seconds. `update.bat` should check https://github.com/zeittresor/PythonSH for project updates, then refresh `wheelhouse/`, then update optional app-local tools. Preserve runtime/user folders when applying GitHub ZIP updates: `.venv`, `wheelhouse`, `tools`, `output`, `app_data`, `.update_cache`. Use colored console status output for important installer/updater steps.

## v0.4.24 installer preflight behavior

The Windows installer should not always ask to run update.bat. It first calls scripts/check_update_status.ps1, which writes .update_cache/update_status.cmd. Only when PSH_UPDATE_NEEDED=1 should install_windows.bat offer update.bat with a 10 second default-yes countdown. If no update/cache/tool download is needed, the installer skips the update prompt and only uses the normal 10 second launch prompt after installation.

## v0.4.24 visualizer and preset expansion

The GUI has a full-screen VisualizerWindow launched from Options. It is intentionally tied to internal playback modes and should not depend on bundled audio analysis; use current song seed to randomize visuals deterministically. New presets should default to conservative musical guardrails and avoid over-busy arps/counter tracks. Installer preflight should skip update prompts when check_update_status.ps1 reports PSH_UPDATE_NEEDED=0.

## v0.4.24 installer/update note

When `install_windows.bat` calls `update.bat`, GitHub self-update may replace the currently running batch file. Do not call batch subroutines after that return. The installer must restart itself with `--skip-update-check` after updater completion, then continue local install/launch. The status checker should only return no-update-needed if `.venv` exists and `import PyQt6, numpy` succeeds, wheelhouse has wheels, optional tools are visible via app-local PATH, and the local GitHub revision marker matches remote.

## v0.4.24 GitHub updater version-gating note

Do not let update.bat blindly overwrite local project files from GitHub. The user specifically observed that a newer extracted ZIP, e.g. v0.4.21+, could be downgraded to an older GitHub snapshot. The updater must compare local project version against remote project version and only apply GitHub project files when the remote version is strictly newer. If the remote version is older or equal, keep local project files but still allow wheelhouse/tool refreshes. Use PROJECT_VERSION.txt and app/__init__.py as local version sources.



## Version-aware updater rule

Before applying project files from GitHub, compare local `docs/version_info.md` / `PROJECT_VERSION.txt` with the remote version. Only apply GitHub project files when the remote version is strictly newer. Do not downgrade a ChatGPT-generated ZIP build with an older GitHub repository snapshot. Wheelhouse and optional tools may still be updated independently.

## v0.4.24 playback / visualizer / coherence note
- Do not reintroduce purely random visualizer motion; the visualizer should consume generated note-event metadata when available.
- Internal playback should prefer WAV over MP3 because QtMultimedia codec support differs between Windows installations.
- Musical Guardrails should keep role-based pitch lanes stable by default; avoid detuning cents automatically unless the user explicitly requests it.

## v0.4.24 implementation notes

User feedback indicated that generated songs were often still too arbitrary: tonal tracks could clash harmonically even when timing was locked. v0.4.24 adds a harmonic coherence pass after arrangement smoothing. It maps non-drum note pitches toward the active chord or scale depending on role and beat strength. Bass is root/fifth focused, chord/pad/arpeggio are chord-tone focused, and melody/counter/texture allow scale tones on weak beats but chord tones on strong beats.

Playback UX now needs a permanently visible Stop playback button in the Generate tab. Stop should stop the QMediaPlayer and close the visualizer window. It cannot stop an external system player like VLC.

The visualizer is now intended to be a fullscreen wormhole/tunnel effect driven by visualizer_events from the generator. It should auto-start only for internal built-in synth or SoundFont playback when the Options checkbox is enabled.

## v0.4.26 reference-guided correction

User uploaded original Java SoundHelix Popcorn and Piano MIDI outputs because recent PythonSoundHelix generations drifted into unstructured/chaotic results. Use `docs/reference_analysis/original_soundhelix_midi_stats.md` as a compact analysis reference. Key takeaway: original SoundHelix density is not the problem; uncoordinated per-track randomness is. Keep timing on a shared lattice, make activity decisions in multi-bar blocks, keep roles in stable register lanes, and protect recognizable chromatic hooks such as Elise from harmonic post-processing that would flatten them into generic scale/chord tones.

The fullscreen visualizer should run automatically when the user presses Play MIDI if the checkbox is enabled, even when the system MIDI player is selected. Audio sync is approximate in system-player mode but the visualizer can still use generated note-event timestamps.

## v0.4.26 active-track and musicality correction

A major quality problem was caused by disabled tracks being skipped in the MIDI track list while later processing still used the full `settings.tracks` list. This shifted roles: e.g. if the first disabled track was a drum, the generated bass could be treated as drum and the lead could be treated as bass during coherence/visualizer passes. Always keep a parallel `active_track_settings` list whenever generated `MidiTrackData` excludes disabled tracks.

Named melody presets should not loop only their first recognizable bar. Use phrase-aware section offsets and longer protected contour material. For Elise-like presets, preserve chromatic identity notes and avoid over-flattening them into current chord tones.

The visualizer target is closer to Winamp Geiss: blurred feedback, radial/tunnel/wormhole motion, audio-reactive pulses and waveform haze. Avoid overly clean vector wireframes.


## v0.5.0 Engine Rule

The generator must stay song-first. Do not reintroduce independent random per-track sequencing as the main approach. A song plan must be created first: sections, harmonic phrase map, lead phrase map, arrangement activity map, then derive bass/chords/pads/arps/drums from that shared plan. User-facing parameters may be ignored or sanitized when they would cause bad output. Prioritize consistently good music over broad but fragile controls.
