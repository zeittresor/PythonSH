# PythonSoundHelix Version Info

version: 0.5.0
date: 2026-06-06

This package uses the v0.5 coordinated song-first engine. Updaters must never downgrade this local version with an older GitHub copy.
