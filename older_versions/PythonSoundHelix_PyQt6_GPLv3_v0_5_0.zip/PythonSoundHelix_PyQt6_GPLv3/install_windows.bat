@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if exist "env_windows.bat" call "env_windows.bat"
set "PSH_SKIP_UPDATE_CHECK=0"
if /I "%~1"=="--skip-update-check" set "PSH_SKIP_UPDATE_CHECK=1"
goto main

:c
set "PSH_COLOR=%~1"
set "PSH_TEXT=%~2"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Write-Host $env:PSH_TEXT -ForegroundColor $env:PSH_COLOR" 2>nul
if errorlevel 1 echo %~2
exit /b 0

:launch_prompt
call :c Green "[OK] PythonSoundHelix is ready."
echo.
choice /C YN /N /T 10 /D Y /M "Launch PythonSoundHelix now? Auto-yes in 10 seconds. [Y/n] "
if errorlevel 2 exit /b 0
call run_windows.bat
exit /b %ERRORLEVEL%

:install_requirements
where py >nul 2>nul
if %errorlevel%==0 (
    set PY=py -3
) else (
    set PY=python
)
call :c Cyan "[PYTHON] Checking Python runtime..."
%PY% --version
if errorlevel 1 (
    call :c Red "[ERROR] Python 3 was not found. Install Python 3.10+ first."
    pause
    exit /b 1
)
if not exist ".venv" (
    call :c Cyan "[1/3] Creating local virtual environment..."
    %PY% -m venv .venv
    if errorlevel 1 goto fail
) else (
    call :c Green "[1/3] Local virtual environment exists."
)
call :c Cyan "[2/3] Checking local wheelhouse cache..."
set WHEELHOUSE=%CD%\wheelhouse
set HAVE_WHEELHOUSE=0
if exist "%WHEELHOUSE%\*.whl" set HAVE_WHEELHOUSE=1
if "%HAVE_WHEELHOUSE%"=="1" (
    call :c Cyan "[3/3] Installing requirements from local wheelhouse..."
    ".venv\Scripts\python.exe" -m pip install --no-index --find-links="%WHEELHOUSE%" -r requirements.txt
    if errorlevel 1 (
        call :c Yellow "[WARN] Local wheelhouse install failed. Trying online installation..."
        ".venv\Scripts\python.exe" -m pip install -r requirements.txt
        if errorlevel 1 goto fail
    )
) else (
    call :c Yellow "[3/3] No populated local wheelhouse found."
    call :c Yellow "      Trying online installation. For offline PCs, run update.bat once on an online PC first."
    ".venv\Scripts\python.exe" -m pip install -r requirements.txt
    if errorlevel 1 goto fail
)
exit /b 0

:main
call :c Cyan "============================================================"
call :c Cyan " PythonSoundHelix v0.5.0 - PyQt6 GPLv3 Windows installer"
call :c Cyan "============================================================"

if "%PSH_SKIP_UPDATE_CHECK%"=="1" (
    call :c Yellow "[UPDATE] Update check skipped after updater handoff. Continuing with local install check."
    call :install_requirements
    if errorlevel 1 goto fail
    goto launch_prompt
)

call :c Cyan "[UPDATE] Checking whether a project/cache/tool/install update is actually needed..."
set "PSH_UPDATE_NEEDED=1"
set "PSH_UPDATE_REASON=Status check unavailable."
set "PSH_UPDATE_DETAILS="
if exist "scripts\check_update_status.ps1" (
    powershell -NoProfile -ExecutionPolicy Bypass -File "scripts\check_update_status.ps1" -Root "%CD%" -RepoOwner "zeittresor" -RepoName "PythonSH"
    if exist ".update_cache\update_status.cmd" call ".update_cache\update_status.cmd"
) else (
    call :c Yellow "[WARN] scripts\check_update_status.ps1 not found. Falling back to normal install/update flow."
)

if /I "%PSH_UPDATE_NEEDED%"=="0" (
    call :c Green "[UPDATE] No project/download/install update is currently required."
    if defined PSH_UPDATE_REASON call :c Green "         %PSH_UPDATE_REASON%"
    goto launch_prompt
)

call :c Yellow "[UPDATE] Update/cache/tool/install refresh is recommended."
if defined PSH_UPDATE_REASON call :c Yellow "         %PSH_UPDATE_REASON%"
if defined PSH_UPDATE_DETAILS call :c Yellow "         %PSH_UPDATE_DETAILS%"
choice /C YN /N /T 10 /D Y /M "Run update.bat now? Auto-yes in 10 seconds. [Y/n] "
if errorlevel 2 (
    call :c Yellow "[INFO] Skipping update step by user choice. Continuing with local installation attempt."
    call :install_requirements
    if errorlevel 1 goto fail
    goto launch_prompt
) else (
    call :c Cyan "[UPDATE] Running app-local updater now..."
    call update.bat --from-installer
    set "PSH_UPDATE_RC=%ERRORLEVEL%"
    if exist ".venv\Scripts\python.exe" if exist "wheelhouse\*.whl" set "PSH_UPDATE_RC=0"
    echo.
    if not "%PSH_UPDATE_RC%"=="0" (
        echo [WARN] update.bat reported a problem. Restarting installer for a local install attempt.
    ) else (
        echo [OK] Update step completed. Restarting installer to avoid stale batch/self-update state.
    )
    cmd /c ""%~f0" --skip-update-check"
    exit /b %ERRORLEVEL%
)

:fail
call :c Red "[ERROR] Installation failed."
call :c Yellow "If this PC is offline, run update.bat once on an online PC first, then copy the whole folder including wheelhouse and tools."
pause
exit /b 1
