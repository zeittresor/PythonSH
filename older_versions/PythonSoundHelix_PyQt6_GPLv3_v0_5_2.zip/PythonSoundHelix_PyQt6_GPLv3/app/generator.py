from __future__ import annotations

import json
import math
import os
import random
import time
from dataclasses import asdict
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

from .audio_render import convert_wav_to_mp3, ffmpeg_available, render_tracks_to_wav
from .midi_writer import MidiTrackData, write_midi
from .models import ChordEvent, GeneratorSettings, SectionEvent, SongResult, TrackSettings
from .music_theory import DRUM_NOTES, clamp, key_to_pc, midi_note_name, notes_for_chord, parse_progression_units, safe_filename, scale_for_mode, voice_lead
from .song_names import generate_song_name

APP_VERSION = "0.5.2"
ENGINE_NAME = "v0.5.2 phrase-led coordinated composer"

MELODY_TEMPLATES = [
    "auto",
    "Fuer-Elise contour",
    "Popcorn-style recognizable contour",
    "SoundHelix piano contour",
    "Ode-to-Joy contour",
    "Canon contour",
    "Row Boat round",
    "Twinkle music-box contour",
    "Frere Jacques round",
    "Amazing Grace hymn contour",
    "Original arcade anthem",
]

NotePhrase = List[Tuple[float, float, int]]


def _bar_ticks(settings: GeneratorSettings) -> int:
    return max(1, int(settings.ticks_per_beat) * max(1, int(settings.beats_per_bar)))


def _beat_ticks(settings: GeneratorSettings, beats: float) -> int:
    return int(round(float(beats) * settings.ticks_per_beat))


def _role(track: TrackSettings) -> str:
    return (track.role or "melody").strip().lower()


def _note(name: str) -> int:
    import re
    from .music_theory import NOTE_TO_PC
    m = re.match(r"^([A-Ga-g])([#bB]?)(-?\d+)$", name.strip())
    if not m:
        return 60
    root = (m.group(1).upper() + m.group(2).upper()).strip()
    pc = NOTE_TO_PC[root]
    return 12 * (int(m.group(3)) + 1) + pc


def _seq(items: Sequence[Tuple[str, float]]) -> NotePhrase:
    pos = 0.0
    out: NotePhrase = []
    for name, dur in items:
        if name.upper() != "REST":
            out.append((pos, dur, _note(name)))
        pos += dur
    return out


ELISE_A = _seq([
    ("E5", .5), ("D#5", .5), ("E5", .5), ("D#5", .5), ("E5", .5), ("B4", .5), ("D5", .5), ("C5", .5), ("A4", 1.0),
    ("C4", .5), ("E4", .5), ("A4", .5), ("B4", 1.0), ("E4", .5), ("G#4", .5), ("B4", .5), ("C5", 1.0),
    ("E4", .5), ("E5", .5), ("D#5", .5), ("E5", .5), ("D#5", .5), ("E5", .5), ("B4", .5), ("D5", .5), ("C5", .5), ("A4", 1.0),
    ("C4", .5), ("E4", .5), ("A4", .5), ("B4", 1.0), ("E4", .5), ("C5", .5), ("B4", .5), ("A4", 1.5),
])
ELISE_B = _seq([
    ("B4", .5), ("C5", .5), ("D5", .5), ("E5", 1.0), ("G4", .5), ("F5", .5), ("E5", .5), ("D5", 1.0),
    ("F4", .5), ("E5", .5), ("D5", .5), ("C5", 1.0), ("E4", .5), ("D5", .5), ("C5", .5), ("B4", 1.0),
    ("E4", .5), ("E5", .5), ("D#5", .5), ("E5", .5), ("D#5", .5), ("E5", .5), ("B4", .5), ("D5", .5), ("C5", .5), ("A4", 1.0),
    ("C4", .5), ("E4", .5), ("A4", .5), ("B4", 1.0), ("E4", .5), ("C5", .5), ("B4", .5), ("A4", 1.5),
])
POPCORN_A = _seq([
    ("A4", .5), ("C5", .5), ("E5", .5), ("A5", .5), ("G5", .5), ("E5", .5), ("C5", .5), ("A4", .5),
    ("G4", .5), ("B4", .5), ("D5", .5), ("G5", .5), ("F5", .5), ("D5", .5), ("B4", .5), ("G4", .5),
    ("F4", .5), ("A4", .5), ("C5", .5), ("F5", .5), ("E5", .5), ("C5", .5), ("A4", .5), ("F4", .5),
    ("A4", .5), ("C5", .5), ("E5", .5), ("A5", .5), ("C6", 1.0), ("B5", .5), ("A5", .5),
])
POPCORN_B = _seq([
    ("C5", .5), ("E5", .5), ("G5", .5), ("C6", .5), ("B5", .5), ("G5", .5), ("E5", .5), ("C5", .5),
    ("E5", .5), ("G5", .5), ("B5", .5), ("E6", .5), ("D6", .5), ("B5", .5), ("G5", .5), ("E5", .5),
    ("D5", .5), ("F#5", .5), ("A5", .5), ("D6", .5), ("C6", .5), ("A5", .5), ("F#5", .5), ("D5", .5),
    ("C5", .5), ("E5", .5), ("G5", .5), ("C6", .5), ("B5", .5), ("G5", .5), ("E5", .5), ("C5", .5),
])
ODE_A = _seq([("E4", .5), ("E4", .5), ("F4", .5), ("G4", .5), ("G4", .5), ("F4", .5), ("E4", .5), ("D4", .5), ("C4", .5), ("C4", .5), ("D4", .5), ("E4", .5), ("E4", .75), ("D4", .25), ("D4", 1.0), ("E4", .5), ("E4", .5), ("F4", .5), ("G4", .5), ("G4", .5), ("F4", .5), ("E4", .5), ("D4", .5), ("C4", .5), ("C4", .5), ("D4", .5), ("E4", .5), ("D4", .75), ("C4", .25), ("C4", 1.0)])
ROW_A = _seq([("C4", .75), ("C4", .75), ("C4", .5), ("D4", .5), ("E4", .75), ("E4", .5), ("D4", .5), ("E4", .5), ("F4", .5), ("G4", 1.5), ("C5", .5), ("C5", .5), ("C5", .5), ("G4", .5), ("G4", .5), ("G4", .5), ("E4", .5), ("E4", .5), ("E4", .5), ("C4", .5), ("C4", .5), ("C4", .5), ("G4", .5), ("F4", .5), ("E4", .5), ("D4", .5), ("C4", 1.5)])
TWINKLE_A = _seq([("C4", .5), ("C4", .5), ("G4", .5), ("G4", .5), ("A4", .5), ("A4", .5), ("G4", 1.0), ("F4", .5), ("F4", .5), ("E4", .5), ("E4", .5), ("D4", .5), ("D4", .5), ("C4", 1.0), ("G4", .5), ("G4", .5), ("F4", .5), ("F4", .5), ("E4", .5), ("E4", .5), ("D4", 1.0), ("G4", .5), ("G4", .5), ("F4", .5), ("F4", .5), ("E4", .5), ("E4", .5), ("D4", 1.0), ("C4", .5), ("C4", .5), ("G4", .5), ("G4", .5), ("A4", .5), ("A4", .5), ("G4", 1.0), ("F4", .5), ("F4", .5), ("E4", .5), ("E4", .5), ("D4", .5), ("D4", .5), ("C4", 1.0)])
CANON_A = _seq([("F#4", .5), ("E4", .5), ("D4", .5), ("C#4", .5), ("B3", .5), ("A3", .5), ("B3", .5), ("C#4", .5), ("D4", 1.0), ("A3", 1.0), ("B3", 1.0), ("F#3", 1.0), ("G3", 1.0), ("D3", 1.0), ("G3", 1.0), ("A3", 1.0)])
ARCADE_A = _seq([("C5", .25), ("E5", .25), ("G5", .5), ("E5", .25), ("C5", .25), ("D5", .5), ("F5", .25), ("A5", .25), ("G5", 1.0), ("E5", .5), ("G5", .5), ("C6", .5), ("G5", .5)])


def _phrase_duration(phrase: Sequence[Tuple[float, float, int]]) -> float:
    return max((o + d for o, d, _ in phrase), default=1.0)


def _section_ratios(settings: GeneratorSettings) -> List[Tuple[str, float, int]]:
    p = (settings.preset_name or "").lower()
    if any(x in p for x in ("elise", "piano", "canon", "row", "twinkle", "ode", "grace", "lullaby")):
        return [("Intro", 0.12, 20), ("A", 0.26, 62), ("B", 0.24, 76), ("A2", 0.26, 84), ("Outro", 0.12, 28)]
    if any(x in p for x in ("ambient", "pad", "drift", "ocean")):
        return [("Fade In", 0.18, 18), ("A", 0.24, 42), ("Bloom", 0.28, 64), ("Return", 0.20, 44), ("Fade Out", 0.10, 18)]
    if any(x in p for x in ("house", "techno", "trance", "drum and bass", "dnb")):
        return [("Intro", 0.16, 28), ("Groove", 0.22, 58), ("Lift", 0.18, 78), ("Drop", 0.30, 94), ("Outro", 0.14, 32)]
    return [("Intro", 0.14, 26), ("A", 0.24, 58), ("B", 0.22, 70), ("Hook", 0.28, 86), ("Outro", 0.12, 30)]


def build_sections(settings: GeneratorSettings) -> List[SectionEvent]:
    bars = max(8, int(settings.bars))
    ratios = _section_ratios(settings)
    allocated: List[int] = []
    used = 0
    for i, (_, ratio, _) in enumerate(ratios):
        if i == len(ratios) - 1:
            n = bars - used
        else:
            n = max(2, int(round(bars * ratio)))
            used += n
        allocated.append(n)
    while sum(allocated) > bars:
        j = max(range(len(allocated)), key=lambda x: allocated[x])
        allocated[j] -= 1
    while sum(allocated) < bars:
        allocated[-2 if len(allocated) > 1 else 0] += 1
    start = 0
    out: List[SectionEvent] = []
    for (name, _, energy), n in zip(ratios, allocated):
        out.append(SectionEvent(name=name, start_bar=start, bars=n, energy=energy))
        start += n
    return out


def section_for_bar(sections: Sequence[SectionEvent], bar: int) -> SectionEvent:
    for s in sections:
        if s.start_bar <= bar < s.start_bar + s.bars:
            return s
    return sections[-1]


def _split_progression(text: str, settings: GeneratorSettings) -> List[str]:
    units = parse_progression_units(text, default_units=max(1, settings.harmonic_rhythm), max_units_per_token=16, divide_duration_by_four=True)
    out: List[str] = []
    for sym, n in units:
        out += [sym] * max(1, int(n))
    return out or ["I", "V", "vi", "IV"]


def _style_phrases(settings: GeneratorSettings, rng: random.Random) -> Dict[str, List[str]]:
    p = (settings.preset_name or "").lower()
    mode = (settings.mode or "major").lower()
    if settings.custom_progression.strip():
        base = _split_progression(settings.custom_progression.strip(), settings)
        return {"A": base, "B": base[2:] + base[:2], "HOOK": base, "OUT": base}
    if "elise" in p:
        return {
            "A": ["Am", "E", "Am", "E", "Am", "C", "G", "Am"],
            "B": ["C", "G", "Am", "E", "F", "C", "Dm", "E"],
            "HOOK": ["Am", "E", "Am", "C", "Dm", "Am", "E", "Am"],
            "OUT": ["F", "C", "E", "Am"],
        }
    if "popcorn" in p:
        return {
            "A": ["Am", "G", "F", "Am", "Am", "G", "F", "Am"],
            "B": ["C", "Em", "D", "C", "C", "Em", "D", "C"],
            "HOOK": ["Am", "G", "F", "Am", "C", "Em", "D", "C"],
            "OUT": ["Am", "G", "F", "Am"],
        }
    if "canon" in p:
        return {"A": ["I", "V", "vi", "iii", "IV", "I", "IV", "V"], "B": ["vi", "iii", "IV", "I", "ii", "V", "I", "V"], "HOOK": ["I", "V", "vi", "iii", "IV", "I", "IV", "V"], "OUT": ["IV", "V", "I", "I"]}
    if any(x in p for x in ("house", "techno", "trance", "drum and bass", "dnb")):
        banks = [
            {"A": ["i", "VII", "VI", "VII"], "B": ["iv", "i", "VI", "VII"], "HOOK": ["i", "VI", "III", "VII"], "OUT": ["i", "VII", "VI", "VII"]},
            {"A": ["i", "VI", "III", "VII"], "B": ["i", "iv", "VII", "III"], "HOOK": ["VI", "VII", "i", "i"], "OUT": ["i", "VII", "i", "VII"]},
        ]
        return rng.choice(banks)
    if any(x in p for x in ("ambient", "pad", "drift", "ocean")):
        return rng.choice([
            {"A": ["i", "VI", "III", "VII"], "B": ["iv", "VI", "i", "VII"], "HOOK": ["VI", "III", "VII", "i"], "OUT": ["i", "VI", "i", "i"]},
            {"A": ["I", "V", "vi", "IV"], "B": ["ii", "vi", "IV", "V"], "HOOK": ["IV", "I", "V", "vi"], "OUT": ["I", "IV", "I", "I"]},
        ])
    if "minor" in mode:
        return rng.choice([
            {"A": ["i", "VI", "III", "VII"], "B": ["iv", "i", "V", "VI"], "HOOK": ["VI", "VII", "i", "V"], "OUT": ["iv", "V", "i", "i"]},
            {"A": ["i", "VII", "VI", "VII"], "B": ["iv", "i", "VII", "III"], "HOOK": ["i", "VI", "III", "VII"], "OUT": ["VI", "V", "i", "i"]},
        ])
    return rng.choice([
        {"A": ["I", "V", "vi", "IV"], "B": ["ii", "V", "I", "vi"], "HOOK": ["IV", "V", "iii", "vi", "IV", "V", "I", "I"], "OUT": ["IV", "V", "I", "I"]},
        {"A": ["I", "vi", "IV", "V"], "B": ["vi", "IV", "I", "V"], "HOOK": ["I", "V", "vi", "IV"], "OUT": ["IV", "V", "I", "I"]},
        {"A": ["I", "IV", "V", "I"], "B": ["ii", "V", "iii", "vi"], "HOOK": ["IV", "I", "V", "vi"], "OUT": ["IV", "V", "I", "I"]},
    ])


def build_chords(settings: GeneratorSettings, sections: Sequence[SectionEvent]) -> List[ChordEvent]:
    rng = random.Random(settings.seed ^ 0x51A7E)
    key_pc = key_to_pc(settings.key)
    phrases = _style_phrases(settings, rng)
    bar_len = _bar_ticks(settings)
    chords: List[ChordEvent] = []
    section_phrase_names = {"Intro": "A", "A": "A", "Groove": "A", "B": "B", "Bloom": "B", "Lift": "B", "A2": "A", "Hook": "HOOK", "Drop": "HOOK", "Return": "A", "Outro": "OUT", "Fade In": "A", "Fade Out": "OUT"}
    for sec in sections:
        pname = section_phrase_names.get(sec.name, "A")
        phrase = phrases.get(pname, phrases.get("A", ["I", "V", "vi", "IV"]))
        if sec.name.lower() in ("intro", "fade in") and len(phrase) >= 4:
            phrase = phrase[:4]
        for i in range(sec.bars):
            bar = sec.start_bar + i
            sym = phrase[i % len(phrase)]
            if i == sec.bars - 1 and pname in ("OUT", "HOOK") and phrase:
                sym = phrase[-1]
            try:
                notes = notes_for_chord(sym, key_pc, settings.mode, octave=4)
            except Exception:
                sym = "i" if settings.mode.lower().startswith("minor") else "I"
                notes = notes_for_chord(sym, key_pc, settings.mode, octave=4)
            chords.append(ChordEvent(bar=bar, tick=bar * bar_len, symbol=sym, root=notes[0] % 12, notes=notes, section=sec.name))
    display_phrase = "; ".join(f"{k}:{','.join(v)}" for k, v in phrases.items())
    settings.progression = display_phrase[:240]
    return chords


def _setup_track(track: TrackSettings) -> MidiTrackData:
    data = MidiTrackData(track.name)
    ch = 9 if _role(track) == "drum" else clamp(track.channel, 0, 15)
    data.add_program(0, ch, track.program)
    data.add_cc(0, ch, 7, clamp(track.volume, 0, 127))
    data.add_cc(0, ch, 10, clamp(track.pan, 0, 127))
    data.add_cc(0, ch, 91, 16)
    data.add_cc(0, ch, 93, 6)
    return data


def _add_note(data: MidiTrackData, track: TrackSettings, start: int, dur: int, pitch: int, velocity: int) -> int:
    ch = 9 if _role(track) == "drum" else clamp(track.channel, 0, 15)
    data.add_note(max(0, start), max(1, dur), ch, clamp(pitch, 0, 127), clamp(velocity, 1, 127))
    return 1


def _fold(p: int, low: int, high: int) -> int:
    while p < low:
        p += 12
    while p > high:
        p -= 12
    return clamp(p, low, high)


def _transpose_template_pitch(pitch: int, settings: GeneratorSettings, reference_key: str = "A") -> int:
    delta = (key_to_pc(settings.key) - key_to_pc(reference_key)) % 12
    if delta > 6:
        delta -= 12
    p = pitch + delta
    high = max(64, min(settings.max_melody_pitch, 84))
    while p > high:
        p -= 12
    while p < 55:
        p += 12
    return p


def _template_segments(settings: GeneratorSettings) -> List[NotePhrase]:
    name = (settings.melody_template or "auto").lower()
    preset = (settings.preset_name or "").lower()
    if "elise" in name or "elise" in preset:
        return [ELISE_A, ELISE_B, ELISE_A + [(o + _phrase_duration(ELISE_A), d, p) for o, d, p in ELISE_B]]
    if "popcorn" in name or "popcorn" in preset:
        return [POPCORN_A, POPCORN_B, POPCORN_A]
    if "ode" in name or "ode" in preset:
        return [ODE_A, ODE_A]
    if "row" in name:
        return [ROW_A, ROW_A]
    if "twinkle" in name:
        return [TWINKLE_A, TWINKLE_A]
    if "canon" in name or "canon" in preset:
        return [CANON_A, CANON_A]
    if "arcade" in name or "arcade" in preset:
        return [ARCADE_A, ARCADE_A]
    return []


def _scale_pitch(settings: GeneratorSettings, degree: int, octave: int = 4) -> int:
    scale = scale_for_mode(settings.mode)
    key = key_to_pc(settings.key)
    step = scale[degree % len(scale)]
    oct_add = degree // len(scale)
    return 12 * (octave + 1 + oct_add) + (key + step) % 12


def _chord_tones_in_range(chord: ChordEvent, low: int, high: int) -> List[int]:
    tones = []
    pcs = [n % 12 for n in chord.notes]
    for p in range(low, high + 1):
        if p % 12 in pcs:
            tones.append(p)
    return tones or [low + 7]


def _scale_tones_in_range(settings: GeneratorSettings, low: int, high: int) -> List[int]:
    pcs = {(key_to_pc(settings.key) + s) % 12 for s in scale_for_mode(settings.mode)}
    return [p for p in range(low, high + 1) if p % 12 in pcs]


def _make_motif(settings: GeneratorSettings, chords: Sequence[ChordEvent], start_bar: int, bars: int, rng: random.Random, contrast: int = 0) -> NotePhrase:
    phrase: NotePhrase = []
    pos_beats = 0.0
    rhythms = [[0.0, 1.0, 2.0, 3.0], [0.0, 1.5, 2.0, 3.0], [0.0, 0.5, 1.5, 2.5], [0.0, 2.0, 3.0]] if settings.beats_per_bar >= 4 else [[0.0, 1.0, 2.0], [0.0, 1.5, 2.25], [0.0, 0.75, 1.5]]
    contour = rng.choice([[0, 2, 4, 5, 4, 2, 1, 0], [0, 1, 2, 4, 5, 4, 2, 0], [2, 4, 5, 7, 5, 4, 2, 0], [4, 2, 0, 2, 4, 5, 4, 2]])
    scale = _scale_tones_in_range(settings, 58 + contrast * 2, min(settings.max_melody_pitch, 78) + contrast * 2)
    idx = 0
    for b in range(bars):
        chord = chords[min(start_bar + b, len(chords) - 1)]
        chord_tones = _chord_tones_in_range(chord, 58 + contrast * 2, min(settings.max_melody_pitch, 79) + contrast * 2)
        rpat = rhythms[(b + contrast + rng.randrange(len(rhythms))) % len(rhythms)] if b % 4 == 0 else rhythms[(b + contrast) % len(rhythms)]
        for j, off in enumerate(rpat):
            if off >= settings.beats_per_bar:
                continue
            if j == 0 or abs(off - round(off)) < 0.01:
                p = chord_tones[(idx + j + contrast) % len(chord_tones)]
            else:
                base = contour[(idx + j) % len(contour)]
                p = scale[base % len(scale)] if scale else chord_tones[0]
            if phrase:
                prev = phrase[-1][2]
                while p - prev > 7:
                    p -= 12
                while prev - p > 9:
                    p += 12
                p = _fold(p, 56, min(settings.max_melody_pitch, 80))
            dur = 0.42 if len(rpat) >= 4 else 0.72
            phrase.append((pos_beats + off, dur, p))
        pos_beats += settings.beats_per_bar
        idx += 1
    return phrase


def _bar_to_section_index(sections: Sequence[SectionEvent], bar: int) -> int:
    for i, s in enumerate(sections):
        if s.start_bar <= bar < s.start_bar + s.bars:
            return i
    return len(sections) - 1


def _place_phrase(data: MidiTrackData, track: TrackSettings, settings: GeneratorSettings, phrase: NotePhrase, start_bar: int, max_bars: int, velocity: int, ref_key: str = "C", keep_chromatics: bool = False, transpose: int = 0) -> int:
    count = 0
    max_beats = max_bars * settings.beats_per_bar
    start_tick = start_bar * _bar_ticks(settings)
    coverage = clamp(getattr(settings, "melody_coverage", 100), 5, 100) / 100.0
    phrase_end = _phrase_duration(phrase) * coverage
    phrase_end = min(phrase_end, max_beats)
    for off, dur, pitch in phrase:
        if off >= phrase_end or off >= max_beats:
            continue
        p = pitch + transpose if keep_chromatics else _transpose_template_pitch(pitch + transpose, settings, ref_key)
        if keep_chromatics:
            delta = (key_to_pc(settings.key) - key_to_pc(ref_key)) % 12
            if delta > 6:
                delta -= 12
            p = _fold(p + delta, 55, min(settings.max_melody_pitch, 82))
        p += track.octave * 12 + getattr(track, "transpose", 0)
        count += _add_note(data, track, start_tick + _beat_ticks(settings, off), max(_beat_ticks(settings, dur * 0.88), settings.ticks_per_beat // 4), p, velocity)
    return count


def _add_melody(data: MidiTrackData, track: TrackSettings, settings: GeneratorSettings, sections: Sequence[SectionEvent], chords: Sequence[ChordEvent], rng: random.Random) -> int:
    count = 0
    pset = (settings.preset_name or "").lower()
    segments = _template_segments(settings)
    section_map = {"Intro": 0, "A": 0, "Groove": 0, "B": 1, "Bloom": 1, "Lift": 1, "A2": 2, "Hook": 2, "Drop": 2, "Return": 0, "Outro": 0, "Fade In": 0, "Fade Out": 0}
    if segments:
        ref_key = "A" if any(x in pset for x in ("elise", "popcorn")) else "C"
        keep_chromatics = "elise" in pset or "elise" in (settings.melody_template or "").lower()
        for sec in sections:
            if track.mute_in_intro and sec.name.lower() in ("intro", "fade in"):
                continue
            seg = segments[section_map.get(sec.name, 0) % len(segments)]
            dur_bars = max(1, int(math.ceil(_phrase_duration(seg) / settings.beats_per_bar)))
            if "elise" in pset:
                repeats = 1 if sec.name in ("Intro", "Outro") else max(1, min(2, math.ceil(sec.bars / max(1, dur_bars))))
            else:
                repeats = max(1, math.ceil(sec.bars / max(1, dur_bars)))
            for r in range(repeats):
                sb = sec.start_bar + r * dur_bars
                if sb >= sec.start_bar + sec.bars:
                    break
                max_bars = min(dur_bars, sec.start_bar + sec.bars - sb)
                vel = clamp(track.volume * 0.72 + sec.energy * 0.12 + (5 if sec.name in ("Hook", "Drop", "A2") else 0), 46, 92)
                count += _place_phrase(data, track, settings, seg, sb, max_bars, vel, ref_key=ref_key, keep_chromatics=keep_chromatics, transpose=0 if r == 0 else (0 if "elise" in pset else rng.choice([0, 12, -12])))
    else:
        for sec in sections:
            if track.mute_in_intro and sec.name.lower() in ("intro", "fade in"):
                continue
            motif_bars = min(8, max(4, sec.bars))
            motif = _make_motif(settings, chords, sec.start_bar, motif_bars, rng, contrast=1 if sec.name in ("B", "Lift", "Bloom") else 0)
            repeats = max(1, math.ceil(sec.bars / motif_bars))
            for r in range(repeats):
                sb = sec.start_bar + r * motif_bars
                if sb >= sec.start_bar + sec.bars:
                    break
                vel = clamp(track.volume * 0.70 + sec.energy * 0.10, 44, 88)
                count += _place_phrase(data, track, settings, motif, sb, min(motif_bars, sec.start_bar + sec.bars - sb), vel, ref_key=settings.key, keep_chromatics=True, transpose=0)
    return count


def _add_bass(data: MidiTrackData, track: TrackSettings, settings: GeneratorSettings, sections: Sequence[SectionEvent], chords: Sequence[ChordEvent]) -> int:
    count = 0
    pset = (settings.preset_name or "").lower()
    for bar, chord in enumerate(chords):
        sec = section_for_bar(sections, bar)
        if track.mute_in_intro and sec.name.lower() in ("intro", "fade in") and (bar - sec.start_bar) < sec.bars // 2:
            continue
        start = bar * _bar_ticks(settings)
        root = _fold(12 * 3 + chord.root + track.octave * 12 + track.transpose, 28, 50)
        fifth = _fold(root + 7, 31, 55)
        octv = _fold(root + 12, 36, 60)
        vel = clamp(track.volume * 0.58 + sec.energy * 0.13, 36, 78)
        if any(x in pset for x in ("elise", "piano", "canon", "lullaby")):
            pat = [(0.0, root), (1.0 if settings.beats_per_bar == 3 else 1.5, fifth), (2.0 if settings.beats_per_bar == 3 else 3.0, octv)]
            dur = 0.62
        elif any(x in pset for x in ("house", "techno", "trance")):
            pat = [(0, root), (1, root), (2, fifth), (3, root)]
            dur = 0.42
        elif any(x in pset for x in ("drum and bass", "dnb")):
            pat = [(0, root), (1.5, fifth), (2.0, root), (3.0, octv)]
            dur = 0.36
        else:
            pat = [(0, root), (1.5 if settings.beats_per_bar >= 4 else 1.0, fifth), (2.5 if settings.beats_per_bar >= 4 else 2.0, root)]
            dur = 0.46
        for off, p in pat:
            if off < settings.beats_per_bar:
                count += _add_note(data, track, start + _beat_ticks(settings, off), _beat_ticks(settings, dur), p, vel)
    return count


def _add_chords(data: MidiTrackData, track: TrackSettings, settings: GeneratorSettings, sections: Sequence[SectionEvent], chords: Sequence[ChordEvent], pad: bool = False) -> int:
    count = 0
    prev: Optional[List[int]] = None
    pset = (settings.preset_name or "").lower()
    for bar, chord in enumerate(chords):
        sec = section_for_bar(sections, bar)
        if pad and (bar - sec.start_bar) % 2 == 1:
            continue
        if _role(track) == "chord" and any(x in pset for x in ("elise", "piano")) and sec.name.lower() in ("intro", "outro"):
            continue
        low, high = (43, 64) if pad else (48, 70)
        voicing = voice_lead(chord.notes, prev, low=low, high=high)
        prev = voicing
        start = bar * _bar_ticks(settings)
        if pad:
            vel = clamp(track.volume * 0.44 + sec.energy * 0.04, 22, 50)
            dur = _bar_ticks(settings) * (2 if settings.beats_per_bar >= 4 else 1)
            for p in voicing:
                count += _add_note(data, track, start, dur - _beat_ticks(settings, 0.08), p + track.octave * 12 + track.transpose, vel)
        else:
            vel = clamp(track.volume * 0.46 + sec.energy * 0.08, 30, 64)
            if any(x in pset for x in ("house", "techno", "trance")):
                hits = [1.0, 3.0]
            elif settings.beats_per_bar == 3:
                hits = [0.0]
            else:
                hits = [0.0, 2.0] if sec.energy > 45 else [0.0]
            for off in hits:
                for p in voicing:
                    count += _add_note(data, track, start + _beat_ticks(settings, off), _beat_ticks(settings, 0.55), p + track.octave * 12 + track.transpose, vel)
    return count


def _add_arpeggio(data: MidiTrackData, track: TrackSettings, settings: GeneratorSettings, sections: Sequence[SectionEvent], chords: Sequence[ChordEvent]) -> int:
    pset = (settings.preset_name or "").lower()
    if any(x in pset for x in ("elise", "piano", "lullaby", "ambient")):
        return 0
    count = 0
    rate = max(25, min(getattr(settings, "global_arpeggio_rate", 60), getattr(track, "arp_rate", 100))) / 100.0
    step = 1.0 if rate < 0.65 else 0.5
    for bar, chord in enumerate(chords):
        sec = section_for_bar(sections, bar)
        if sec.energy < 62 or (bar - sec.start_bar) % 2 == 1:
            continue
        voicing = voice_lead([n + 12 for n in chord.notes], None, low=55, high=74)
        vel = clamp(track.volume * 0.42 + sec.energy * 0.05, 24, 54)
        start = bar * _bar_ticks(settings)
        steps = int(settings.beats_per_bar / step)
        for i in range(steps):
            if rate < 0.8 and i % 2:
                continue
            p = voicing[i % len(voicing)] + track.octave * 12 + track.transpose
            count += _add_note(data, track, start + _beat_ticks(settings, i * step), _beat_ticks(settings, step * 0.52), p, vel)
    return count


def _add_drums(data: MidiTrackData, track: TrackSettings, settings: GeneratorSettings, sections: Sequence[SectionEvent]) -> int:
    pset = (settings.preset_name or "").lower()
    if any(x in pset for x in ("elise", "canon", "piano", "lullaby", "ambient", "pad")):
        return 0
    count = 0
    for bar in range(settings.bars):
        sec = section_for_bar(sections, bar)
        if sec.energy < 24:
            continue
        base = clamp(track.volume * 0.50 + sec.energy * 0.16, 38, 82)
        if any(x in pset for x in ("house", "techno", "trance")):
            hits = [(0, "kick", base+7), (1, "kick", base), (2, "kick", base+5), (3, "kick", base), (1, "closed_hat", base-22), (3, "closed_hat", base-22), (2, "snare", base-8)]
        elif any(x in pset for x in ("drum and bass", "dnb")):
            hits = [(0, "kick", base+3), (1.5, "snare", base+8), (2, "kick", base-5), (3, "snare", base+6), (0.5, "closed_hat", base-26), (1, "closed_hat", base-28), (2.5, "closed_hat", base-26), (3.5, "closed_hat", base-28)]
        elif "reggae" in pset or "dub" in pset:
            hits = [(2, "kick", base), (3, "snare", base), (1, "closed_hat", base-22), (3, "closed_hat", base-24)]
        else:
            hits = [(0, "kick", base), (2, "snare", base-4), (1, "closed_hat", base-28), (3, "closed_hat", base-28)] if settings.beats_per_bar >= 4 else [(0, "kick", base), (2, "snare", base-8)]
        if bar == sec.start_bar + sec.bars - 1 and sec.energy > 60:
            hits.append((settings.beats_per_bar - 0.5, "snare", base+6))
        start = bar * _bar_ticks(settings)
        for off, name, vel in hits:
            if 0 <= off < settings.beats_per_bar:
                count += _add_note(data, track, start + _beat_ticks(settings, off), max(1, settings.ticks_per_beat // 10), DRUM_NOTES[name], vel)
    return count


def _add_counter(data: MidiTrackData, track: TrackSettings, settings: GeneratorSettings, sections: Sequence[SectionEvent], chords: Sequence[ChordEvent]) -> int:
    if any(x in (settings.preset_name or "").lower() for x in ("elise", "piano", "lullaby")):
        return 0
    count = 0
    for bar, chord in enumerate(chords):
        sec = section_for_bar(sections, bar)
        if sec.energy < 70 or (bar - sec.start_bar) % 8 not in (6, 7):
            continue
        tones = _chord_tones_in_range(chord, 60, min(settings.max_melody_pitch, 80))
        p = tones[(bar // 2) % len(tones)] + track.octave * 12 + track.transpose
        count += _add_note(data, track, bar * _bar_ticks(settings) + _beat_ticks(settings, settings.beats_per_bar - 1), _beat_ticks(settings, 0.45), p, clamp(track.volume * 0.45, 28, 54))
    return count


def _count_note_ons(tracks: Sequence[MidiTrackData]) -> int:
    return sum(1 for t in tracks for e in t.events if e.kind == "note_on" and e.b > 0)


def _normalize_tracks(tracks: Sequence[MidiTrackData], active_settings: Sequence[TrackSettings]) -> None:
    targets = {"drum": 62, "bass": 64, "melody": 74, "chord": 52, "pad": 40, "arpeggio": 45, "counter": 43, "texture": 34}
    for data, track in zip(tracks, active_settings):
        ons = [e for e in data.events if e.kind == "note_on" and e.b > 0]
        if not ons:
            continue
        role = _role(track)
        target = targets.get(role, 54)
        avg = sum(e.b for e in ons) / len(ons)
        density_penalty = max(0, len(ons) - 250) / 250 * 8
        shift = target - avg - density_penalty
        ceiling = 94 if role in ("melody", "drum") else 82 if role == "bass" else 72
        for e in ons:
            e.b = clamp(e.b + shift * 0.72, 16, ceiling)


def _visualizer_event_payload(tracks: Sequence[MidiTrackData], settings: GeneratorSettings, active_settings: Sequence[TrackSettings], end_tick: int) -> Tuple[List[Dict], float]:
    seconds_per_tick = 60.0 / max(1, settings.bpm) / max(1, settings.ticks_per_beat)
    roles: Dict[int, str] = {clamp(t.channel, 0, 15): _role(t) for t in active_settings}
    roles[9] = "drum"
    events = []
    for data in tracks:
        for e in data.events:
            if e.kind == "note_on" and e.b > 0:
                events.append({"t": round(e.tick * seconds_per_tick, 4), "p": int(e.a), "v": int(e.b), "d": 0.2, "role": roles.get(e.channel, "melody")})
    events.sort(key=lambda e: e["t"])
    if len(events) > 5000:
        step = max(1, len(events) // 5000)
        events = events[::step]
    return events, max(1.0, end_tick * seconds_per_tick)


def _sanitize_tracks_for_style(settings: GeneratorSettings) -> None:
    p = (settings.preset_name or "").lower()
    for t in settings.tracks:
        r = _role(t)
        if r == "texture":
            t.enabled = False
        if r == "arpeggio":
            t.volume = min(t.volume, 56)
            t.density = min(t.density, 52)
            t.activity = min(t.activity, 66)
            t.arp_rate = min(getattr(t, "arp_rate", 100), 70)
        if r == "counter":
            t.volume = min(t.volume, 50)
            t.density = min(t.density, 35)
            t.activity = min(t.activity, 50)
        if r == "pad":
            t.volume = min(t.volume, 58)
            t.density = min(t.density, 45)
        if r == "chord":
            t.volume = min(t.volume, 72)
        if r == "drum" and any(x in p for x in ("elise", "piano", "canon", "ambient", "pad", "lullaby")):
            t.enabled = False


def _smart_sanitize_settings(settings: GeneratorSettings) -> None:
    p = (settings.preset_name or "").lower()
    settings.musical_guardrails = True
    settings.timing_grid_lock = True
    settings.strict_arpeggio_grid = True
    settings.rhythmic_smoothing = True
    settings.calm_busy_tracks = True
    settings.normalize_velocity = True
    settings.humanize_ticks = min(settings.humanize_ticks, 1)
    settings.humanize_velocity = min(settings.humanize_velocity, 5)
    settings.coherence_strength = max(settings.coherence_strength, 94)
    settings.relaxation_strength = max(settings.relaxation_strength, 90)
    settings.global_arpeggio_rate = min(settings.global_arpeggio_rate, 72)
    settings.max_melody_pitch = min(max(settings.max_melody_pitch, 72), 82)
    if "elise" in p:
        settings.key = "A"
        settings.mode = "minor"
        settings.bpm = clamp(settings.bpm or 94, 86, 104)
        settings.beats_per_bar = 3
        settings.bars = clamp(settings.bars or 72, 48, 96)
        settings.melody_template = "Fuer-Elise contour"
        settings.progression = "Auto phrase harmony"
        settings.render_mp3 = False
        settings.complexity = min(settings.complexity, 32)
        settings.variation = min(settings.variation, 32)
        settings.seed_variation_strength = min(settings.seed_variation_strength, 28)
    elif "popcorn" in p:
        settings.key = "A"
        settings.mode = "minor"
        settings.bpm = clamp(settings.bpm or 136, 120, 144)
        settings.beats_per_bar = 4
        settings.bars = clamp(settings.bars or 96, 64, 160)
        settings.melody_template = "Popcorn-style recognizable contour"
    elif any(x in p for x in ("piano", "canon", "row", "twinkle", "ode", "lullaby")):
        settings.bpm = clamp(settings.bpm, 72, 118)
        settings.bars = clamp(settings.bars, 48, 128)
        settings.beats_per_bar = clamp(settings.beats_per_bar, 3, 4)
    elif any(x in p for x in ("drum and bass", "dnb")):
        settings.bpm = clamp(settings.bpm, 156, 176)
        settings.bars = clamp(settings.bars, 64, 128)
        settings.beats_per_bar = 4
    elif any(x in p for x in ("house", "techno", "trance")):
        settings.bpm = clamp(settings.bpm, 118, 140)
        settings.bars = clamp(settings.bars, 64, 160)
        settings.beats_per_bar = 4
    elif any(x in p for x in ("ambient", "pad", "drift")):
        settings.bpm = clamp(settings.bpm, 64, 96)
        settings.bars = clamp(settings.bars, 48, 128)
    else:
        settings.bpm = clamp(settings.bpm, 82, 138)
        settings.bars = clamp(settings.bars, 48, 128)
        settings.beats_per_bar = clamp(settings.beats_per_bar, 3, 4)
    _sanitize_tracks_for_style(settings)


def _quality_report(settings: GeneratorSettings, tracks: Sequence[MidiTrackData], sections: Sequence[SectionEvent], chords: Sequence[ChordEvent]) -> str:
    roles: Dict[str, int] = {}
    for data in tracks:
        for e in data.events:
            if e.kind == "note_on" and e.b > 0:
                roles[data.name] = roles.get(data.name, 0) + 1
    return f"{ENGINE_NAME}; sections={len(sections)}; chord_phrases=section-aware; tracks={len(tracks)}; note_tracks={roles}"


def generate_song(settings: GeneratorSettings, output_dir: str | os.PathLike[str], taste_profile: Optional[dict] = None, progress_callback=None) -> SongResult:
    settings = GeneratorSettings.from_dict(settings.to_dict())
    if settings.randomize_seed:
        settings.seed = int(time.time_ns() % 2_147_483_647)
    _smart_sanitize_settings(settings)
    rng = random.Random(settings.seed)
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    title = settings.title.strip() or generate_song_name(settings.seed, settings.preset_name)
    settings.title = title
    safe = safe_filename(title)
    midi_path = output / f"{safe}.mid"
    json_path = output / f"{safe}.json"
    chord_sheet_path = output / f"{safe}_chords.txt"
    if progress_callback:
        progress_callback(5, "Planning coherent song structure...")
    sections = build_sections(settings)
    chords = build_chords(settings, sections)
    bar_len = _bar_ticks(settings)
    end_tick = settings.bars * bar_len
    markers = [(s.start_bar * bar_len, s.name) for s in sections] if settings.add_markers else []
    tracks: List[MidiTrackData] = []
    active: List[TrackSettings] = []
    note_count = 0
    melody_done = False
    for idx, track in enumerate(settings.tracks):
        if not track.enabled:
            continue
        data = _setup_track(track)
        role = _role(track)
        if progress_callback:
            progress_callback(10 + int(70 * idx / max(1, len(settings.tracks))), f"Composing {track.name}...")
        if role == "drum":
            note_count += _add_drums(data, track, settings, sections)
        elif role == "bass":
            note_count += _add_bass(data, track, settings, sections, chords)
        elif role == "melody" and not melody_done:
            note_count += _add_melody(data, track, settings, sections, chords, rng)
            melody_done = True
        elif role == "melody":
            note_count += _add_counter(data, track, settings, sections, chords)
        elif role == "chord":
            note_count += _add_chords(data, track, settings, sections, chords, pad=False)
        elif role == "pad":
            note_count += _add_chords(data, track, settings, sections, chords, pad=True)
        elif role == "arpeggio":
            note_count += _add_arpeggio(data, track, settings, sections, chords)
        elif role in ("counter", "texture"):
            note_count += _add_counter(data, track, settings, sections, chords)
        else:
            note_count += _add_melody(data, track, settings, sections, chords, rng)
        tracks.append(data)
        active.append(track)
    if not melody_done:
        synthetic = TrackSettings(name="Main Melody", role="melody", channel=4, program=0, volume=82, pan=64, density=55, complexity=45, activity=80, pattern="auto")
        data = _setup_track(synthetic)
        note_count += _add_melody(data, synthetic, settings, sections, chords, rng)
        tracks.append(data)
        active.append(synthetic)
    if settings.normalize_velocity:
        if progress_callback:
            progress_callback(84, "Balancing tracks...")
        _normalize_tracks(tracks, active)
    note_count = _count_note_ons(tracks)
    if progress_callback:
        progress_callback(90, "Writing MIDI...")
    write_midi(str(midi_path), tracks, settings.ticks_per_beat, settings.bpm, settings.beats_per_bar, title, markers)
    chord_sheet_text = make_chord_sheet(title, settings, sections, chords, note_count)
    if settings.export_chord_sheet:
        chord_sheet_path.write_text(chord_sheet_text, encoding="utf-8")
    else:
        chord_sheet_path = Path("")
    result = SongResult(title=title, seed=settings.seed, midi_path=str(midi_path), json_path=str(json_path) if settings.export_json else "", chord_sheet_path=str(chord_sheet_path) if settings.export_chord_sheet else "", sections=sections, chords=chords, note_count=note_count, settings=settings)
    result.visualizer_events, result.visualizer_duration = _visualizer_event_payload(tracks, settings, active, end_tick)
    result.render_log += _quality_report(settings, tracks, sections, chords) + " "
    if settings.render_wav or settings.render_mp3:
        wav_path = output / f"{safe}.wav"
        mp3_path = output / f"{safe}.mp3"
        try:
            if progress_callback:
                progress_callback(94, "Rendering WAV...")
            result.wav_path = render_tracks_to_wav(wav_path, tracks, active, settings.bpm, settings.ticks_per_beat, end_tick, settings.audio_sample_rate, progress_callback, settings.normalize_velocity)
            result.render_log += "WAV rendered. "
            if settings.render_mp3:
                if ffmpeg_available():
                    result.mp3_path = convert_wav_to_mp3(result.wav_path, mp3_path)
                    result.render_log += "MP3 rendered via ffmpeg/libmp3lame. "
                else:
                    result.render_log += "MP3 skipped: ffmpeg was not found in PATH. "
        except Exception as exc:
            result.render_log += f"Audio render warning: {type(exc).__name__}: {exc} "
    if settings.export_json:
        payload = {
            "application": "PythonSoundHelix",
            "version": APP_VERSION,
            "license": "GPLv3",
            "title": result.title,
            "seed": result.seed,
            "midi_path": result.midi_path,
            "wav_path": result.wav_path,
            "mp3_path": result.mp3_path,
            "render_log": result.render_log,
            "note_count": result.note_count,
            "visualizer_duration": result.visualizer_duration,
            "visualizer_events": result.visualizer_events,
            "engine": ENGINE_NAME,
            "settings": settings.to_dict(),
            "sections": [asdict(s) for s in sections],
            "chords": [asdict(c) for c in chords],
        }
        json_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    if progress_callback:
        progress_callback(100, "Done")
    return result


def make_chord_sheet(title: str, settings: GeneratorSettings, sections: Sequence[SectionEvent], chords: Sequence[ChordEvent], note_count: int) -> str:
    lines = [
        title,
        "=" * len(title),
        "",
        f"Generated by PythonSoundHelix {APP_VERSION} (GPLv3)",
        f"Engine: {ENGINE_NAME}",
        f"Preset: {settings.preset_name}",
        f"Seed: {settings.seed}",
        f"Tempo: {settings.bpm} BPM | Key: {settings.key} {settings.mode} | Bars: {settings.bars} | Beats/bar: {settings.beats_per_bar}",
        f"Progression plan: {settings.effective_progression()}",
        f"Notes: {note_count}",
        "",
        "Sections:",
    ]
    for s in sections:
        lines.append(f"  - {s.name}: bars {s.start_bar + 1}-{s.start_bar + s.bars}, energy {s.energy}%")
    lines += ["", "Chord map:"]
    current = None
    buffer: List[str] = []
    for chord in chords:
        if chord.section != current:
            if buffer:
                lines.append("    " + " | ".join(buffer)); buffer.clear()
            current = chord.section
            lines.append(f"  [{current}]")
        root_name = midi_note_name(chord.notes[0])[:-1]
        buffer.append(f"{chord.bar + 1}:{chord.symbol}({root_name})")
        if len(buffer) >= 8:
            lines.append("    " + " | ".join(buffer)); buffer.clear()
    if buffer:
        lines.append("    " + " | ".join(buffer))
    lines += ["", "Note: v0.5.2 composes sections, harmony and melody first, then derives accompaniment tracks from the same song plan."]
    return "\n".join(lines) + "\n"
