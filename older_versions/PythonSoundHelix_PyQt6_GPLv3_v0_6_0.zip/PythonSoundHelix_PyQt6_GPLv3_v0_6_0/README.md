# PythonSoundHelix v0.6.0

PythonSoundHelix is a separate Python/PyQt6 project inspired by Thomas Schürger's original SoundHelix concept. It is not the original Java SoundHelix project.

Original SoundHelix project: Thomas Schürger.  
PythonSoundHelix project origin / updates: github.com/zeittresor.

## v0.6.0 quality-first reset

This build intentionally reduces fragility. The generator does not allow independent random tracks to drift away from the selected key, mode, chord map or rhythm grid.

Important rules:

- If a minor progression is selected, mode is forced to minor.
- If a major progression is selected, mode is forced to major.
- Bass, chords, pads and melody derive from one shared section/chord plan.
- Strong melody beats prefer chord tones.
- Weak melody beats stay in the active scale.
- A final tonal quality pass snaps non-drum notes back into the active scale/chord set.
- Melody coverage is distributed across the whole phrase instead of cutting only the beginning.

Default preset: `Toccata Drive`.

## Install

Run `install_windows.bat`.

## Offline wheelhouse

Run `update.bat` once online. It downloads wheels into `wheelhouse`. Afterwards the entire folder can be copied and installed offline.

## License

GPLv3.
