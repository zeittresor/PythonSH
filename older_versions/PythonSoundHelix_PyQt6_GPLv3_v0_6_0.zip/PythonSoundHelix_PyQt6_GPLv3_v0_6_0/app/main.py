from __future__ import annotations

import os
import sys
import json
import subprocess
from pathlib import Path

from PyQt6.QtCore import Qt
from PyQt6.QtGui import QAction, QDesktopServices
from PyQt6.QtCore import QUrl
from PyQt6.QtWidgets import (
    QApplication, QCheckBox, QComboBox, QFileDialog, QFormLayout, QGridLayout, QGroupBox,
    QHBoxLayout, QLabel, QLineEdit, QMainWindow, QMessageBox, QPushButton, QScrollArea,
    QSpinBox, QTabWidget, QTextEdit, QVBoxLayout, QWidget
)

from .generator import APP_VERSION, GeneratorSettings, PRESET_NAMES, PROGRESSION_NAMES, MELODY_TEMPLATES, TrackSettings, generate_song, preset_defaults, sanitize_mode_progression

ROOT = Path(__file__).resolve().parent.parent
OUTPUT_DIR = ROOT / "output"

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.settings = preset_defaults("Toccata Drive")
        self.last_result = None
        self.setWindowTitle(f"PythonSoundHelix v{APP_VERSION} - PyQt6 GPLv3")
        self.resize(1340, 840)
        self._build_ui()
        self._load_settings_to_ui()
        self._apply_dark_theme()

    def _build_ui(self):
        self.tabs = QTabWidget(); self.setCentralWidget(self.tabs)
        self.tabs.addTab(self._generate_tab(), "Generate")
        self.tabs.addTab(self._tracks_tab(), "Tracks")
        self.tabs.addTab(self._options_tab(), "Options")
        self.tabs.addTab(self._log_tab(), "Log")
        menubar = self.menuBar()
        help_menu = menubar.addMenu("Help")
        about = QAction("About", self); about.triggered.connect(self.about)
        help_menu.addAction(about)

    def _generate_tab(self):
        page=QWidget(); outer=QVBoxLayout(page)
        top=QHBoxLayout(); outer.addLayout(top)
        gen=QGroupBox("Generator"); form=QFormLayout(gen); top.addWidget(gen,1)
        self.preset=QComboBox(); self.preset.addItems(PRESET_NAMES); self.preset.currentTextChanged.connect(self.on_preset)
        self.title=QLineEdit(); self.seed=QSpinBox(); self.seed.setRange(0,2_147_483_647); self.randomize=QCheckBox("randomize on generate")
        seedrow=QHBoxLayout(); seedwrap=QWidget(); seedrow.addWidget(self.seed); seedrow.addWidget(self.randomize); seedwrap.setLayout(seedrow)
        self.bpm=QSpinBox(); self.bpm.setRange(40,240)
        self.bars=QSpinBox(); self.bars.setRange(16,256)
        self.beats=QSpinBox(); self.beats.setRange(3,4)
        self.ticks=QSpinBox(); self.ticks.setRange(96,1920)
        for label,w in [("Preset",self.preset),("Song title",self.title),("Seed",seedwrap),("BPM",self.bpm),("Bars",self.bars),("Beats per bar",self.beats),("Ticks per beat",self.ticks)]: form.addRow(label,w)
        harm=QGroupBox("Harmony / structure"); hform=QFormLayout(harm); top.addWidget(harm,1)
        self.key=QComboBox(); self.key.addItems(["C","C#","D","D#","E","F","F#","G","G#","A","A#","B"])
        self.mode=QComboBox(); self.mode.addItems(["major","minor"]); self.mode.currentTextChanged.connect(self.on_mode_progression)
        self.progression=QComboBox(); self.progression.addItems(PROGRESSION_NAMES); self.progression.currentTextChanged.connect(self.on_mode_progression)
        self.custom=QLineEdit(); self.custom.setPlaceholderText("Optional override, e.g. i,V,i,iv or C#m,G#,F#m")
        self.hrhythm=QSpinBox(); self.hrhythm.setRange(1,8)
        self.sections=QSpinBox(); self.sections.setRange(5,5); self.sections.setEnabled(False)
        self.melody_template=QComboBox(); self.melody_template.addItems(MELODY_TEMPLATES)
        self.coverage=QSpinBox(); self.coverage.setRange(5,100); self.coverage.setSuffix(" %")
        for label,w in [("Key",self.key),("Mode",self.mode),("Progression",self.progression),("Custom progression",self.custom),("Harmonic rhythm",self.hrhythm),("Sections",self.sections),("Melody template",self.melody_template),("Melody coverage",self.coverage)]: hform.addRow(label,w)
        adv=QGroupBox("Performance / advanced"); grid=QGridLayout(adv); outer.addWidget(adv)
        self.complexity=QSpinBox(); self.complexity.setRange(0,100)
        self.variation=QSpinBox(); self.variation.setRange(0,100)
        self.seed_variation=QSpinBox(); self.seed_variation.setRange(0,100)
        self.swing=QSpinBox(); self.swing.setRange(0,40)
        self.motif=QSpinBox(); self.motif.setRange(0,100)
        self.accent=QSpinBox(); self.accent.setRange(0,100)
        self.hticks=QSpinBox(); self.hticks.setRange(0,32)
        self.hvel=QSpinBox(); self.hvel.setRange(0,32)
        spin_pairs=[("Complexity",self.complexity),("Variation",self.variation),("Seed variation",self.seed_variation),("Swing",self.swing),("Motif memory",self.motif),("Accent",self.accent),("Humanize ticks",self.hticks),("Humanize velocity",self.hvel)]
        for i,(label,w) in enumerate(spin_pairs): grid.addWidget(QLabel(label),i,0); grid.addWidget(w,i,1)
        self.lfo=QCheckBox("LFO expression CC"); self.call=QCheckBox("call/response melody"); self.bass_roots=QCheckBox("bass favors chord roots"); self.markers=QCheckBox("section markers"); self.export_json=QCheckBox("export JSON result"); self.export_chords=QCheckBox("export chord sheet"); self.ratings=QCheckBox("use thumbs-up rating memory")
        checks=[self.lfo,self.call,self.bass_roots,self.markers,self.export_json,self.export_chords,self.ratings]
        for i,c in enumerate(checks): grid.addWidget(c,i,2)
        buttons=QHBoxLayout(); outer.addLayout(buttons)
        self.btn_generate=QPushButton("Generate Song"); self.btn_generate.clicked.connect(self.generate)
        self.btn_play=QPushButton("Play MIDI"); self.btn_play.clicked.connect(self.play_midi)
        self.btn_open=QPushButton("Open output folder"); self.btn_open.clicked.connect(lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(str(OUTPUT_DIR))))
        for b in [self.btn_generate,self.btn_play,self.btn_open]: buttons.addWidget(b)
        self.status=QTextEdit(); self.status.setMinimumHeight(110); self.status.setReadOnly(True); outer.addWidget(self.status)
        return page

    def _tracks_tab(self):
        self.track_page=QWidget(); self.track_layout=QVBoxLayout(self.track_page)
        self.track_widgets=[]
        return self.track_page

    def rebuild_tracks_tab(self):
        while self.track_layout.count():
            item=self.track_layout.takeAt(0)
            if item.widget(): item.widget().deleteLater()
        self.track_widgets=[]
        for t in self.settings.tracks:
            box=QGroupBox(t.name); f=QFormLayout(box)
            en=QCheckBox("enabled"); role=QComboBox(); role.addItems(["drum","bass","melody","chord","pad"]); vol=QSpinBox(); vol.setRange(0,127); prog=QSpinBox(); prog.setRange(0,127); octv=QSpinBox(); octv.setRange(-3,3); trans=QSpinBox(); trans.setRange(-12,12)
            en.setChecked(t.enabled); role.setCurrentText(t.role); vol.setValue(t.volume); prog.setValue(t.program); octv.setValue(t.octave); trans.setValue(t.transpose)
            for label,w in [("Enabled",en),("Role",role),("Program",prog),("Volume",vol),("Octave",octv),("Transpose",trans)]: f.addRow(label,w)
            self.track_widgets.append((t,en,role,prog,vol,octv,trans)); self.track_layout.addWidget(box)
        self.track_layout.addStretch(1)

    def _options_tab(self):
        page=QWidget(); v=QVBoxLayout(page)
        info=QTextEdit(); info.setReadOnly(True); info.setText("Quality-first build. The generator now enforces mode/progression compatibility and final tonal correction. Melody coverage is distributed across the whole phrase instead of clipping only the beginning.")
        v.addWidget(info)
        return page

    def _log_tab(self):
        self.log=QTextEdit(); self.log.setReadOnly(True); return self.log

    def _load_settings_to_ui(self):
        s=self.settings
        self.preset.blockSignals(True); self.preset.setCurrentText(s.preset_name); self.preset.blockSignals(False)
        self.title.setText(s.title); self.seed.setValue(s.seed); self.randomize.setChecked(s.randomize_seed)
        self.bpm.setValue(s.bpm); self.bars.setValue(s.bars); self.beats.setValue(s.beats_per_bar); self.ticks.setValue(s.ticks_per_beat)
        self.key.setCurrentText(s.key); self.mode.setCurrentText(s.mode); self.progression.setCurrentText(s.progression); self.custom.setText(s.custom_progression)
        self.hrhythm.setValue(s.harmonic_rhythm); self.sections.setValue(5); self.melody_template.setCurrentText(s.melody_template); self.coverage.setValue(s.melody_coverage)
        self.complexity.setValue(s.complexity); self.variation.setValue(s.variation); self.seed_variation.setValue(s.seed_variation_strength); self.swing.setValue(s.swing); self.motif.setValue(s.motif_memory); self.accent.setValue(s.accent_strength); self.hticks.setValue(s.humanize_ticks); self.hvel.setValue(s.humanize_velocity)
        self.lfo.setChecked(s.lfo_expression); self.call.setChecked(s.call_response); self.bass_roots.setChecked(s.keep_bass_on_roots); self.markers.setChecked(s.add_markers); self.export_json.setChecked(s.export_json); self.export_chords.setChecked(s.export_chord_sheet); self.ratings.setChecked(s.use_rating_memory)
        self.rebuild_tracks_tab()

    def _ui_to_settings(self):
        s=self.settings
        s.preset_name=self.preset.currentText(); s.title=self.title.text(); s.seed=self.seed.value(); s.randomize_seed=self.randomize.isChecked(); s.bpm=self.bpm.value(); s.bars=self.bars.value(); s.beats_per_bar=self.beats.value(); s.ticks_per_beat=self.ticks.value(); s.key=self.key.currentText(); s.mode=self.mode.currentText(); s.progression=self.progression.currentText(); s.custom_progression=self.custom.text(); s.harmonic_rhythm=self.hrhythm.value(); s.section_count=5; s.melody_template=self.melody_template.currentText(); s.melody_coverage=self.coverage.value(); s.complexity=self.complexity.value(); s.variation=self.variation.value(); s.seed_variation_strength=self.seed_variation.value(); s.swing=self.swing.value(); s.motif_memory=self.motif.value(); s.accent_strength=self.accent.value(); s.humanize_ticks=self.hticks.value(); s.humanize_velocity=self.hvel.value(); s.lfo_expression=self.lfo.isChecked(); s.call_response=self.call.isChecked(); s.keep_bass_on_roots=self.bass_roots.isChecked(); s.add_markers=self.markers.isChecked(); s.export_json=self.export_json.isChecked(); s.export_chord_sheet=self.export_chords.isChecked(); s.use_rating_memory=self.ratings.isChecked()
        for t,en,role,prog,vol,octv,trans in self.track_widgets:
            t.enabled=en.isChecked(); t.role=role.currentText(); t.program=prog.value(); t.volume=vol.value(); t.octave=octv.value(); t.transpose=trans.value()
        sanitize_mode_progression(s)
        return s

    def on_preset(self, name):
        self.settings=preset_defaults(name); self._load_settings_to_ui()

    def on_mode_progression(self):
        prog=self.progression.currentText().lower()
        if prog.startswith("minor") and self.mode.currentText() != "minor": self.mode.setCurrentText("minor")
        if prog.startswith("major") and self.mode.currentText() != "major": self.mode.setCurrentText("major")

    def generate(self):
        try:
            s=self._ui_to_settings(); OUTPUT_DIR.mkdir(exist_ok=True)
            res=generate_song(s, OUTPUT_DIR)
            self.last_result=res
            self.seed.setValue(res.seed); self.title.setText(res.title)
            msg=f"{res.title} | seed={res.seed} | notes={res.note_count}\nMIDI: {res.midi_path}\nChord sheet: {res.chord_sheet_path}\n{res.render_log}"
            self.status.setPlainText(msg); self.log.append(msg)
        except Exception as e:
            QMessageBox.critical(self,"Generate failed",f"{type(e).__name__}: {e}")
            raise

    def play_midi(self):
        if not self.last_result:
            QMessageBox.information(self,"PythonSoundHelix","Generate a song first."); return
        path=self.last_result.midi_path
        if sys.platform.startswith('win'):
            os.startfile(path)
        else:
            QDesktopServices.openUrl(QUrl.fromLocalFile(path))

    def about(self):
        QMessageBox.information(self,"About PythonSoundHelix", f"PythonSoundHelix v{APP_VERSION}\nGPLv3\n\nOriginal SoundHelix project: Thomas Schürger.\nPythonSoundHelix is inspired by SoundHelix but is a separate Python/PyQt6 project intended for github.com/zeittresor.\n\nThis build is quality-first: strict mode/progression lock, distributed melody coverage, tonal correction pass.")

    def _apply_dark_theme(self):
        self.setStyleSheet("""
        QWidget { background:#1d212b; color:#f4f6ff; font-size:13px; }
        QGroupBox { border:1px solid #3c465c; border-radius:8px; margin-top:10px; padding:10px; font-weight:bold; }
        QGroupBox::title { subcontrol-origin: margin; left:12px; padding:0 5px; }
        QLineEdit,QSpinBox,QComboBox,QTextEdit { background:#252b38; border:1px solid #394257; padding:5px; border-radius:5px; }
        QPushButton { background:#3574ed; border:0; padding:10px; border-radius:7px; }
        QPushButton:hover { background:#4d88ff; }
        QTabBar::tab { background:#202638; padding:9px 16px; border-top-left-radius:6px; border-top-right-radius:6px; }
        QTabBar::tab:selected { background:#3574ed; }
        """)


def run_gui():
    app=QApplication(sys.argv)
    win=MainWindow(); win.show()
    return app.exec()


def main(argv=None):
    argv=argv or sys.argv[1:]
    if "--nogui" in argv:
        preset="Toccata Drive"; seed=None; output=str(OUTPUT_DIR)
        for i,a in enumerate(argv):
            if a=="--preset" and i+1<len(argv): preset=argv[i+1]
            if a=="--seed" and i+1<len(argv): seed=int(argv[i+1])
            if a=="--output" and i+1<len(argv): output=argv[i+1]
        s=preset_defaults(preset)
        if seed is not None: s.seed=seed; s.randomize_seed=False
        res=generate_song(s, output)
        print(f"{res.title} | seed={res.seed} | notes={res.note_count}")
        print(res.midi_path)
        return 0
    return run_gui()
