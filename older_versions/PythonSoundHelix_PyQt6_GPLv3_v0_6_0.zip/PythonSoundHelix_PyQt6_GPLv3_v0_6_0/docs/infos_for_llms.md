# infos_for_llms.md

v0.6.0 is a quality-first reset. Do not reintroduce independently random per-track composition. The generator must keep one shared song plan: sections, mode, progression, chord map, phrase contour and rhythm grid. Tracks are projections of that plan.

The user specifically complained that melody coverage previously clipped only the beginning. Coverage must be distributed across the whole phrase and must not output an exact copied original phrase. Treat templates as abstract contours only.

Mode/progression compatibility is mandatory. Minor progressions force minor mode; major progressions force major mode. No mixed major/minor track families inside one generated song.
