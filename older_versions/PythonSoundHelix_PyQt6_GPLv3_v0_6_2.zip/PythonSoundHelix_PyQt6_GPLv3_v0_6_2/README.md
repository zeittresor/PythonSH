# PythonSoundHelix v0.6.2

PythonSoundHelix is a separate Python/PyQt6 project inspired by Thomas Schürger's original SoundHelix concept. It is not the original Java SoundHelix project.

Original SoundHelix project: Thomas Schürger.  
PythonSoundHelix project origin / updates: github.com/zeittresor.

## v0.6.2 melody governor and tonal-balance update

This build intentionally reduces fragility. The generator does not allow independent random tracks to drift away from the selected key, mode, chord map or rhythm grid.

Important rules:

- If a minor progression is selected, mode is forced to minor.
- If a major progression is selected, mode is forced to major.
- Bass, chords, pads and melody derive from one shared section/chord plan.
- Strong melody beats prefer chord tones.
- Weak melody beats stay in the active scale.
- A final tonal quality pass snaps non-drum notes back into the active scale/chord set.
- Melody coverage is distributed across the whole phrase instead of cutting only the beginning.

- Melody phrases are expanded as real multi-bar phrases instead of firing a whole contour in one bar and then waiting for the next pattern.
- The melody lane has a governor that prevents constant overly-fast clusters; fast bursts are mostly reserved for transitions and hooks.
- Melody velocity and MIDI channel volume are lowered so the lead sits closer to bass/chords/pads instead of dominating.
- Melody note-offs are now rewritten together with corrected note-ons during the tonal quality pass, preventing mismatched corrected pitches.

Default preset: `Toccata Drive`.

## Install

Run `install_windows.bat`.

## Offline wheelhouse

Run `update.bat` once online. It downloads wheels into `wheelhouse`. Afterwards the entire folder can be copied and installed offline.

## License

GPLv3.

## v0.6.2 Auto Composer / UI scrollbars

Defaults are now Auto-oriented: key, mode, progression and melody template may be resolved per seed so generated songs do not always begin with the same musical setup. The melody contour is transformed per section so A/B/Hook/Outro keep a recognizable thread without restarting the same pattern endlessly. Generate, Tracks, Options and Log tabs are wrapped in always-on vertical scroll areas.

