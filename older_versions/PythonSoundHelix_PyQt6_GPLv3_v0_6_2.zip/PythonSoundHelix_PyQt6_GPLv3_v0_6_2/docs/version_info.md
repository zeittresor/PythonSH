# PythonSoundHelix Version Info

version: 0.6.2
engine: quality-locked tonal composer

Remote updates must not replace this package with an older version.
