# Changelog

## v0.6.3

- Fixed generated songs overwriting previous output files. Output filenames now include the seed and auto-increment when needed.
- Randomized generation now ignores the previously generated title so every generation can receive a fresh song name.
- Reworked Tracks into a Finetuning tab with instrument selection, role/function selection, volume slider, fine-tune slider, octave and transpose controls.
- Added extra-track creation in the Finetuning tab.
- Added Options controls for English/German/French/Russian and interface themes.
- Added GM instrument names for user-facing instrument selection.

