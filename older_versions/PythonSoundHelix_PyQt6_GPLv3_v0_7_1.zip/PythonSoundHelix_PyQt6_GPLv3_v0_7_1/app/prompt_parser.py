from __future__ import annotations

import json
import random
import re
import unicodedata
from pathlib import Path
from typing import Dict, Iterable, List, Tuple

STYLE_DATA_PATH = Path(__file__).resolve().parent / "prompt_style_words.json"

KEY_WORDS = {
    "c#": "C#", "cis": "C#", "des": "C#", "db": "C#", "c sharp": "C#",
    "d#": "D#", "dis": "D#", "ees": "D#", "eb": "D#", "d sharp": "D#",
    "f#": "F#", "fis": "F#", "gb": "F#", "f sharp": "F#",
    "g#": "G#", "gis": "G#", "ab": "G#", "g sharp": "G#",
    "a#": "A#", "ais": "A#", "bb": "A#", "b flat": "A#",
    "c": "C", "d": "D", "e": "E", "f": "F", "g": "G", "a": "A", "b": "B", "h": "B",
}

NEGATION_PATTERNS = {
    "drum": ["no drums", "without drums", "ohne drums", "ohne schlagzeug", "keine drums", "keine schlagzeug", "sans batterie", "без ударных"],
    "bass": ["no bass", "without bass", "ohne bass", "kein bass", "sans basse", "без баса"],
    "pad": ["no pad", "without pad", "ohne pad", "keine pads", "sans pad"],
}

INTENSITY_WORDS = {
    "soft": -15, "gentle": -18, "calm": -20, "ruhig": -20, "sanft": -18, "zart": -20, "chill": -16, "relaxed": -18,
    "hard": 18, "heavy": 20, "hart": 18, "aggressiv": 22, "aggressive": 22, "intense": 18, "epic": 12,
}

SPEED_WORDS = {
    "very slow": -42, "langsam": -30, "slow": -28, "downtempo": -26, "ruhig": -18,
    "medium": 0, "midtempo": 0, "fast": 28, "schnell": 28, "rapid": 34, "speed": 38, "uptempo": 24,
    "sehr schnell": 42, "very fast": 42,
}

MOOD_MINOR = ["minor", "moll", "dark", "dunkel", "düster", "duester", "sad", "traurig", "melancholic", "melancholisch", "mysterious", "mystisch", "occult", "okkult"]
MOOD_MAJOR = ["major", "dur", "happy", "fröhlich", "frohlich", "bright", "hell", "uplifting", "positiv", "positive", "sunny", "sommer", "summer"]
SPARSE_WORDS = ["sparse", "minimal", "wenig", "sparsam", "subtle", "subtil", "luftig", "airy"]
DENSE_WORDS = ["dense", "voll", "viel", "busy", "complex", "komplex", "reich", "rich"]
LONG_WORDS = ["long", "lange", "lang", "extended", "epic", "ausgedehnt"]
SHORT_WORDS = ["short", "kurz", "klein", "sketch", "quick"]

ROLE_WORDS = {
    "piano": {"melody": 0, "chord": 0, "pad": 48, "bass": 32},
    "klavier": {"melody": 0, "chord": 0, "pad": 48, "bass": 32},
    "orchestral": {"melody": 40, "chord": 48, "pad": 48, "bass": 43},
    "orchester": {"melody": 40, "chord": 48, "pad": 48, "bass": 43},
    "guitar": {"melody": 27, "chord": 25, "pad": 27, "bass": 33},
    "gitarre": {"melody": 27, "chord": 25, "pad": 27, "bass": 33},
    "chiptune": {"melody": 80, "chord": 81, "pad": 88, "bass": 38},
    "8bit": {"melody": 80, "chord": 81, "pad": 88, "bass": 38},
    "choir": {"melody": 52, "chord": 52, "pad": 52},
    "chor": {"melody": 52, "chord": 52, "pad": 52},
}

STYLE_FALLBACKS = ["Synthwave", "Dark Ambient", "Acid House", "Drum and Bass", "20s Jazz", "House", "Canon Dream", "Piano", "Ambient"]


STYLE_FAMILY_TERMS = {
    "techno": ["techno", "tekkno", "schranz", "minimal tekkno", "acid techno", "hard techno", "detroit techno", "industrial techno"],
    "house": ["house", "deep house", "tech house", "techhouse", "garage house", "french house", "acid house", "disco house", "vocal house", "afro house", "latin house", "amapiano", "ukg", "uk garage"],
    "trance": ["trance", "goa", "uplifting trance", "acid trance", "rave", "big room"],
    "dnb": ["drum and bass", "drum n bass", "dnb", "jungle", "jump up", "techstep", "liquid dnb", "breakcore"],
    "hardcore": ["hardcore", "happy hardcore", "gabba", "frenchcore", "hardstyle", "speedcore"],
    "ambient": ["ambient", "dark ambient", "meditation", "drone", "spherical", "calm", "pad"],
    "piano": ["piano", "klavier", "walzer", "waltz", "ragtime"],
    "canon": ["canon", "baroque", "orchestral", "orchester", "church", "gospel", "choral", "choir"],
    "band": ["rock", "metal", "punk", "ska", "reggae", "dub", "rockabilly", "indie"],
    "latin": ["latin", "cumbia", "merengue", "tango", "cha cha", "cha-cha", "salsa"],
    "chiptune": ["8-bit", "8bit", "chiptune", "sid", "sid tune"],
    "hiphop": ["hiphop", "hip hop", "trap", "drill", "gangster rap", "rnb", "rhythm and grime", "grime"],
}

DRUM_HARD_WORDS = ["hard drums", "heavy drums", "hard kick", "starker kick", "harte drums", "harte kick", "druckvolle drums", "pounding drums", "relentless kick", "909", "four on the floor", "club kick"]

FAMILY_DEFAULTS = {
    "techno": {"preset": "Minor House", "mode": "minor", "bpm_min": 124, "bpm_max": 148, "template": "Toccata contour", "complexity": 72, "variation": 56},
    "house": {"preset": "Minor House", "mode": "minor", "bpm_min": 118, "bpm_max": 132, "template": "SoundHelix piano contour", "complexity": 62, "variation": 58},
    "trance": {"preset": "Minor House", "mode": "minor", "bpm_min": 132, "bpm_max": 146, "template": "Toccata contour", "complexity": 68, "variation": 68},
    "dnb": {"preset": "DNB Coherent", "mode": "minor", "bpm_min": 160, "bpm_max": 176, "template": "Toccata contour", "complexity": 76, "variation": 62},
    "hardcore": {"preset": "DNB Coherent", "mode": "minor", "bpm_min": 160, "bpm_max": 190, "template": "Toccata contour", "complexity": 82, "variation": 54},
    "ambient": {"preset": "Calm Ambient", "mode": "minor", "bpm_min": 64, "bpm_max": 94, "template": "SoundHelix piano contour", "complexity": 38, "variation": 52},
    "piano": {"preset": "Night Piano", "mode": "auto", "bpm_min": 72, "bpm_max": 108, "template": "SoundHelix piano contour", "complexity": 45, "variation": 55},
    "canon": {"preset": "Canon Dream", "mode": "major", "bpm_min": 78, "bpm_max": 112, "template": "Canon contour", "complexity": 46, "variation": 48},
    "band": {"preset": "Structured Pop", "mode": "auto", "bpm_min": 88, "bpm_max": 142, "template": "SoundHelix piano contour", "complexity": 58, "variation": 60},
    "latin": {"preset": "Structured Pop", "mode": "major", "bpm_min": 92, "bpm_max": 138, "template": "SoundHelix piano contour", "complexity": 62, "variation": 70},
    "chiptune": {"preset": "Toccata Drive", "mode": "auto", "bpm_min": 120, "bpm_max": 160, "template": "Toccata contour", "complexity": 75, "variation": 70},
    "hiphop": {"preset": "Structured Pop", "mode": "minor", "bpm_min": 70, "bpm_max": 110, "template": "SoundHelix piano contour", "complexity": 50, "variation": 58},
}



def normalize(text: str) -> str:
    text = (text or "").lower().replace("ß", "ss")
    text = text.replace("♯", "#").replace("♭", "b")
    text = unicodedata.normalize("NFKD", text)
    text = "".join(c for c in text if not unicodedata.combining(c))
    return text


def words(text: str) -> List[str]:
    return re.findall(r"[a-zа-яё0-9#]+", normalize(text), flags=re.IGNORECASE)


def phrase_in(text: str, phrases: Iterable[str]) -> bool:
    n = normalize(text)
    return any(normalize(p) in n for p in phrases)


def style_family_for(style: dict | None, prompt: str = "") -> str:
    sid = normalize((style or {}).get("id") or "")
    name = normalize((style or {}).get("name") or "")
    hay = f"{sid} {name} {normalize(prompt)}"
    for family, terms in STYLE_FAMILY_TERMS.items():
        if any(normalize(t).replace("-", " ") in hay.replace("_", " ").replace("-", " ") for t in terms):
            return family
    return "pop"


def prompt_intensity(prompt: str) -> int:
    score = 0
    norm = normalize(prompt)
    for term, value in INTENSITY_WORDS.items():
        if normalize(term) in norm:
            score += int(value)
    if phrase_in(prompt, DRUM_HARD_WORDS):
        score += 18
    return int(max(-40, min(45, score)))


def hard_drums_requested(prompt: str) -> bool:
    return phrase_in(prompt, DRUM_HARD_WORDS)


def _load_styles() -> List[dict]:
    try:
        data = json.loads(STYLE_DATA_PATH.read_text(encoding="utf-8"))
        return list(data.get("styles", []))
    except Exception:
        return []


def match_style(prompt: str, seed: int) -> Tuple[dict | None, List[Tuple[str, int]]]:
    styles = _load_styles()
    if not styles:
        return None, []
    norm = normalize(prompt)
    w = set(words(prompt))
    scores: List[Tuple[int, dict]] = []
    for st in styles:
        name = normalize(st.get("name") or "")
        toks = set(st.get("tokens") or [])
        score = 0
        if name and name in norm:
            score += 80 + len(name)
        for part in name.split():
            if len(part) > 2 and part in w:
                score += 18
        score += len(w & toks) * 4
        # Strong common shorthand boosts.
        aliases = {
            "drum_and_bass": ["drum and bass", "drum n bass", "dnb"],
            "liquid_dnb": ["liquid drum and bass", "liquid dnb"],
            "dnb": ["drum and bass", "drum n bass", "dnb"],
            "ukg": ["ukg", "uk garage"],
            "8_bit_sound": ["8 bit", "8-bit", "chiptune"],
            "synthwave": ["synthwave", "retrowave"],
            "dark_ambient": ["dark ambient", "dunkler ambient"],
        }
        for sid, phrases in aliases.items():
            if st.get("id") == sid and phrase_in(prompt, phrases):
                score += 90
        fam = style_family_for(st, prompt)
        if hard_drums_requested(prompt) and fam in ("techno", "hardcore", "dnb"):
            score += 18
        if "hard" in w and any(t in name for t in ["schranz", "hard", "gabba", "hardcore"]):
            score += 22
        if score:
            scores.append((score, st))
    scores.sort(key=lambda x: (x[0], x[1].get("name", "")), reverse=True)
    if scores and scores[0][0] >= 12:
        return scores[0][1], [(s.get("name", ""), sc) for sc, s in scores[:5]]
    # Empty / vague prompt: choose a style deterministically from the imported list.
    r = random.Random(seed ^ 0x707070)
    preferred = [s for s in styles if s.get("name") in STYLE_FALLBACKS]
    return r.choice(preferred or styles), []


def _program_from_style(style: dict, role: str) -> int | None:
    programs = style.get("programs") or {}
    if role == "bass":
        return programs.get("bass")
    if role == "melody":
        return programs.get("lead", programs.get("hook", programs.get("pluck")))
    if role == "chord":
        return programs.get("pluck", programs.get("vibe", programs.get("hook")))
    if role == "pad":
        return programs.get("pad", programs.get("echo"))
    return None


def _contains_any(prompt: str, terms: Iterable[str]) -> bool:
    norm = normalize(prompt)
    return any(normalize(t) in norm for t in terms)


def _parse_key(prompt: str) -> str | None:
    norm = normalize(prompt)
    # Match explicit forms first: "in c#", "key c#", "tonart fis".
    m = re.search(r"(?:key|tonart|in|en)\s+([a-g](?:#|b)?|cis|dis|fis|gis|ais|des|es|ees|as|bes|h)\b", norm)
    if m:
        return KEY_WORDS.get(m.group(1), None)
    return None


def _parse_bpm(prompt: str) -> int | None:
    m = re.search(r"\b(?:bpm|tempo)\s*[:=]?\s*(\d{2,3})\b", normalize(prompt))
    if not m:
        m = re.search(r"\b(\d{2,3})\s*bpm\b", normalize(prompt))
    if m:
        return max(48, min(220, int(m.group(1))))
    return None


def _style_to_generic_preset(style: dict | None, prompt: str, seed: int) -> str:
    family = style_family_for(style, prompt)
    if family == "dnb" or family == "hardcore":
        return "DNB Coherent"
    if family in ("techno", "house", "trance"):
        return "Minor House"
    if family == "ambient":
        return "Calm Ambient"
    if family == "piano":
        return "Night Piano"
    if family == "canon":
        return "Canon Dream"
    if family in ("chiptune",):
        return "Toccata Drive"
    if family in ("band", "latin", "hiphop"):
        return "Structured Pop"
    return "Auto Composer"

def apply_prompt_to_settings(settings, prompt: str, language: str = "English") -> dict:
    prompt = prompt or ""
    seed = int(getattr(settings, "seed", 0) or 0)
    style, candidates = match_style(prompt, seed)
    notes: List[str] = []
    if style:
        family = style_family_for(style, prompt)
        hard_drums = hard_drums_requested(prompt)
        intensity = prompt_intensity(prompt)
        notes.append(f"style={style.get('name')}")
        notes.append(f"family={family}")
        settings.prompt_style_id = str(style.get("id") or "")
        settings.prompt_style_name = str(style.get("name") or "")
        settings.prompt_style_family = family
        settings.prompt_drum_feel = str(style.get("drum_feel") or family)
        settings.prompt_intensity = intensity
        settings.prompt_hard_drums = hard_drums
        settings.preset_name = _style_to_generic_preset(style, prompt, seed)
        settings.key = "Auto"
        defaults = FAMILY_DEFAULTS.get(family, {})
        settings.mode = str(defaults.get("mode") or "auto")
        settings.progression = "Auto mode-safe"
        settings.melody_template = str(defaults.get("template") or "auto")
        lo = int(style.get("bpm_min") or defaults.get("bpm_min") or settings.bpm)
        hi = int(style.get("bpm_max") or defaults.get("bpm_max") or settings.bpm)
        settings.bpm = int((lo + hi) / 2)
        notes.append(f"bpm≈{settings.bpm}")
        if family == "techno" and hard_drums:
            settings.bpm = max(settings.bpm, min(148, settings.bpm + 6))
            notes.append("hard_drums=true")
        if (style.get("meter") or "4/4").startswith("3"):
            settings.beats_per_bar = 3
        else:
            settings.beats_per_bar = 4
        if style.get("swing") is not None:
            settings.swing = int(max(0, min(40, float(style.get("swing") or 0) * 100)))
        settings.complexity = int(defaults.get("complexity", settings.complexity))
        settings.variation = int(defaults.get("variation", settings.variation))
        if intensity > 8:
            settings.complexity = min(94, settings.complexity + intensity // 3)
            settings.accent_strength = min(92, getattr(settings, "accent_strength", 52) + intensity // 2)
        if family in ("techno", "hardcore"):
            settings.melody_coverage = min(getattr(settings, "melody_coverage", 50), 45)
            settings.call_response = False
        for t in getattr(settings, "tracks", []):
            role = getattr(t, "role", "")
            if getattr(t, "lock_instrument", False):
                continue
            prog = _program_from_style(style, role)
            if prog is not None:
                t.program = int(max(0, min(127, prog)))
            if family == "techno":
                if role == "drum":
                    t.volume = 86 if hard_drums else 78
                elif role == "bass":
                    t.volume = 78
                elif role == "melody":
                    t.volume = 52
                elif role == "chord":
                    t.volume = 64
                elif role == "pad":
                    t.volume = 24
            elif family == "hardcore":
                if role == "drum": t.volume = 92
                elif role == "bass": t.volume = 82
                elif role == "pad": t.volume = 18
                elif role == "melody": t.volume = 48
            else:
                arp = float(style.get("arp_density") or 0.4)
                pad = float(style.get("pad_density") or 0.4)
                bright = float(style.get("brightness") or 0.5)
                if role == "pad":
                    t.volume = int(max(28, min(70, 34 + pad * 30)))
                if role == "melody":
                    t.volume = int(max(50, min(78, 62 + bright * 16)))
    else:
        settings.preset_name = "Auto Composer"
        settings.prompt_style_family = "auto"

    bpm = _parse_bpm(prompt)
    if bpm:
        settings.bpm = bpm
        notes.append(f"explicit_bpm={bpm}")
    key = _parse_key(prompt)
    if key:
        settings.key = key
        notes.append(f"key={key}")
    if _contains_any(prompt, MOOD_MINOR):
        settings.mode = "minor"
        notes.append("mode=minor")
    elif _contains_any(prompt, MOOD_MAJOR):
        settings.mode = "major"
        notes.append("mode=major")

    # Speed words adjust only if no explicit BPM was present.
    if not bpm:
        delta = 0
        norm = normalize(prompt)
        for phrase, value in SPEED_WORDS.items():
            if normalize(phrase) in norm:
                delta += value
        if delta:
            if style and style.get("bpm_min") and style.get("bpm_max"):
                lo, hi = int(style["bpm_min"]), int(style["bpm_max"])
                if delta > 0:
                    settings.bpm = int(max(lo, min(hi, settings.bpm + delta * 0.35)))
                else:
                    settings.bpm = int(max(lo, min(hi, settings.bpm + delta * 0.50)))
            else:
                settings.bpm = int(max(48, min(220, settings.bpm + delta)))
            notes.append(f"speed_delta={delta}")

    if _contains_any(prompt, ["3/4", "waltz", "walzer", "valse"]):
        settings.beats_per_bar = 3
        notes.append("meter=3/4")
    elif _contains_any(prompt, ["4/4", "four on the floor", "club", "dancefloor"]):
        settings.beats_per_bar = 4

    if _contains_any(prompt, LONG_WORDS):
        settings.bars = max(settings.bars, 128)
    if _contains_any(prompt, SHORT_WORDS):
        settings.bars = min(settings.bars, 64)

    if _contains_any(prompt, SPARSE_WORDS):
        settings.complexity = max(25, settings.complexity - 20)
        settings.variation = max(30, settings.variation - 10)
        for t in getattr(settings, "tracks", []):
            if getattr(t, "role", "") in ("chord", "pad", "melody"):
                t.volume = max(28, int(t.volume * 0.86))
        notes.append("density=sparse")
    if _contains_any(prompt, DENSE_WORDS):
        settings.complexity = min(92, settings.complexity + 12)
        settings.variation = min(92, settings.variation + 10)
        notes.append("density=rich")

    # Direct instrument-color words override unlocked tracks.
    norm = normalize(prompt).replace("-", "")
    for term, role_programs in ROLE_WORDS.items():
        if normalize(term).replace("-", "") in norm:
            for t in getattr(settings, "tracks", []):
                prog = role_programs.get(getattr(t, "role", ""))
                if prog is not None and not getattr(t, "lock_instrument", False):
                    t.program = prog
            notes.append(f"instrument_color={term}")

    for role, patterns in NEGATION_PATTERNS.items():
        if phrase_in(prompt, patterns):
            for t in getattr(settings, "tracks", []):
                if getattr(t, "role", "") == role:
                    t.enabled = False
            notes.append(f"disable_{role}=true")

    if phrase_in(prompt, ["only piano", "piano solo", "nur klavier", "solo piano", "nur piano"]):
        for t in getattr(settings, "tracks", []):
            if getattr(t, "role", "") == "drum":
                t.enabled = False
            if getattr(t, "role", "") in ("melody", "chord") and not getattr(t, "lock_instrument", False):
                t.program = 0
            if getattr(t, "role", "") == "pad":
                t.enabled = False
        settings.preset_name = "Night Piano"
        notes.append("arrangement=piano_solo")

    if _contains_any(prompt, ["experimental", "dissonant", "atonal", "schrag", "schräg", "free counterpoint", "frei"]):
        settings.allow_dissonance = True
        notes.append("allow_dissonance=true")
    else:
        settings.allow_dissonance = False

    # Prompt mode should never reuse stale typed titles unless the prompt explicitly asks for a title.
    if not re.search(r"(?:title|titel|named|name it)\s*[:=]", normalize(prompt)):
        settings.title = ""

    settings.prompt = prompt
    settings.prompt_language = language
    settings.prompt_interpretation = "; ".join(notes) if notes else "auto interpretation"
    return {"notes": notes, "style": style, "candidates": candidates}
