# PythonSoundHelix Version Info

version: 0.7.1

Prompt-first build. The Generate tab is natural-language first and direct generator parameters are hidden. Prompt parsing uses local multilingual wordlists and style vocabulary derived from the user-provided Synthwave Midi Reimaginer style data.
