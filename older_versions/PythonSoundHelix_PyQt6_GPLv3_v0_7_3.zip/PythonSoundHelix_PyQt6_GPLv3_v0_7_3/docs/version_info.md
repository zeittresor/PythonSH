# PythonSoundHelix Version Info

version: 0.7.3
date: 2026-06-07

This package adds a local reference database for high-level artist/song/style prompt interpretation. References are used only as genre/trait hints; original songs, melodies, lyrics and arrangements are not copied.
