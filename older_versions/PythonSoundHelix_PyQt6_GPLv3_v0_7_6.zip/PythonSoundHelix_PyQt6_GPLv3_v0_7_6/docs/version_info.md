# PythonSoundHelix Version Info

version: 0.7.6

This version strengthens multi-style prompt blends such as goa/techno/psytrance and writes prompt_style_blend to generated JSON.
