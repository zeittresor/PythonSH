# PythonSoundHelix v0.7.8

## v0.7.8 prompt-first interface

The Generate tab now uses a natural-language prompt instead of direct generator parameter editing. Type requests such as:

- `dark melodic drum and bass, fast, strong drums, evolving bass, airy pads, no dissonance`
- `ruhiger Walzer mit Klavier und Streichern, warm, nicht schräg`
- `acid house, 126 bpm, hypnotic bass, no pads`

The parser is local/offline and uses multilingual wordlists plus style vocabulary imported from the user-provided Synthwave Midi Reimaginer style data. Optional Finetuning remains available for manual track/instrument overrides and locked instruments.



## v0.7.8 arrangement/profile update

Presets are now style hints. By default, key, mode, progression and melody template stay Auto so each seed can generate its own coherent structure. The engine chooses a seed-specific arrangement profile controlling which role enters first and which roles are foreground/subtle. This prevents every song from beginning with bass and reduces identical long A-section loops.

PythonSoundHelix is a separate Python/PyQt6 project inspired by Thomas Schürger's original SoundHelix concept. It is not the original Java SoundHelix project.

Original SoundHelix project: Thomas Schürger.  
PythonSoundHelix project origin / updates: github.com/zeittresor.


## v0.7.8 file output / finetuning update

- Generated filenames now include the seed, for example `Song_Title_seed123456.mid`.
- If the same title/seed already exists, a suffix like `_02` is added instead of overwriting the previous song.
- When `randomize on generate` is enabled, a new title is generated each time even if the title field currently shows the previous result.
- The old Tracks page is now a Finetuning page. Each track has instrument, role, volume, finetune, octave and transpose controls.
- Finetuning can add additional tracks/instruments with a selected musical role.
- Options now includes live language switching for English, German, French and Russian plus interface themes: Dark, Light, Matrix, Ocean, Purple, Hellfire and Sepia.

## v0.7.8 melody governor and tonal-balance update

This build intentionally reduces fragility. The generator does not allow independent random tracks to drift away from the selected key, mode, chord map or rhythm grid.

Important rules:

- If a minor progression is selected, mode is forced to minor.
- If a major progression is selected, mode is forced to major.
- Bass, chords, pads and melody derive from one shared section/chord plan.
- Strong melody beats prefer chord tones.
- Weak melody beats stay in the active scale.
- A final tonal quality pass snaps non-drum notes back into the active scale/chord set.
- Melody coverage is distributed across the whole phrase instead of cutting only the beginning.

- Melody phrases are expanded as real multi-bar phrases instead of firing a whole contour in one bar and then waiting for the next pattern.
- The melody lane has a governor that prevents constant overly-fast clusters; fast bursts are mostly reserved for transitions and hooks.
- Melody velocity and MIDI channel volume are lowered so the lead sits closer to bass/chords/pads instead of dominating.
- Melody note-offs are now rewritten together with corrected note-ons during the tonal quality pass, preventing mismatched corrected pitches.

Default preset: `Auto Composer`. Other presets are style hints; core harmonic/melodic choices remain Auto by default.

## Install

Run `install_windows.bat`.

## Offline wheelhouse

Run `update.bat` once online. It downloads wheels into `wheelhouse`. Afterwards the entire folder can be copied and installed offline.

## License

GPLv3.

## v0.7.8 Auto Composer / UI scrollbars

Defaults are now Auto-oriented: key, mode, progression and melody template may be resolved per seed so generated songs do not always begin with the same musical setup. The melody contour is transformed per section so A/B/Hook/Outro keep a recognizable thread without restarting the same pattern endlessly. Generate, Tracks, Options and Log tabs are wrapped in always-on vertical scroll areas.


## v0.7.8 reference-aware prompts

PythonSoundHelix now ships a local SQLite reference database (`app/style_reference.sqlite`) with more than 2,000 rows. It maps style terms, artist names and well-known song references to high-level musical traits such as style family, BPM range, drum feel, bass feel, intensity and GM instrument colors. This is for prompt interpretation only: the generator must not copy original melodies, lyrics, recordings or arrangements.

A new **Reference DB** tab lets users test reference matches and add their own local references. User-added references are stored in `app_data/user_style_references.jsonl` so updates do not overwrite them. A PostgreSQL-compatible schema is included in `docs/style_reference_schema_postgresql.sql` for future central/updateable deployments.

## v0.7.8 semantic prompt relation layer

The prompt parser now connects style, mood, instrument and reference words before mapping to the engine. For example, `dark melodic dran and bass` becomes a dark melodic DnB relation profile instead of a vague industrial/trait match, and `goa / techno / psytrance` becomes a Goa+Techno+Psytrance blend. The generated JSON exposes `prompt_relation_profile`, `prompt_semantic_tags` and `prompt_style_confidence` for debugging.


## v0.7.8 direct style dropdown

When Options disables the Prompt-first Generate tab, the direct parameter view now has a Style / drum preset dropdown. It is populated from the imported Synthwave MIDI Reimaginer style vocabulary and can be left on Auto / random style or set to one of the packaged style profiles. The selected style is used as a style, drum and instrument hint; explicit direct overrides such as key, mode, progression, custom progression and melody template remain authoritative.

